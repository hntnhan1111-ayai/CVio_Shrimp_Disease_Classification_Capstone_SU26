
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

INJECTION_BLOCK = r'''

# === CVIO_WINDOWS6GB_ATTENTION_INJECTION_V2_BEGIN ===
# Repo-local safety helpers for attention insertion before Ultralytics Classify head.
# This block is intentionally conservative: if the project already defines these helpers,
# the appended definitions override only the public names at import time.
from __future__ import annotations as _cvio_annotations
import json as _attention_json
import math as _attention_math
import torch as _attention_torch
import torch.nn as _attention_nn

class AttentionBeforeClassify(_attention_nn.Module):
    def __init__(self, attention_module, classify_head):
        super().__init__()
        self.attention = attention_module
        self.classify = classify_head
        # Preserve Ultralytics graph metadata when present.
        for attr in ("f", "i", "type", "np"):
            if hasattr(classify_head, attr):
                try:
                    setattr(self, attr, getattr(classify_head, attr))
                except Exception:
                    pass

    def forward(self, x):
        x = self.attention(x)
        return self.classify(x)


def _cvio_find_final_classify_module(model):
    candidates = []
    for name, module in model.named_modules():
        cls_name = module.__class__.__name__.lower()
        if cls_name == "classify" or cls_name.endswith("classify"):
            candidates.append((name, module))
    if not candidates:
        raise RuntimeError("Could not locate final Ultralytics Classify head for attention injection.")
    return candidates[-1]


def _cvio_get_parent_module(root, dotted_name: str):
    if not dotted_name:
        raise RuntimeError("Cannot replace root module directly.")
    parts = dotted_name.split(".")
    parent = root
    for part in parts[:-1]:
        parent = parent[int(part)] if part.isdigit() else getattr(parent, part)
    return parent, parts[-1]


def _cvio_replace_child(parent, child_name: str, new_module):
    if child_name.isdigit() and hasattr(parent, "__setitem__"):
        parent[int(child_name)] = new_module
    else:
        setattr(parent, child_name, new_module)


def _cvio_infer_head_input_shape(model, classify_head, img_size=224, device=None):
    seen = {}
    def pre_hook(module, inputs):
        x = inputs[0]
        if isinstance(x, (list, tuple)):
            x = x[0]
        if hasattr(x, "shape"):
            seen["shape"] = tuple(int(v) for v in x.shape)
            seen["channels"] = int(x.shape[1]) if len(x.shape) >= 2 else None
            seen["dtype"] = str(x.dtype)
            seen["device"] = str(x.device)
    h = classify_head.register_forward_pre_hook(pre_hook)
    was_training = model.training
    model.eval()
    try:
        with _attention_torch.no_grad():
            dev = device or next(model.parameters()).device
            dummy = _attention_torch.zeros(1, 3, int(img_size), int(img_size), device=dev)
            out = model(dummy)
        if "channels" not in seen or seen["channels"] is None:
            raise RuntimeError("Forward hook did not infer Classify input channels.")
        return seen, out
    finally:
        h.remove()
        model.train(was_training)


def _cvio_build_attention_from_key(attention_key, channels):
    # Prefer whichever factory the active project/top10 patch exposes.
    for fn_name in ("build_attention_module", "make_attention_module", "make_attention", "create_attention_module", "get_attention_module"):
        fn = globals().get(fn_name)
        if callable(fn):
            try:
                return fn(attention_key=attention_key, channels=channels)
            except TypeError:
                try:
                    return fn(attention_key, channels)
                except TypeError:
                    continue
    raise RuntimeError(f"No attention factory could construct attention_key={attention_key!r} channels={channels}.")


def inject_attention_before_classify(model, attention_key="none_baseline", img_size=224, num_classes=4, device=None):
    if attention_key in (None, "", "none", "none_baseline", "baseline"):
        return model, {
            "attention_key": attention_key,
            "requested_attention_key": attention_key,
            "status": "baseline_no_attention",
            "inserted": False,
            "params_added": 0,
        }
    name, head = _cvio_find_final_classify_module(model)
    shape_audit, original_out = _cvio_infer_head_input_shape(model, head, img_size=img_size, device=device)
    channels = int(shape_audit["channels"])
    attention = _cvio_build_attention_from_key(attention_key, channels)
    params_added = int(sum(p.numel() for p in attention.parameters()))
    wrapper = AttentionBeforeClassify(attention, head)
    parent, child = _cvio_get_parent_module(model, name)
    _cvio_replace_child(parent, child, wrapper)
    was_training = model.training
    model.eval()
    try:
        with _attention_torch.no_grad():
            dev = device or next(model.parameters()).device
            dummy = _attention_torch.zeros(1, 3, int(img_size), int(img_size), device=dev)
            verified = model(dummy)
        if isinstance(verified, (list, tuple)):
            verified_shape = list(verified[0].shape) if hasattr(verified[0], "shape") else [str(type(verified[0]))]
        else:
            verified_shape = list(verified.shape) if hasattr(verified, "shape") else [str(type(verified))]
    finally:
        model.train(was_training)
    audit = {
        "attention_key": attention_key,
        "requested_attention_key": attention_key,
        "status": "inserted",
        "inserted": True,
        "implementation_source": getattr(attention, "implementation_source", "repo_local_custom_cbam_inspired"),
        "implementation_variant": getattr(attention, "implementation_variant", "experimental_repo_local_custom_cbam_inspired"),
        "is_exact_official_implementation": bool(getattr(attention, "is_exact_official_implementation", False)),
        "attention_family": getattr(attention, "attention_family", "custom_cbam_inspired_top10"),
        "target_module_name": name,
        "target_module_class": head.__class__.__name__,
        "wrapper_class": wrapper.__class__.__name__,
        "attention_module_class": attention.__class__.__name__,
        "params_added": params_added,
        "wrapper_total_params": int(sum(p.numel() for p in wrapper.parameters())),
        "inferred_channels": channels,
        "head_input_shape": list(shape_audit.get("shape", [])),
        "verified_output_shape": verified_shape,
        "img_size": int(img_size),
        "num_classes": int(num_classes),
    }
    return model, audit
# === CVIO_WINDOWS6GB_ATTENTION_INJECTION_V2_END ===
'''

def patch_file(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    begin = "# === CVIO_WINDOWS6GB_ATTENTION_INJECTION_V2_BEGIN ==="
    end = "# === CVIO_WINDOWS6GB_ATTENTION_INJECTION_V2_END ==="
    if begin in text and end in text:
        pre = text.split(begin)[0].rstrip()
        post = text.split(end)[-1].lstrip()
        text = pre + "\n" + INJECTION_BLOCK + "\n" + post
    else:
        text = text.rstrip() + "\n" + INJECTION_BLOCK + "\n"
    path.write_text(text, encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project_dir", required=True)
    ap.add_argument("--run_compileall", action="store_true")
    args = ap.parse_args()
    project = Path(args.project_dir).resolve()
    target = project / "shrimp_scripts" / "attention.py"
    if not target.exists():
        raise SystemExit(f"Missing attention.py: {target}")
    backup = target.with_suffix(target.suffix + ".bak_windows_injection_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    shutil.copy2(target, backup)
    patch_file(target)
    print(f"Backup created: {backup}")
    print(f"Patched: {target}")
    if args.run_compileall:
        subprocess.check_call([sys.executable, "-m", "compileall", "shrimp_scripts", "experiments"], cwd=str(project))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
