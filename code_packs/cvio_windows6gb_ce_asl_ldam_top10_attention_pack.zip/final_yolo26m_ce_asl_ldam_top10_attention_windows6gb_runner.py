
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shutil
import subprocess
import sys
import textwrap
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

TOP10 = [
    "dynamic_multiscale_gated_cbam_lite",
    "nam_cbam_lite",
    "local_block_pooling_cbam_lite",
    "directional_stripe_cbam",
    "eca_nam_spatial_cbam",
    "gam_lite_cbam_no_pool_spatial",
    "binary_gated_cbam_lite",
    "ema_grouped_cbam",
    "sparse_learnable_fusion_cbam",
    "two_step_iterative_cbam_lite",
]

ARMS = [
    {"arm": "stage1_ce_attention", "loss_key": "baseline_ce", "label": "Stage-1 CE foundation + attention"},
    {"arm": "asl_ldam_margin_attention", "loss_key": "asl_ldam_margin", "label": "ASL-LDAM Margin + attention"},
]

REFERENCE = {
    "stage1_ce_fixed_reference": {"test_macro_f1": 0.8902, "test_accuracy": 0.8902, "cohen_kappa": 0.8505},
    "asl_ldam_margin_reference": {"test_macro_f1": 0.8991, "test_accuracy": 0.9017, "cohen_kappa": 0.8661},
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


def run_cmd(cmd: list[str], cwd: Path | None, log_path: Path, env: dict[str, str], check: bool = True) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print("\n[RUN]", " ".join(map(str, cmd)))
    print("[CWD]", cwd or Path.cwd())
    print("[LOG]", log_path)
    with log_path.open("w", encoding="utf-8", errors="replace") as f:
        f.write("[RUN] " + " ".join(map(str, cmd)) + "\n")
        f.write("[CWD] " + str(cwd or Path.cwd()) + "\n")
        f.flush()
        p = subprocess.Popen(cmd, cwd=str(cwd) if cwd else None, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
        assert p.stdout is not None
        for line in p.stdout:
            print(line, end="")
            f.write(line)
        rc = p.wait()
        f.write(f"\n[EXIT_CODE] {rc}\n")
    if check and rc != 0:
        raise RuntimeError(f"Command failed rc={rc}: {' '.join(map(str, cmd))}; log={log_path}")
    return rc


def copy_project(src: Path, dst: Path, force: bool) -> None:
    if dst.exists() and force:
        shutil.rmtree(dst)
    if dst.exists():
        print(f"Using existing work project: {dst}")
        return
    print("Copying project to isolated folder:")
    print("  SRC=", src)
    print("  DST=", dst)
    ignore = shutil.ignore_patterns(
        ".git", ".venv", "venv", "__pycache__", ".ipynb_checkpoints", "*.pt", "*.pth",
        "runs", "outputs", "wandb", "datasets", "yolo_fixed_dataset", "*.zip"
    )
    shutil.copytree(src, dst, ignore=ignore)


def write_kagglehub_override(project: Path, dataset_root: Path) -> None:
    shim = project / "kagglehub.py"
    dataset_root = dataset_root.resolve()
    # run_01_prepare_dataset often expects dataset_download() to return the parent directory
    # containing processed_images. If user passes processed_images itself, return parent.
    return_path = dataset_root.parent if dataset_root.name == "processed_images" else dataset_root
    shim.write_text(f'''
from pathlib import Path

def dataset_download(slug: str):
    print("Using local KaggleHub override for", slug)
    return str(Path(r"{return_path}"))
'''.lstrip(), encoding="utf-8")
    print("Wrote local kagglehub override:", shim, "->", return_path)


def patch_windows6gb_config(project: Path, batch: int, workers: int) -> dict[str, Any]:
    cfg = project / "shrimp_scripts" / "config.py"
    audit = {"path": str(cfg), "patched": False, "replacements": []}
    if not cfg.exists():
        audit["error"] = "config.py missing"
        return audit
    text = cfg.read_text(encoding="utf-8")
    original = text
    patterns = {
        r"(?m)^(\s*YOLO_BATCH_SIZE\s*=\s*)\d+": f"\\g<1>{batch}",
        r"(?m)^(\s*BATCH_SIZE\s*=\s*)\d+": f"\\g<1>{batch}",
        r"(?m)^(\s*YOLO_WORKERS\s*=\s*)\d+": f"\\g<1>{workers}",
        r"(?m)^(\s*WORKERS\s*=\s*)\d+": f"\\g<1>{workers}",
        r"(?m)^(\s*NUM_WORKERS\s*=\s*)\d+": f"\\g<1>{workers}",
    }
    for pat, repl in patterns.items():
        text2, n = re.subn(pat, repl, text)
        if n:
            audit["replacements"].append({"pattern": pat, "count": n})
            text = text2
    if text != original:
        backup = cfg.with_suffix(cfg.suffix + ".bak_windows6gb_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
        shutil.copy2(cfg, backup)
        cfg.write_text(text, encoding="utf-8")
        audit["patched"] = True
        audit["backup"] = str(backup)
    return audit


def generate_selftest_scripts(output_dir: Path, model_name: str) -> tuple[Path, Path, Path]:
    mod_test = output_dir / "selftest_top10_attention_modules.py"
    module_json = output_dir / "attention_module_self_test.json"
    mod_test.write_text(f'''
from pathlib import Path
import json
from shrimp_scripts.attention import attention_keys, self_test_attention_modules
expected = {TOP10!r}
keys = attention_keys()
print("attention_keys=", keys)
missing = [k for k in expected if k not in keys]
if missing:
    raise RuntimeError("missing top10 keys: " + repr(missing))
result = self_test_attention_modules(attention_key=None)
print(json.dumps(result, indent=2, default=str))
Path(r"{module_json}").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
if result.get("status") != "passed":
    raise RuntimeError("attention module self-test failed")
'''.lstrip(), encoding="utf-8")

    inj_test = output_dir / "selftest_top10_attention_injection.py"
    injection_json = output_dir / "attention_injection_self_test.json"
    inj_test.write_text(f'''
import json
from pathlib import Path
from ultralytics import YOLO
from shrimp_scripts.attention import inject_attention_before_classify
expected = {TOP10!r}
rows = []
for key in expected:
    y = YOLO("{model_name}.pt")
    model, audit = inject_attention_before_classify(y.model, attention_key=key, img_size=224, num_classes=4, device="cpu")
    print("injection_passed", key, json.dumps(audit, default=str)[:1200])
    if audit.get("status") != "inserted" or not audit.get("inserted"):
        raise RuntimeError(f"injection failed for {{key}}: {{audit}}")
    rows.append(audit)
Path(r"{injection_json}").write_text(json.dumps({{"status":"passed", "rows":rows}}, indent=2, default=str), encoding="utf-8")
print("Top-10 injection self-test passed.")
'''.lstrip(), encoding="utf-8")

    loss_test = output_dir / "selfcheck_asl_ldam_margin.py"
    loss_test.write_text(f'''
import subprocess, sys
from pathlib import Path
out = Path(r"{output_dir}")
script = Path("experiments/asl_custom_loss_screening/run_asl_custom_screen.py")
if not script.exists():
    raise SystemExit("Missing ASL custom screening script: " + str(script))
cmd = [sys.executable, str(script), "--output_dir", str(out), "--backend", "yolo", "--model", "{model_name}", "--loss", "asl_ldam_margin", "--self_check_yolo_loss"]
print("RUN", " ".join(cmd))
subprocess.check_call(cmd)
'''.lstrip(), encoding="utf-8")
    return mod_test, inj_test, loss_test

def generate_train_script(path: Path, project: Path, output_dir: Path, arm: dict[str, str], attention_key: str, epochs: int, model_name: str, smoke_test: bool) -> None:
    condition_key = f"ce_asl_ldam_top10_attention_20runs_{model_name}_{arm['loss_key']}_{attention_key}_randaugment_seed42"
    script = f'''
from __future__ import annotations
import json
from pathlib import Path
import sys
ROOT = Path(r"{project}").resolve()
sys.path.insert(0, str(ROOT))
from shrimp_scripts.dataset import load_yolo_manifest
from shrimp_scripts.models_yolo import train_yolo_with_fallback
from shrimp_scripts.utils import write_json

output_dir = Path(r"{output_dir}")
yolo_manifest = load_yolo_manifest(output_dir)
condition = {{
    "condition_key": "{condition_key}",
    "loss_key": "{arm['loss_key']}",
    "randaugment": True,
    "attention_key": "{attention_key}",
    "epochs": int({epochs}),
    "experiment_key": "ce_asl_ldam_top10_attention_20runs_windows6gb",
    "experiment_group": "{arm['arm']}",
    "screening_note": "Windows 6GB run: {arm['label']} with top-10 custom CBAM-inspired attention. Fixed no-attention CE baseline is a reference, not rerun.",
    "windows6gb_mode": True,
}}
print("TRAIN_CONDITION", json.dumps(condition, indent=2))
result = train_yolo_with_fallback("{model_name}", condition, yolo_manifest, output_dir, resume=True, smoke_test={bool(smoke_test)}, progress_enabled=True)
variant_dir = output_dir / "variant_results"
variant_dir.mkdir(parents=True, exist_ok=True)
write_json(variant_dir / "{arm['arm']}_{attention_key}.json", {{
    "status": "completed",
    "arm": "{arm['arm']}",
    "loss_key": "{arm['loss_key']}",
    "attention_key": "{attention_key}",
    "epochs": int({epochs}),
    "result": result,
}})
print("VARIANT_COMPLETED", "{arm['arm']}", "{attention_key}")
'''.lstrip()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(script, encoding="utf-8")


def plan_rows() -> list[dict[str, Any]]:
    rows = []
    idx = 1
    for arm in ARMS:
        for key in TOP10:
            rows.append({"run_index": idx, **arm, "attention_key": key})
            idx += 1
    return rows


def write_plan_csv(output_dir: Path, rows: list[dict[str, Any]]) -> None:
    p = output_dir / "final_reports" / "planned_20runs.csv"
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


def read_json_safe(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def collect_summary(output_dir: Path) -> dict[str, Any]:
    reports = output_dir / "final_reports"
    reports.mkdir(parents=True, exist_ok=True)
    variant_files = sorted((output_dir / "variant_results").glob("*.json")) if (output_dir / "variant_results").exists() else []
    metrics_files = sorted(output_dir.rglob("metrics.json"))
    audit_files = sorted(output_dir.rglob("attention_module_audit.json"))
    rows = []
    for vf in variant_files:
        obj = read_json_safe(vf) or {}
        row = {
            "variant_file": str(vf),
            "status": obj.get("status"),
            "arm": obj.get("arm"),
            "loss_key": obj.get("loss_key"),
            "attention_key": obj.get("attention_key"),
            "epochs": obj.get("epochs"),
        }
        result = obj.get("result") if isinstance(obj.get("result"), dict) else {}
        for k in ["run_dir", "metrics_path", "run_id", "test_macro_f1", "test_accuracy", "cohen_kappa", "best_checkpoint"]:
            if k in result:
                row[k] = result[k]
        rows.append(row)
    csv_path = reports / "completed_variant_results.csv"
    if rows:
        keys = sorted(set().union(*[r.keys() for r in rows]))
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader(); w.writerows(rows)
    summary = {
        "timestamp": now_iso(),
        "planned_runs": 20,
        "completed_variant_files": len(variant_files),
        "metrics_files": len(metrics_files),
        "attention_audit_files": len(audit_files),
        "reference": REFERENCE,
        "completed_variant_csv": str(csv_path),
        "output_dir": str(output_dir),
    }
    write_json(reports / "summary.json", summary)
    return summary


def zip_review(output_dir: Path, review_zip: Path, extra_files: list[Path]) -> None:
    exclude_parts = {"weights", "yolo_fixed_dataset", "__pycache__", ".git"}
    exclude_suffix = {".pt", ".pth", ".onnx", ".engine", ".png", ".jpg", ".jpeg", ".webp"}
    with zipfile.ZipFile(review_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in extra_files:
            if p.exists() and p.is_file():
                z.write(p, arcname=p.name)
        if output_dir.exists():
            for p in output_dir.rglob("*"):
                if not p.is_file():
                    continue
                if any(part in exclude_parts for part in p.parts):
                    continue
                if p.suffix.lower() in exclude_suffix:
                    continue
                z.write(p, arcname=str(p.relative_to(output_dir.parent)))
    print("Review ZIP:", review_zip, "size_MB=", round(review_zip.stat().st_size / 1024 / 1024, 3))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project_dir", required=True)
    ap.add_argument("--output_dir", required=True)
    ap.add_argument("--local_dataset_root", required=True)
    ap.add_argument("--patch_injection_script", required=True)
    ap.add_argument("--patch_attention_script", required=True)
    ap.add_argument("--work_project_dir", required=True)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--start", type=int, default=1)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--model_name", default="yolo26m-cls")
    ap.add_argument("--force_project_copy", action="store_true")
    ap.add_argument("--stop_on_failure", action="store_true")
    ap.add_argument("--smoke_test", action="store_true")
    ap.add_argument("--windows6gb_mode", action="store_true")
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--skip_prepare", action="store_true")
    ap.add_argument("--skip_selftests", action="store_true")
    args = ap.parse_args()

    project_dir = Path(args.project_dir).resolve()
    output_dir = Path(args.output_dir).resolve()
    dataset_root = Path(args.local_dataset_root).resolve()
    work_project = Path(args.work_project_dir).resolve()
    log_dir = output_dir / "notebook_command_logs"
    output_dir.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["LOCAL_DATASET_ROOT"] = str(dataset_root)
    env["SHRIMP_DATASET_ROOT"] = str(dataset_root)
    env["PYTORCH_CUDA_ALLOC_CONF"] = env.get("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True,max_split_size_mb:128")
    env["CVIO_WINDOWS6GB_MODE"] = "1" if args.windows6gb_mode else env.get("CVIO_WINDOWS6GB_MODE", "0")
    env["YOLO_ATTENTION_SCREEN_EPOCHS"] = str(args.epochs)

    copy_project(project_dir, work_project, force=args.force_project_copy)
    write_kagglehub_override(work_project, dataset_root)

    config_audit = None
    if args.windows6gb_mode:
        config_audit = patch_windows6gb_config(work_project, args.batch, args.workers)
        write_json(output_dir / "windows6gb_config_patch_audit.json", config_audit)

    write_json(output_dir / "run_context.json", {
        "timestamp": now_iso(),
        "project_dir": str(project_dir),
        "work_project_dir": str(work_project),
        "output_dir": str(output_dir),
        "local_dataset_root": str(dataset_root),
        "epochs": args.epochs,
        "start": args.start,
        "limit": args.limit,
        "model_name": args.model_name,
        "windows6gb_mode": args.windows6gb_mode,
        "batch": args.batch,
        "workers": args.workers,
        "reference": REFERENCE,
        "config_audit": config_audit,
    })

    run_cmd([sys.executable, "-m", "compileall", "shrimp_scripts", "experiments"], work_project, log_dir / "000_compileall_before.log", env, check=True)

    if not args.skip_prepare:
        prep = work_project / "shrimp_scripts" / "run_01_prepare_dataset.py"
        run_cmd([sys.executable, str(prep), "--output_dir", str(output_dir), "--resume", "--progress"], work_project, log_dir / "010_prepare_dataset.log", env, check=True)

    run_cmd([sys.executable, str(Path(args.patch_injection_script).resolve()), "--project_dir", str(work_project), "--run_compileall"], Path.cwd(), log_dir / "020_patch_attention_injection.log", env, check=True)
    run_cmd([sys.executable, str(Path(args.patch_attention_script).resolve()), "--project_dir", str(work_project), "--run_compileall"], Path.cwd(), log_dir / "021_patch_top10_attention.log", env, check=True)

    if not args.skip_selftests:
        mod_test, inj_test, loss_test = generate_selftest_scripts(output_dir, args.model_name)
        run_cmd([sys.executable, str(mod_test)], work_project, log_dir / "030_top10_attention_module_selftest.log", env, check=True)
        run_cmd([sys.executable, str(inj_test)], work_project, log_dir / "031_top10_attention_injection_selftest.log", env, check=True)
        run_cmd([sys.executable, str(loss_test)], work_project, log_dir / "032_asl_ldam_margin_selfcheck.log", env, check=True)

    rows = plan_rows()
    write_plan_csv(output_dir, rows)
    start_idx = max(1, int(args.start))
    selected = rows[start_idx - 1:]
    if args.limit and args.limit > 0:
        selected = selected[: int(args.limit)]
    print(f"Selected runs: {start_idx}..{start_idx + len(selected) - 1} of {len(rows)}")
    if not selected:
        raise RuntimeError("No selected runs. Check --start/--limit.")

    failed = []
    for row in selected:
        arm = {"arm": row["arm"], "loss_key": row["loss_key"], "label": row["label"]}
        attention_key = row["attention_key"]
        print("\n" + "="*100)
        print(f"RUN {row['run_index']:02d}/20 :: {arm['arm']} :: loss={arm['loss_key']} :: attention={attention_key}")
        script_path = output_dir / "generated_train_scripts" / f"run_{arm['arm']}_{attention_key}.py"
        generate_train_script(script_path, work_project, output_dir, arm, attention_key, args.epochs, args.model_name, args.smoke_test)
        rc = run_cmd([sys.executable, str(script_path)], work_project, log_dir / f"train_{arm['arm']}_{attention_key}.log", env, check=False)
        if rc != 0:
            failed.append({"run_index": row["run_index"], "arm": arm["arm"], "loss_key": arm["loss_key"], "attention_key": attention_key, "return_code": rc})
            write_json(output_dir / "failed_runs" / f"{arm['arm']}_{attention_key}.json", failed[-1])
            if args.stop_on_failure:
                summary = collect_summary(output_dir)
                write_json(output_dir / "final_reports" / "failed_runs.json", failed)
                raise RuntimeError(f"Variant failed and --stop_on_failure is set: {arm['arm']} + {attention_key}. See logs.")

    summary = collect_summary(output_dir)
    write_json(output_dir / "final_reports" / "failed_runs.json", failed)
    if selected and summary.get("completed_variant_files", 0) == 0:
        raise RuntimeError("No variants completed. Refusing to create a misleading success result.")

    review_zip = output_dir.parent / "ce_asl_ldam_top10_attention_20runs_windows6gb_for_review.zip"
    zip_review(output_dir, review_zip, [Path(__file__).resolve(), Path(args.patch_injection_script).resolve(), Path(args.patch_attention_script).resolve()])
    print("SUMMARY")
    print(json.dumps(summary, indent=2, default=str))
    print("DONE")
    print("Review ZIP:", review_zip)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
