
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

TOP10_BLOCK = r'''

# === CVIO_WINDOWS6GB_TOP10_CUSTOM_CBAM_BEGIN ===
# Top-10 repo-local CBAM-inspired attention modules for internal screening.
# These are NOT official paper implementations. Report them as repo-local variants.
import torch as _attention_torch
import torch.nn as _attention_nn
import torch.nn.functional as _attention_F

class _CVioConvBNAct(_attention_nn.Sequential):
    def __init__(self, c1, c2, k=1, s=1, p=None, groups=1):
        if p is None:
            p = k // 2
        super().__init__(
            _attention_nn.Conv2d(c1, c2, k, s, p, groups=groups, bias=False),
            _attention_nn.BatchNorm2d(c2),
            _attention_nn.SiLU(inplace=True),
        )

class _CVioChannelGate(_attention_nn.Module):
    def __init__(self, channels, reduction=16, use_eca=False):
        super().__init__()
        hidden = max(8, channels // reduction)
        self.mlp = _attention_nn.Sequential(
            _attention_nn.Conv2d(channels, hidden, 1, bias=False),
            _attention_nn.SiLU(inplace=True),
            _attention_nn.Conv2d(hidden, channels, 1, bias=False),
        )
        self.use_eca = bool(use_eca)
        self.eca = _attention_nn.Conv1d(1, 1, kernel_size=3, padding=1, bias=False) if self.use_eca else None
    def forward(self, x):
        avg = self.mlp(_attention_F.adaptive_avg_pool2d(x, 1))
        mx = self.mlp(_attention_F.adaptive_max_pool2d(x, 1))
        out = avg + mx
        if self.eca is not None:
            y = _attention_F.adaptive_avg_pool2d(x, 1).squeeze(-1).transpose(-1, -2)
            y = self.eca(y).transpose(-1, -2).unsqueeze(-1)
            out = out + y
        return _attention_torch.sigmoid(out)

class _CVioSpatialGate(_attention_nn.Module):
    def __init__(self, kernel_size=7):
        super().__init__()
        self.conv = _attention_nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False)
    def forward(self, x):
        avg = _attention_torch.mean(x, dim=1, keepdim=True)
        mx = _attention_torch.amax(x, dim=1, keepdim=True)
        return _attention_torch.sigmoid(self.conv(_attention_torch.cat([avg, mx], dim=1)))

class _CVioCBAMLite(_attention_nn.Module):
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels, reduction=16, spatial_kernel=7, use_eca=False):
        super().__init__()
        self.channel = _CVioChannelGate(channels, reduction=reduction, use_eca=use_eca)
        self.spatial = _CVioSpatialGate(spatial_kernel)
    def forward(self, x):
        return x * self.channel(x) * self.spatial(x)

class DynamicMultiScaleGatedCBAMLite(_attention_nn.Module):
    implementation_source = "repo_local_cbam_inspired_dmsca_lgf_lite"
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels):
        super().__init__()
        hidden = max(8, channels // 16)
        self.b1 = _attention_nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.b2 = _attention_nn.Conv2d(channels, channels, 5, padding=2, groups=channels, bias=False)
        self.gate = _attention_nn.Sequential(_attention_nn.AdaptiveAvgPool2d(1), _attention_nn.Conv2d(channels, hidden, 1), _attention_nn.SiLU(), _attention_nn.Conv2d(hidden, 2, 1))
        self.cbam = _CVioCBAMLite(channels)
    def forward(self, x):
        g = _attention_torch.softmax(self.gate(x), dim=1)
        y = self.b1(x) * g[:, 0:1] + self.b2(x) * g[:, 1:2]
        return self.cbam(x + y)

class NAMCBAMLite(_CVioCBAMLite):
    implementation_source = "repo_local_cbam_inspired_nam_lite"
    def __init__(self, channels):
        super().__init__(channels, reduction=32, spatial_kernel=7, use_eca=False)
        self.nam_scale = _attention_nn.Parameter(_attention_torch.ones(1, channels, 1, 1))
    def forward(self, x):
        return super().forward(x * _attention_torch.sigmoid(self.nam_scale))

class LocalBlockPoolingCBAMLite(_attention_nn.Module):
    implementation_source = "repo_local_cbam_inspired_local_pooling"
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels):
        super().__init__()
        self.local = _attention_nn.AvgPool2d(3, stride=1, padding=1)
        self.cbam = _CVioCBAMLite(channels)
    def forward(self, x):
        return self.cbam(x + self.local(x))

class DirectionalStripeCBAM(_attention_nn.Module):
    implementation_source = "repo_local_cbam_inspired_directional_stripe"
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels):
        super().__init__()
        self.channel = _CVioChannelGate(channels)
        self.hconv = _attention_nn.Conv2d(1, 1, (1, 7), padding=(0, 3), bias=False)
        self.vconv = _attention_nn.Conv2d(1, 1, (7, 1), padding=(3, 0), bias=False)
    def forward(self, x):
        y = x * self.channel(x)
        avg = _attention_torch.mean(y, dim=1, keepdim=True)
        s = _attention_torch.sigmoid(self.hconv(avg) + self.vconv(avg))
        return y * s

class ECANAMSpatialCBAM(_CVioCBAMLite):
    implementation_source = "repo_local_cbam_inspired_eca_nam_spatial"
    def __init__(self, channels):
        super().__init__(channels, reduction=32, spatial_kernel=7, use_eca=True)

class GAMLiteCBAMNoPoolSpatial(_attention_nn.Module):
    implementation_source = "repo_local_cbam_inspired_gam_lite"
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels):
        super().__init__()
        hidden = max(16, channels // 4)
        self.channel = _attention_nn.Sequential(_attention_nn.Conv2d(channels, hidden, 1), _attention_nn.SiLU(), _attention_nn.Conv2d(hidden, channels, 1))
        self.spatial = _attention_nn.Sequential(_attention_nn.Conv2d(channels, channels, 3, padding=1, groups=channels), _attention_nn.SiLU(), _attention_nn.Conv2d(channels, 1, 1))
    def forward(self, x):
        return x * _attention_torch.sigmoid(self.channel(x)) * _attention_torch.sigmoid(self.spatial(x))

class BinaryGatedCBAMLite(_attention_nn.Module):
    implementation_source = "repo_local_cbam_inspired_binary_gate"
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels):
        super().__init__()
        self.cbam = _CVioCBAMLite(channels)
        self.logit = _attention_nn.Parameter(_attention_torch.zeros(1))
    def forward(self, x):
        soft = self.cbam(x)
        gate = _attention_torch.sigmoid(self.logit)
        return x * (1 - gate) + soft * gate

class EMAGroupedCBAM(_attention_nn.Module):
    implementation_source = "repo_local_cbam_inspired_ema_grouped"
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels, groups=8):
        super().__init__()
        g = min(groups, channels)
        while channels % g != 0 and g > 1:
            g -= 1
        self.groups = g
        self.conv = _attention_nn.Conv2d(channels, channels, 3, padding=1, groups=g, bias=False)
        self.channel = _CVioChannelGate(channels, reduction=32)
    def forward(self, x):
        y = self.conv(x)
        return x + y * self.channel(y)

class SparseLearnableFusionCBAM(_attention_nn.Module):
    implementation_source = "repo_local_cbam_inspired_sparse_fusion"
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels):
        super().__init__()
        self.a = _CVioCBAMLite(channels, reduction=16, spatial_kernel=7)
        self.b = _CVioCBAMLite(channels, reduction=32, spatial_kernel=3, use_eca=True)
        self.w = _attention_nn.Parameter(_attention_torch.zeros(2))
    def forward(self, x):
        w = _attention_torch.softmax(self.w, dim=0)
        return w[0] * self.a(x) + w[1] * self.b(x)

class TwoStepIterativeCBAMLite(_attention_nn.Module):
    implementation_source = "repo_local_cbam_inspired_iterative_refinement"
    implementation_variant = "experimental_repo_local_custom_cbam_inspired"
    is_exact_official_implementation = False
    attention_family = "custom_cbam_inspired_top10"
    def __init__(self, channels):
        super().__init__()
        self.cbam = _CVioCBAMLite(channels)
    def forward(self, x):
        return self.cbam(self.cbam(x))

_TOP10_CUSTOM_CBAM_REGISTRY = {
    "dynamic_multiscale_gated_cbam_lite": DynamicMultiScaleGatedCBAMLite,
    "nam_cbam_lite": NAMCBAMLite,
    "local_block_pooling_cbam_lite": LocalBlockPoolingCBAMLite,
    "directional_stripe_cbam": DirectionalStripeCBAM,
    "eca_nam_spatial_cbam": ECANAMSpatialCBAM,
    "gam_lite_cbam_no_pool_spatial": GAMLiteCBAMNoPoolSpatial,
    "binary_gated_cbam_lite": BinaryGatedCBAMLite,
    "ema_grouped_cbam": EMAGroupedCBAM,
    "sparse_learnable_fusion_cbam": SparseLearnableFusionCBAM,
    "two_step_iterative_cbam_lite": TwoStepIterativeCBAMLite,
}

def attention_keys():
    return list(_TOP10_CUSTOM_CBAM_REGISTRY.keys())

def attention_is_baseline(attention_key):
    return attention_key in (None, "", "none", "none_baseline", "baseline")

def build_attention_module(attention_key, channels, **kwargs):
    if attention_is_baseline(attention_key):
        return _attention_nn.Identity()
    if attention_key not in _TOP10_CUSTOM_CBAM_REGISTRY:
        raise KeyError(f"Unknown top-10 custom attention key: {attention_key!r}; available={attention_keys()}")
    return _TOP10_CUSTOM_CBAM_REGISTRY[attention_key](int(channels))

def make_attention_module(attention_key, channels, **kwargs):
    return build_attention_module(attention_key, channels, **kwargs)

def make_attention(attention_key, channels, **kwargs):
    return build_attention_module(attention_key, channels, **kwargs)

def create_attention_module(attention_key, channels, **kwargs):
    return build_attention_module(attention_key, channels, **kwargs)

def get_attention_module(attention_key, channels, **kwargs):
    return build_attention_module(attention_key, channels, **kwargs)

def self_test_attention_modules(attention_key=None):
    keys = [attention_key] if attention_key else attention_keys()
    rows, errors = [], []
    for key in keys:
        try:
            module = build_attention_module(key, 512)
            module.eval()
            x = _attention_torch.randn(2, 512, 20, 20)
            with _attention_torch.no_grad():
                y = module(x)
            assert tuple(y.shape) == tuple(x.shape), (tuple(y.shape), tuple(x.shape))
            assert _attention_torch.isfinite(y).all().item(), "non-finite output"
            rows.append({
                "attention_key": key,
                "module_class": module.__class__.__name__,
                "params": int(sum(p.numel() for p in module.parameters())),
                "input_shape": list(x.shape),
                "output_shape": list(y.shape),
                "implementation_source": getattr(module, "implementation_source", "repo_local_custom_cbam_inspired"),
                "implementation_variant": getattr(module, "implementation_variant", "experimental_repo_local_custom_cbam_inspired"),
                "is_exact_official_implementation": bool(getattr(module, "is_exact_official_implementation", False)),
            })
        except Exception as exc:
            errors.append(f"{key}:{exc!r}")
            rows.append({"attention_key": key, "status": "failed", "error": repr(exc)})
    return {"status": "passed" if not errors else "failed", "rows": rows, "errors": errors}
# === CVIO_WINDOWS6GB_TOP10_CUSTOM_CBAM_END ===
'''

def patch_file(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    begin = "# === CVIO_WINDOWS6GB_TOP10_CUSTOM_CBAM_BEGIN ==="
    end = "# === CVIO_WINDOWS6GB_TOP10_CUSTOM_CBAM_END ==="
    if begin in text and end in text:
        pre = text.split(begin)[0].rstrip()
        post = text.split(end)[-1].lstrip()
        text = pre + "\n" + TOP10_BLOCK + "\n" + post
    else:
        text = text.rstrip() + "\n" + TOP10_BLOCK + "\n"
    path.write_text(text, encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project_dir", required=True)
    ap.add_argument("--run_compileall", action="store_true")
    args = ap.parse_args()
    project = Path(args.project_dir).resolve()
    target = project / "shrimp_scripts" / "attention.py"
    if not target.exists():
        raise SystemExit(f"Missing attention.py: {target}")
    backup = target.with_suffix(target.suffix + ".bak_top10_custom_windows_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
    shutil.copy2(target, backup)
    patch_file(target)
    print(f"Backup created: {backup}")
    print(f"Patched: {target}")
    if args.run_compileall:
        subprocess.check_call([sys.executable, "-m", "compileall", "shrimp_scripts", "experiments"], cwd=str(project))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
