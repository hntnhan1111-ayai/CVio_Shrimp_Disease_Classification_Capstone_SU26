
# CVio Windows 6GB YOLOv26m-cls CE/ASL-LDAM + Top-10 Custom Attention Pack

This pack is for the Windows GTX 1060 6GB machine (`nhan-6gb` branch) and is designed to be unzipped **after pulling the Git repo**.

## What it runs

Planned matrix: 20 variants.

- 10 runs: `yolo26m-cls` + `baseline_ce` + top-10 custom CBAM-inspired attention modules.
- 10 runs: `yolo26m-cls` + `asl_ldam_margin` + top-10 custom CBAM-inspired attention modules.

The fixed no-attention CE baseline remains a reference; this pack does **not** rerun the no-attention CE baseline unless the existing project pipeline does so internally.

## Important 6GB VRAM warning

The GTX 1060 6GB machine is for smoke/debug and conservative experiment execution. A full 20-run YOLOv26m-cls matrix can still OOM or take a long time. Default Windows settings in this pack are conservative:

- `batch=4` override where possible
- `workers=0` override where possible
- `imgsz=224`
- foreground logging through PowerShell `Tee-Object`
- `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True,max_split_size_mb:128`

For final paper-grade timing/metrics, prefer RTX 4090 or Kaggle T4x2.

## Files

- `final_yolo26m_ce_asl_ldam_top10_attention_windows6gb_runner.py` — main cross-platform runner.
- `patch_yolo_attention_injection_v2_windows_safe.py` — validates/adds safe attention injection helpers only when missing.
- `patch_top10_custom_cbam_attention_modules_windows_safe.py` — registers top-10 custom CBAM-inspired attention modules.
- `run_windows6gb_smoke.ps1` — one-run smoke test, foreground logs.
- `run_windows6gb_full_20runs.ps1` — full 20-run command, foreground logs.
- `windows6gb_env_check.ps1` — machine/GPU/Python diagnostics.

## Expected repo state before unzipping

PowerShell:

```powershell
cd C:\Users\ADMIN\Downloads\CVio_Shrimp_Disease_Classification_Capstone_SU26

git status
git branch --show-current
# expected branch: nhan-6gb
```

## Dataset location

The scripts expect a dataset root, default:

```text
C:\Users\ADMIN\Downloads\processed-images\processed_images
```

If your dataset is somewhere else, edit `$DATASET_ROOT` in the PowerShell scripts or pass `--local_dataset_root` manually.

## Output location

Default output directory:

```text
C:\Users\ADMIN\Downloads\cvio_windows6gb_outputs\ce_asl_ldam_top10_attention_20runs
```

After completion, upload the generated review ZIP:

```text
ce_asl_ldam_top10_attention_20runs_windows6gb_for_review.zip
```
