$ErrorActionPreference = "Continue"
$ROOT = "C:\Users\ADMIN\Downloads\CVio_Shrimp_Disease_Classification_Capstone_SU26"
Set-Location $ROOT
New-Item -ItemType Directory -Force setup_logs | Out-Null
systeminfo | Tee-Object setup_logs\systeminfo.txt
Get-CimInstance Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed | Format-List | Tee-Object setup_logs\cpu_info.txt
Get-CimInstance Win32_ComputerSystem | Select-Object TotalPhysicalMemory | Format-List | Tee-Object setup_logs\ram_info.txt
Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM, DriverVersion | Format-List | Tee-Object setup_logs\gpu_windows_info.txt
nvidia-smi | Tee-Object setup_logs\nvidia_smi.txt
nvidia-smi --query-gpu=name,memory.total,memory.free,driver_version --format=csv | Tee-Object setup_logs\nvidia_smi_query.txt
git --version | Tee-Object setup_logs\git_version.txt
uv --version | Tee-Object setup_logs\uv_version.txt
python --version 2>&1 | Tee-Object setup_logs\python_version.txt
python -c "import sys; print(sys.executable)" | Tee-Object setup_logs\python_executable.txt
python -c "import torch; print('torch', torch.__version__); print('cuda', torch.cuda.is_available()); print('cuda version', torch.version.cuda); print('gpu', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO CUDA'); print('vram GB', round(torch.cuda.get_device_properties(0).total_memory/1024**3,2) if torch.cuda.is_available() else 'NO CUDA')" | Tee-Object setup_logs\torch_cuda_check.txt
