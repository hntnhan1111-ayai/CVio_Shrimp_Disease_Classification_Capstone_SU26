$ErrorActionPreference = "Stop"
$ROOT = "C:\Users\ADMIN\Downloads\CVio_Shrimp_Disease_Classification_Capstone_SU26"
$DATASET_ROOT = "C:\Users\ADMIN\Downloads\processed-images\processed_images"
$OUTPUT_ROOT = "C:\Users\ADMIN\Downloads\cvio_windows6gb_outputs"
$OUT = Join-Path $OUTPUT_ROOT "ce_asl_ldam_top10_attention_20runs"
$WORK = Join-Path $OUTPUT_ROOT "CE_ASL_LDAM_TOP10_ATTENTION_20RUNS_run_project"

Set-Location $ROOT
$env:PYTORCH_CUDA_ALLOC_CONF = "expandable_segments:True,max_split_size_mb:128"
$env:PYTHONUNBUFFERED = "1"
$env:CUDA_VISIBLE_DEVICES = "0"

python .\final_yolo26m_ce_asl_ldam_top10_attention_windows6gb_runner.py `
  --project_dir $ROOT `
  --output_dir $OUT `
  --local_dataset_root $DATASET_ROOT `
  --patch_injection_script (Join-Path $ROOT "patch_yolo_attention_injection_v2_windows_safe.py") `
  --patch_attention_script (Join-Path $ROOT "patch_top10_custom_cbam_attention_modules_windows_safe.py") `
  --work_project_dir $WORK `
  --epochs 30 `
  --start 1 `
  --limit 0 `
  --model_name "yolo26m-cls" `
  --force_project_copy `
  --windows6gb_mode `
  --batch 4 `
  --workers 0 `
  2>&1 | Tee-Object (Join-Path $ROOT "ce_asl_ldam_top10_attention_windows6gb_FULL_live.log")
