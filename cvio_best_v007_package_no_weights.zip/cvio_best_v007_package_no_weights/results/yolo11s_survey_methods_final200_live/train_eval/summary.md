# YOLO11s Survey-Method Training/Eval Summary

- Calibrated anchor mAP50: `0.157789`
- Calibrated anchor mAP50-95: `0.043617`
- Total eval rows: `30`
- Winners over anchor on both metrics: `1`

## Top test rows

| id | data | imgsz | conf | iou | max_det | map50 | map50_95 | map75 | precision | recall | _delta_map50 | _delta_map50_95 | elapsed_sec |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Y11_BASELINE_LOCKED_test_best5095_iou055 | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1280.000000 | 0.000500 | 0.550000 | 600.000000 | 0.158088 | 0.044099 | 0.008204 | 0.256114 | 0.272020 | 0.000299 | 0.000482 | 0.982370 |
| Y11_ORIGINAL_STRONGAUG_1280_test_best5095_iou055 | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1280.000000 | 0.000500 | 0.550000 | 600.000000 | 0.145754 | 0.043278 | 0.013992 | 0.213967 | 0.254147 | -0.012035 | -0.000339 | 1.011612 |
| Y11_BASELINE_LOCKED_test_calib_iou050 | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1280.000000 | 0.000500 | 0.500000 | 600.000000 | 0.159602 | 0.043256 | 0.008035 | 0.257362 | 0.272624 | 0.001813 | -0.000361 | 0.970355 |
| Y11_ORIGINAL_STRONGAUG_1280_test_calib_iou050 | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1280.000000 | 0.000500 | 0.500000 | 600.000000 | 0.147287 | 0.043032 | 0.013399 | 0.221761 | 0.251901 | -0.010502 | -0.000585 | 1.083311 |
| Y11_SR_LANCZOS_X2_1280_test_best5095_iou055 | /home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200_live/sr_x2/data.yaml | 1280.000000 | 0.000500 | 0.550000 | 600.000000 | 0.162259 | 0.042378 | 0.007996 | 0.274411 | 0.275897 | 0.004470 | -0.001239 | 1.750142 |
| Y11_SR_LANCZOS_X2_1280_test_calib_iou050 | /home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200_live/sr_x2/data.yaml | 1280.000000 | 0.000500 | 0.500000 | 600.000000 | 0.163173 | 0.042094 | 0.007833 | 0.277337 | 0.275897 | 0.005384 | -0.001523 | 1.784631 |
| Y11_ORIGINAL_STRONGAUG_1280_test_old_anchor | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1024.000000 | 0.001000 | 0.700000 | 300.000000 | 0.129542 | 0.039069 | 0.013982 | 0.208827 | 0.232131 | -0.028247 | -0.004548 | 0.883811 |
| Y11_SR_LANCZOS_X2_1280_test_old_anchor | /home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200_live/sr_x2/data.yaml | 1024.000000 | 0.001000 | 0.700000 | 300.000000 | 0.143377 | 0.037976 | 0.009146 | 0.255265 | 0.215756 | -0.014412 | -0.005641 | 1.687920 |
| Y11_BASELINE_LOCKED_test_old_anchor | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1024.000000 | 0.001000 | 0.700000 | 300.000000 | 0.131038 | 0.037332 | 0.009884 | 0.227227 | 0.242171 | -0.026751 | -0.006285 | 0.884552 |
| Y11_TILEAWARE_640_eval_full_test_best5095_iou055 | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1280.000000 | 0.000500 | 0.550000 | 600.000000 | 0.123274 | 0.033388 | 0.006760 | 0.210040 | 0.243491 | -0.034515 | -0.010229 | 1.020036 |
| Y11_TILEAWARE_640_eval_full_test_calib_iou050 | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1280.000000 | 0.000500 | 0.500000 | 600.000000 | 0.121596 | 0.032604 | 0.006415 | 0.214005 | 0.237141 | -0.036193 | -0.011013 | 1.010906 |
| Y11_TILEAWARE_640_eval_full_test_old_anchor | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1024.000000 | 0.001000 | 0.700000 | 300.000000 | 0.114438 | 0.030777 | 0.005741 | 0.210503 | 0.204734 | -0.043351 | -0.012840 | 0.886168 |
| Y11_TILEAWARE_640_eval_tile_test_old_anchor | /home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200_live/tile640_ov0p35/data.yaml | 1024.000000 | 0.001000 | 0.700000 | 300.000000 | 0.102279 | 0.029939 | 0.007834 | 0.167574 | 0.228289 | -0.055510 | -0.013678 | 4.124582 |
| Y11_TILEAWARE_640_eval_tile_test_best5095_iou055 | /home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200_live/tile640_ov0p35/data.yaml | 1280.000000 | 0.000500 | 0.550000 | 600.000000 | 0.080978 | 0.021557 | 0.004568 | 0.139756 | 0.206625 | -0.076811 | -0.022060 | 4.939347 |
| Y11_TILEAWARE_640_eval_tile_test_calib_iou050 | /home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200_live/tile640_ov0p35/data.yaml | 1280.000000 | 0.000500 | 0.500000 | 600.000000 | 0.080877 | 0.021218 | 0.004318 | 0.140849 | 0.214249 | -0.076912 | -0.022399 | 4.968949 |

## Winners over YOLO11s calibrated

| id | data | imgsz | conf | iou | max_det | map50 | map50_95 | map75 | precision | recall | _delta_map50 | _delta_map50_95 | elapsed_sec |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Y11_BASELINE_LOCKED_test_best5095_iou055 | /home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml | 1280.000000 | 0.000500 | 0.550000 | 600.000000 | 0.158088 | 0.044099 | 0.008204 | 0.256114 | 0.272020 | 0.000299 | 0.000482 | 0.982370 |