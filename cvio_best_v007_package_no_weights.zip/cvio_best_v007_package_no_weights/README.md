# CVio YOLO11s Best V007 Experiment Package — No Weights / No Dataset Images

This package collects code, configs, result tables, logs, summaries, and result visualizations for the current best YOLO11s shrimp disease object detection experiments.

## Current best method from available results

- Method: `V007_C3k2SimAM_backbone_nomosaic_loc`
- mAP50: `0.163909`
- mAP50-95: `0.047748`

## Original YOLO11s baseline used for percentage-point comparison

- mAP50: `0.129`
- mAP50-95: `0.038`

## Exclusions

This package intentionally excludes:

- model weights: `.pt`, `.pth`, `.onnx`, `.engine`, `.tflite`
- raw dataset images
- raw YOLO label folders
- large train/val/test image folders

## Main folders

- `code/`: experiment scripts, custom modules, YAML configs, runners
- `results/`: CSV/MD/HTML/JSON/TXT/LOG outputs
- `visuals/`: YOLO result plots and curves only
- `dataset_metadata/`: data.yaml and small metadata files only
