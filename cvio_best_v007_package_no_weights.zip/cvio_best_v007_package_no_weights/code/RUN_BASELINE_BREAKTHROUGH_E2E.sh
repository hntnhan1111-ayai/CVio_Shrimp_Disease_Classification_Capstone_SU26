#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:$PWD/tools_paper_diag:$PWD/tools_baseline_breakthrough:${PYTHONPATH:-}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"
BASELINE_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt"
OUT_DIR="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_breakthrough_results"

# Optional:
# Nếu đã có label-refined v2 thì export DATA_V2_YAML trước khi chạy.
# Ví dụ:
# export DATA_V2_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15_v2/data.yaml"
DATA_V2_YAML="${DATA_V2_YAML:-}"

# Optional:
# Nếu có teacher mạnh hơn thì export TEACHER_WEIGHTS trước khi chạy.
# Ví dụ:
# export TEACHER_WEIGHTS="/home/drnguyenvinh/notebooks/teachers/yolo11m_shrimp_best.pt"
TEACHER_WEIGHTS="${TEACHER_WEIGHTS:-}"

mkdir -p "$OUT_DIR"

echo "===== ENV CHECK ====="
echo "DATA_YAML=$DATA_YAML"
echo "BASELINE_WEIGHTS=$BASELINE_WEIGHTS"
echo "OUT_DIR=$OUT_DIR"
echo "DATA_V2_YAML=$DATA_V2_YAML"
echo "TEACHER_WEIGHTS=$TEACHER_WEIGHTS"

test -f "$DATA_YAML"
test -f "$BASELINE_WEIGHTS"

echo
echo "===== INSTALL LIGHT DEPS IF NEEDED ====="
.venv/bin/python -m pip install -U pyyaml pillow numpy pandas tqdm tabulate >/dev/null

echo
echo "===== RUN BASELINE BREAKTHROUGH E2E ====="
.venv/bin/python tools_baseline_breakthrough/04_baseline_breakthrough_e2e.py \
  --data "$DATA_YAML" \
  --baseline "$BASELINE_WEIGHTS" \
  --out "$OUT_DIR" \
  --splits val,test \
  --device 0 \
  --run-fullres \
  --run-sahi \
  --run-nwd \
  --run-classwise \
  --run-audit \
  --run-teacher-audit \
  --teacher "$TEACHER_WEIGHTS" \
  --data-v2 "$DATA_V2_YAML" \
  --epochs 200 \
  --train-imgsz 1280 \
  --batch 2 \
  --lr0 0.0005 \
  --patience 30 \
  --anchor-map50 0.157330 \
  --anchor-map50-95 0.043496

echo
echo "===== FINAL SUMMARY ====="
cat "$OUT_DIR/summary.md"

echo
echo "===== WINNERS OVER FAIR BASELINE @1280 ====="
cat "$OUT_DIR/winners_over_fair_baseline_1280.csv" || true

echo
echo "===== AUDIT HTML ====="
echo "$OUT_DIR/audit/AUDIT_BL1280_iou050_md1000/index.html"
