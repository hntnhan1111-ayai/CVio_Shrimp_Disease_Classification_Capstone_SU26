#!/usr/bin/env bash
set -u

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:$PWD/tools_paper_diag:$PWD/tools_yolo11_survey_methods:${PYTHONPATH:-}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"
YOLO11S_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt"

OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200_live"
AUDIT_CSV="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/parallel_yolo11s_yolo26n_all_ideas/yolo11s_all_ideas/audit/AUDIT_BL1280_iou050_md1000/audit_queue.csv"

TILE_SIZE="${TILE_SIZE:-640}"
TILE_OVERLAP="${TILE_OVERLAP:-0.35}"
EPOCHS="${EPOCHS:-200}"
FINAL_EPOCHS="${FINAL_EPOCHS:-200}"
BATCH_FULL="${BATCH_FULL:-2}"
BATCH_TILE="${BATCH_TILE:-16}"
LR0="${LR0:-0.0005}"

mkdir -p "$OUT_ROOT/logs"

STATUS_LOG="$OUT_ROOT/logs/status.tsv"
echo -e "stage\tstatus\ttime" > "$STATUS_LOG"

log_stage() {
  echo -e "$1\t$2\t$(date '+%F %T')" | tee -a "$STATUS_LOG"
}

run_stage() {
  local stage="$1"
  shift

  echo
  echo "============================================================"
  echo "RUN STAGE: $stage"
  echo "============================================================"
  log_stage "$stage" "START"

  "$@" 2>&1 | tee "$OUT_ROOT/logs/${stage}.log"
  local code=${PIPESTATUS[0]}

  if [ "$code" -eq 0 ]; then
    log_stage "$stage" "OK"
    echo "[OK] $stage"
  else
    log_stage "$stage" "ERROR_CODE_${code}"
    echo "[ERROR] $stage code=$code"
    echo "Log: $OUT_ROOT/logs/${stage}.log"
  fi

  return 0
}

echo "===== PATH CHECK ====="
echo "DATA_YAML=$DATA_YAML"
echo "YOLO11S_WEIGHTS=$YOLO11S_WEIGHTS"
echo "OUT_ROOT=$OUT_ROOT"
echo "AUDIT_CSV=$AUDIT_CSV"
echo "TILE_SIZE=$TILE_SIZE"
echo "TILE_OVERLAP=$TILE_OVERLAP"
echo "EPOCHS=$EPOCHS"
echo "FINAL_EPOCHS=$FINAL_EPOCHS"
echo "BATCH_FULL=$BATCH_FULL"
echo "BATCH_TILE=$BATCH_TILE"
echo "LR0=$LR0"

test -f "$DATA_YAML" || { echo "[FATAL] missing DATA_YAML"; exit 1; }
test -f "$YOLO11S_WEIGHTS" || { echo "[FATAL] missing YOLO11S_WEIGHTS"; exit 1; }

echo
echo "===== INSTALL LIGHT DEPS ====="
.venv/bin/python -m pip install -U pandas pyyaml pillow numpy tqdm tabulate >/dev/null

echo
echo "===== VERIFY PYTHON SCRIPTS ====="
test -f tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py || { echo "[FATAL] missing 06_prepare_yolo11s_survey_data.py"; exit 1; }
test -f tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py || { echo "[FATAL] missing 07_train_eval_yolo11s_survey_methods.py"; exit 1; }

.venv/bin/python -m py_compile tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py || exit 1
.venv/bin/python -m py_compile tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py || exit 1

echo
echo "===== 1) MAKE LABEL-V2 REVIEW PACK ====="
if [ -f "$AUDIT_CSV" ]; then
  run_stage "01_make_label_v2_review_pack" \
    .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
      --data "$DATA_YAML" \
      --out-root "$OUT_ROOT" \
      --audit-csv "$AUDIT_CSV" \
      --make-review \
      --topk 700
else
  echo "[WARN] audit CSV not found. Skip review pack."
fi

echo
echo "===== 2) MAKE TRUE TILE-AWARE DATASET ====="
run_stage "02_make_tile_dataset" \
  .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
    --data "$DATA_YAML" \
    --out-root "$OUT_ROOT" \
    --make-tiles \
    --tile "$TILE_SIZE" \
    --overlap "$TILE_OVERLAP" \
    --min-keep 0.30 \
    --min-box-px 2.0

echo
echo "===== 3) MAKE SUPER-RESOLUTION LANCZOS X2 DATASET ====="
run_stage "03_make_sr_lanczos_x2_dataset" \
  .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
    --data "$DATA_YAML" \
    --out-root "$OUT_ROOT" \
    --make-sr \
    --sr-scale 2

TILE_DATA="$OUT_ROOT/tile${TILE_SIZE}_ov${TILE_OVERLAP/./p}/data.yaml"
SR_DATA="$OUT_ROOT/sr_x2/data.yaml"
ACTIONS_CSV="$OUT_ROOT/label_v2_review_pack/manual_label_actions.csv"
LABEL_V2_DATA="$OUT_ROOT/shrimp_yolo_labels_v2/data.yaml"

echo
echo "===== 4) APPLY LABEL-V2 ACTIONS IF APPROVED ====="
if [ -f "$ACTIONS_CSV" ]; then
  APPROVED_COUNT="$(.venv/bin/python - <<PY
import pandas as pd
p="$ACTIONS_CSV"
df=pd.read_csv(p)
print(df["status"].astype(str).str.lower().isin(["done","apply","approved","yes"]).sum())
PY
)"
  echo "Approved label actions: $APPROVED_COUNT"

  if [ "$APPROVED_COUNT" -gt 0 ]; then
    run_stage "04_apply_label_v2_actions" \
      .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
        --data "$DATA_YAML" \
        --out-root "$OUT_ROOT" \
        --apply-actions \
        --actions-csv "$ACTIONS_CSV" \
        --label-v2-out "$OUT_ROOT/shrimp_yolo_labels_v2"
  else
    echo "[SKIP] No approved label-v2 actions yet."
  fi
else
  echo "[SKIP] ACTIONS_CSV not found."
fi

COMMON_ARGS=(
  --baseline "$YOLO11S_WEIGHTS"
  --data "$DATA_YAML"
  --out "$OUT_ROOT/train_eval"
  --device 0
  --epochs "$EPOCHS"
  --final-epochs "$FINAL_EPOCHS"
  --batch-full "$BATCH_FULL"
  --batch-tile "$BATCH_TILE"
  --lr0 "$LR0"
  --anchor-map50 0.157789
  --anchor-map50-95 0.043617
)

echo
echo "===== 5) TRAIN ORIGINAL STRONG AUG 200E ====="
run_stage "05_train_original_strongaug_200ep" \
  .venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py \
    "${COMMON_ARGS[@]}" \
    --run-original-strong

echo
echo "===== 6) TRAIN TRUE TILE-AWARE 200E ====="
if [ -f "$TILE_DATA" ]; then
  run_stage "06_train_tileaware_200ep" \
    .venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py \
      "${COMMON_ARGS[@]}" \
      --tile-data "$TILE_DATA" \
      --run-tile-train
else
  echo "[SKIP] TILE_DATA missing: $TILE_DATA"
fi

echo
echo "===== 7) TRAIN SR LANCZOS X2 200E ====="
if [ -f "$SR_DATA" ]; then
  run_stage "07_train_sr_lanczos_x2_200ep" \
    .venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py \
      "${COMMON_ARGS[@]}" \
      --sr-data "$SR_DATA" \
      --run-sr
else
  echo "[SKIP] SR_DATA missing: $SR_DATA"
fi

echo
echo "===== 8) TRAIN LABEL-V2 200E IF AVAILABLE ====="
if [ -f "$LABEL_V2_DATA" ]; then
  run_stage "08_train_labelv2_200ep" \
    .venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py \
      "${COMMON_ARGS[@]}" \
      --data-v2 "$LABEL_V2_DATA" \
      --run-label-v2
else
  echo "[SKIP] LABEL_V2_DATA missing. Review label actions first."
fi

echo
echo "===== FINAL STATUS ====="
cat "$STATUS_LOG"

echo
echo "===== FINAL SUMMARY ====="
if [ -f "$OUT_ROOT/train_eval/summary.md" ]; then
  cat "$OUT_ROOT/train_eval/summary.md"
else
  echo "[WARN] summary.md not found"
fi

echo
echo "===== OUTPUTS ====="
echo "OUT_ROOT=$OUT_ROOT"
echo "Review HTML=$OUT_ROOT/label_v2_review_pack/index.html"
echo "Manual actions CSV=$OUT_ROOT/label_v2_review_pack/manual_label_actions.csv"
echo "Tile data=$TILE_DATA"
echo "SR data=$SR_DATA"
echo "Training summary=$OUT_ROOT/train_eval/summary.md"
echo "Winners=$OUT_ROOT/train_eval/winners_over_yolo11s_calibrated.csv"
echo "Logs=$OUT_ROOT/logs"
