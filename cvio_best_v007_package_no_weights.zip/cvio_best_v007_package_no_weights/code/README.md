# CVio YOLO11s Full Method Zoo

Wrapper + registry + notebook for exhaustive YOLO11s improvement experiments on ShrimpDiseaseImageBD canonical BG/WSSV OD.

## Open notebook
`notebooks/shrimp_yolo11s_full_method_zoo.ipynb`

## Important
This scaffold registers every planned method. It does not fake unported methods. Variants requiring third-party module/YAML porting are marked clearly.

## Quick start
```bash
python scripts/run_zoo_from_registry.py
```
