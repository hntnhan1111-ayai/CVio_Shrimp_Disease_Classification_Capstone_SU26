from __future__ import annotations

import argparse
import csv
import html
import json
import math
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
from PIL import Image, ImageDraw
from ultralytics import YOLO

from common_diag import (
    resolve_split_images,
    load_gt_for_image,
    box_iou,
    voc_ap,
    get_class_names,
    md_table,
)

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


# ---------------------------
# CSV / resume helpers
# ---------------------------

def read_rows(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_rows(path: Path, rows: List[Dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = []
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def append_row(path: Path, row: Dict[str, Any]):
    rows = read_rows(path)
    rows.append(row)
    write_rows(path, rows)


def row_done(path: Path, exp_id: str) -> bool:
    for r in read_rows(path):
        if r.get("id") == exp_id and r.get("status") == "ok":
            return True
    return False


def fnum(x, default=float("nan")):
    try:
        return float(x)
    except Exception:
        return default


# ---------------------------
# Prediction helpers
# ---------------------------

def pred_from_result(result, image_name: str, xoff=0.0, yoff=0.0) -> List[Dict[str, Any]]:
    preds = []
    if result.boxes is None:
        return preds

    for i, b in enumerate(result.boxes):
        x1, y1, x2, y2 = [float(v) for v in b.xyxy[0].detach().cpu().tolist()]
        cls_id = int(b.cls.item())
        conf = float(b.conf.item())
        preds.append({
            "pred_id": f"{image_name}::pred{i}_{xoff}_{yoff}",
            "image_name": image_name,
            "cls": cls_id,
            "conf": conf,
            "xyxy": [x1 + xoff, y1 + yoff, x2 + xoff, y2 + yoff],
        })
    return preds


def full_predict(
    model,
    image_path: Path,
    imgsz: int,
    conf: float,
    iou: float,
    max_det: int,
    device: str,
) -> List[Dict[str, Any]]:
    r = model.predict(
        source=str(image_path),
        imgsz=imgsz,
        conf=conf,
        iou=iou,
        max_det=max_det,
        device=device,
        verbose=False,
    )[0]
    return pred_from_result(r, image_path.name)


def tile_coords(W: int, H: int, tile: int, overlap: float) -> List[Tuple[int, int, int, int]]:
    step = max(1, int(tile * (1.0 - overlap)))
    xs = list(range(0, max(W - tile + 1, 1), step))
    ys = list(range(0, max(H - tile + 1, 1), step))

    if not xs or xs[-1] != max(W - tile, 0):
        xs.append(max(W - tile, 0))
    if not ys or ys[-1] != max(H - tile, 0):
        ys.append(max(H - tile, 0))

    coords = []
    seen = set()
    for y in ys:
        for x in xs:
            x2 = min(x + tile, W)
            y2 = min(y + tile, H)
            key = (x, y, x2, y2)
            if key not in seen:
                seen.add(key)
                coords.append(key)
    return coords


def sliced_predict(
    model,
    image_path: Path,
    tile: int,
    overlap: float,
    conf: float,
    iou: float,
    max_det: int,
    device: str,
    include_full: bool,
    full_imgsz: int,
) -> List[Dict[str, Any]]:
    img = Image.open(image_path).convert("RGB")
    W, H = img.size
    all_preds = []

    if include_full:
        all_preds.extend(
            full_predict(
                model=model,
                image_path=image_path,
                imgsz=full_imgsz,
                conf=conf,
                iou=iou,
                max_det=max_det,
                device=device,
            )
        )

    coords = tile_coords(W, H, tile, overlap)
    for idx, (x1, y1, x2, y2) in enumerate(coords):
        crop = img.crop((x1, y1, x2, y2))
        arr = np.array(crop)
        r = model.predict(
            source=arr,
            imgsz=tile,
            conf=conf,
            iou=iou,
            max_det=max_det,
            device=device,
            verbose=False,
        )[0]
        all_preds.extend(pred_from_result(r, image_path.name, xoff=x1, yoff=y1))

    return all_preds


# ---------------------------
# Postprocess helpers
# ---------------------------

def area(box):
    x1, y1, x2, y2 = box
    return max(0.0, x2 - x1) * max(0.0, y2 - y1)


def intersection(a, b):
    x1 = max(a[0], b[0])
    y1 = max(a[1], b[1])
    x2 = min(a[2], b[2])
    y2 = min(a[3], b[3])
    return max(0.0, x2 - x1) * max(0.0, y2 - y1)


def ios(a, b):
    inter = intersection(a, b)
    denom = max(min(area(a), area(b)), 1e-9)
    return inter / denom


def nwd_similarity(a, b, C=32.0):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b

    acx = (ax1 + ax2) / 2.0
    acy = (ay1 + ay2) / 2.0
    bcx = (bx1 + bx2) / 2.0
    bcy = (by1 + by2) / 2.0

    aw = max(ax2 - ax1, 1e-6)
    ah = max(ay2 - ay1, 1e-6)
    bw = max(bx2 - bx1, 1e-6)
    bh = max(by2 - by1, 1e-6)

    dist = math.sqrt((acx - bcx) ** 2 + (acy - bcy) ** 2 + ((aw - bw) / 2) ** 2 + ((ah - bh) / 2) ** 2)
    return math.exp(-dist / C)


def match_score(a, b, metric: str, nwd_c: float):
    metric = metric.upper()
    if metric == "IOU":
        return box_iou(a, b)
    if metric == "IOS":
        return ios(a, b)
    if metric == "NWD":
        return nwd_similarity(a, b, C=nwd_c)
    raise ValueError(f"Unknown metric: {metric}")


def merge_group(group: List[Dict[str, Any]], method: str) -> Dict[str, Any]:
    group = sorted(group, key=lambda p: p["conf"], reverse=True)
    if method.upper() == "NMS":
        return dict(group[0])

    scores = np.array([max(float(p["conf"]), 1e-9) for p in group], dtype=np.float64)
    boxes = np.array([p["xyxy"] for p in group], dtype=np.float64)
    ws = scores / scores.sum()
    merged_box = (boxes * ws[:, None]).sum(axis=0).tolist()

    out = dict(group[0])
    out["xyxy"] = [float(v) for v in merged_box]
    out["conf"] = float(scores.max())
    out["merged_count"] = len(group)
    return out


def postprocess_predictions(
    preds: List[Dict[str, Any]],
    method: str = "GREEDYNMM",
    metric: str = "IOU",
    match_thr: float = 0.50,
    nwd_c: float = 32.0,
    tiny_only_nwd: bool = False,
    tiny_area: float = 1024.0,
) -> List[Dict[str, Any]]:
    if not preds:
        return []

    final = []
    by_img_cls = {}
    for p in preds:
        by_img_cls.setdefault((p["image_name"], p["cls"]), []).append(p)

    for _, ps in by_img_cls.items():
        ps = sorted(ps, key=lambda p: p["conf"], reverse=True)
        used = [False] * len(ps)

        for i, p in enumerate(ps):
            if used[i]:
                continue

            group = [p]
            used[i] = True

            for j in range(i + 1, len(ps)):
                if used[j]:
                    continue

                q = ps[j]
                current_metric = metric

                if metric.upper() == "NWD" and tiny_only_nwd:
                    if max(area(p["xyxy"]), area(q["xyxy"])) > tiny_area:
                        current_metric = "IOU"

                s = match_score(p["xyxy"], q["xyxy"], current_metric, nwd_c)
                if s >= match_thr:
                    group.append(q)
                    used[j] = True

            final.append(merge_group(group, method))

    return final


def apply_classwise_conf(preds: List[Dict[str, Any]], bg_conf: float, wssv_conf: float):
    out = []
    for p in preds:
        cls_id = int(p["cls"])
        thr = bg_conf if cls_id == 0 else wssv_conf
        if float(p["conf"]) >= thr:
            out.append(p)
    return out


# ---------------------------
# Evaluation
# ---------------------------

def collect_gts(images: List[Path]) -> List[Dict[str, Any]]:
    gts = []
    for img in images:
        for j, g in enumerate(load_gt_for_image(img)):
            x = dict(g)
            x["gt_id"] = f"{img.name}::gt{j}"
            x["image_name"] = img.name
            gts.append(x)
    return gts


def compute_ap(gts, preds, cls_id: int, iou_thr: float) -> float:
    gt_subset = [g for g in gts if int(g["cls"]) == cls_id]
    pred_subset = [p for p in preds if int(p["cls"]) == cls_id]

    n_gt = len(gt_subset)
    if n_gt == 0:
        return float("nan")

    gt_by_img = {}
    for g in gt_subset:
        gt_by_img.setdefault(g["image_name"], []).append(g)

    matched = set()
    pred_subset = sorted(pred_subset, key=lambda x: float(x["conf"]), reverse=True)

    tp, fp = [], []
    for p in pred_subset:
        best_iou = 0.0
        best_gt = None

        for g in gt_by_img.get(p["image_name"], []):
            if g["gt_id"] in matched:
                continue
            v = box_iou(p["xyxy"], g["xyxy"])
            if v > best_iou:
                best_iou = v
                best_gt = g

        if best_gt is not None and best_iou >= iou_thr:
            matched.add(best_gt["gt_id"])
            tp.append(1)
            fp.append(0)
        else:
            tp.append(0)
            fp.append(1)

    if not tp:
        return 0.0

    cum_tp, cum_fp = [], []
    a = b = 0
    for t, f in zip(tp, fp):
        a += t
        b += f
        cum_tp.append(a)
        cum_fp.append(b)

    rec = [x / n_gt for x in cum_tp]
    prec = [cum_tp[i] / max(cum_tp[i] + cum_fp[i], 1) for i in range(len(cum_tp))]
    return voc_ap(rec, prec)


def evaluate_predictions(gts, preds, class_names: Dict[int, str]) -> Dict[str, Any]:
    classes = sorted(set([int(g["cls"]) for g in gts]))
    thrs = [0.50 + 0.05 * i for i in range(10)]

    row = {
        "num_gt": len(gts),
        "num_pred": len(preds),
    }

    ap50s, ap75s, map5095s = [], [], []

    for cls_id in classes:
        ap50 = compute_ap(gts, preds, cls_id, 0.50)
        ap75 = compute_ap(gts, preds, cls_id, 0.75)
        aps = [compute_ap(gts, preds, cls_id, t) for t in thrs]
        aps = [x for x in aps if x == x]
        map5095 = sum(aps) / len(aps) if aps else float("nan")

        row[f"ap50_class_{cls_id}"] = ap50
        row[f"map50_95_class_{cls_id}"] = map5095

        ap50s.append(ap50)
        ap75s.append(ap75)
        map5095s.append(map5095)

    row["map50"] = sum(ap50s) / len(ap50s) if ap50s else float("nan")
    row["map75"] = sum(ap75s) / len(ap75s) if ap75s else float("nan")
    row["map50_95"] = sum(map5095s) / len(map5095s) if map5095s else float("nan")
    return row


# ---------------------------
# Ultralytics official eval
# ---------------------------

def ultra_val_row(
    exp_id: str,
    weights: str,
    data_yaml: str,
    split: str,
    imgsz: int,
    conf: float,
    iou: float,
    max_det: int,
    device: str,
    out_csv: Path,
    stage: str,
    exp_type: str,
):
    if row_done(out_csv, exp_id):
        print(f"[SKIP done] {exp_id}")
        return

    print(f"[RUN ULTRA] {exp_id}")
    t0 = time.time()
    model = YOLO(weights)
    r = model.val(
        data=data_yaml,
        split=split,
        imgsz=imgsz,
        conf=conf,
        iou=iou,
        max_det=max_det,
        device=device,
        plots=False,
        save_json=False,
        verbose=False,
    )

    maps = getattr(r.box, "maps", [])
    row = {
        "id": exp_id,
        "stage": stage,
        "type": exp_type,
        "split": split,
        "status": "ok",
        "weights": weights,
        "imgsz": imgsz,
        "conf": conf,
        "iou": iou,
        "max_det": max_det,
        "map50": float(r.box.map50),
        "map50_95": float(r.box.map),
        "map75": float(r.box.map75),
        "precision": float(r.box.mp),
        "recall": float(r.box.mr),
        "ap_class_0": float(maps[0]) if len(maps) > 0 else float("nan"),
        "ap_class_1": float(maps[1]) if len(maps) > 1 else float("nan"),
        "elapsed_sec": time.time() - t0,
    }
    append_row(out_csv, row)


# ---------------------------
# Custom experiment runners
# ---------------------------

def run_custom_eval(
    exp_id: str,
    weights: str,
    data_yaml: str,
    split: str,
    device: str,
    out_csv: Path,
    out_dir: Path,
    class_names: Dict[int, str],
    mode: str,
    imgsz: int = 1280,
    conf: float = 0.001,
    iou: float = 0.50,
    max_det: int = 1000,
    tile: int = 640,
    overlap: float = 0.35,
    include_full: bool = False,
    post_method: str = "GREEDYNMM",
    post_metric: str = "IOU",
    post_thr: float = 0.50,
    nwd_c: float = 32.0,
    classwise: Tuple[float, float] | None = None,
):
    if row_done(out_csv, exp_id):
        print(f"[SKIP done] {exp_id}")
        return

    print(f"[RUN CUSTOM] {exp_id}")
    t0 = time.time()
    images = resolve_split_images(data_yaml, split)
    gts = collect_gts(images)

    model = YOLO(weights)
    preds_all = []

    for i, img in enumerate(images):
        if i % 25 == 0:
            print(f"  {exp_id}: {i}/{len(images)}")

        if mode == "full":
            ps = full_predict(model, img, imgsz, conf, iou, max_det, device)
        elif mode == "sliced":
            ps = sliced_predict(
                model=model,
                image_path=img,
                tile=tile,
                overlap=overlap,
                conf=conf,
                iou=iou,
                max_det=max_det,
                device=device,
                include_full=include_full,
                full_imgsz=imgsz,
            )
        else:
            raise ValueError(mode)

        if classwise is not None:
            ps = apply_classwise_conf(ps, bg_conf=classwise[0], wssv_conf=classwise[1])

        ps = postprocess_predictions(
            ps,
            method=post_method,
            metric=post_metric,
            match_thr=post_thr,
            nwd_c=nwd_c,
            tiny_only_nwd=(post_metric.upper() == "NWD"),
        )
        preds_all.extend(ps)

    metrics = evaluate_predictions(gts, preds_all, class_names)

    pred_path = out_dir / f"{exp_id}_preds.jsonl"
    pred_path.parent.mkdir(parents=True, exist_ok=True)
    with pred_path.open("w", encoding="utf-8") as f:
        for p in preds_all:
            f.write(json.dumps(p) + "\n")

    row = {
        "id": exp_id,
        "stage": "CUSTOM",
        "type": mode,
        "split": split,
        "status": "ok",
        "weights": weights,
        "imgsz": imgsz,
        "conf": conf,
        "iou": iou,
        "max_det": max_det,
        "tile": tile if mode == "sliced" else "",
        "overlap": overlap if mode == "sliced" else "",
        "include_full": include_full,
        "post_method": post_method,
        "post_metric": post_metric,
        "post_thr": post_thr,
        "nwd_c": nwd_c,
        "classwise_bg_conf": classwise[0] if classwise else "",
        "classwise_wssv_conf": classwise[1] if classwise else "",
        "elapsed_sec": time.time() - t0,
        **metrics,
    }
    append_row(out_csv, row)


# ---------------------------
# Audit generation
# ---------------------------

def audit_predictions(
    exp_id: str,
    weights: str,
    data_yaml: str,
    split: str,
    device: str,
    out_dir: Path,
    imgsz: int,
    conf: float,
    iou: float,
    max_det: int,
    class_names: Dict[int, str],
    topk: int = 300,
):
    audit_dir = out_dir / "audit" / exp_id
    audit_dir.mkdir(parents=True, exist_ok=True)
    audit_csv = audit_dir / "audit_queue.csv"
    html_path = audit_dir / "index.html"

    if audit_csv.exists() and html_path.exists():
        print(f"[SKIP audit done] {exp_id}")
        return

    print(f"[RUN AUDIT] {exp_id}")
    images = resolve_split_images(data_yaml, split)
    model = YOLO(weights)

    rows = []
    image_map = {p.name: p for p in images}

    for idx, img in enumerate(images):
        if idx % 25 == 0:
            print(f"  audit {idx}/{len(images)}")

        gts = load_gt_for_image(img)
        for j, g in enumerate(gts):
            g["gt_id"] = f"{img.name}::gt{j}"
            g["image_name"] = img.name

        preds = full_predict(model, img, imgsz, conf, iou, max_det, device)

        matched_gt = set()

        for p in sorted(preds, key=lambda x: x["conf"], reverse=True):
            same = [g for g in gts if int(g["cls"]) == int(p["cls"])]
            other = [g for g in gts if int(g["cls"]) != int(p["cls"])]

            best_same_iou = 0.0
            best_same_gt = None
            for g in same:
                v = box_iou(p["xyxy"], g["xyxy"])
                if v > best_same_iou:
                    best_same_iou = v
                    best_same_gt = g

            best_other_iou = 0.0
            for g in other:
                best_other_iou = max(best_other_iou, box_iou(p["xyxy"], g["xyxy"]))

            if best_same_gt is not None and best_same_iou >= 0.50:
                event = "tp"
                matched_gt.add(best_same_gt["gt_id"])
            elif best_same_iou >= 0.10:
                event = "box_shift_or_low_iou"
            elif best_other_iou >= 0.30:
                event = "wrong_class"
            elif float(p["conf"]) >= 0.05:
                event = "possible_missing_label"
            else:
                event = "fp_other"

            x1, y1, x2, y2 = p["xyxy"]
            rows.append({
                "image_name": img.name,
                "event": event,
                "class_id": int(p["cls"]),
                "class_name": class_names.get(int(p["cls"]), str(p["cls"])),
                "conf": float(p["conf"]),
                "iou": best_same_iou,
                "other_class_iou": best_other_iou,
                "x1": x1,
                "y1": y1,
                "x2": x2,
                "y2": y2,
            })

        for g in gts:
            if g["gt_id"] not in matched_gt:
                x1, y1, x2, y2 = g["xyxy"]
                rows.append({
                    "image_name": img.name,
                    "event": "fn_missed_gt",
                    "class_id": int(g["cls"]),
                    "class_name": class_names.get(int(g["cls"]), str(g["cls"])),
                    "conf": "",
                    "iou": 0.0,
                    "other_class_iou": "",
                    "x1": x1,
                    "y1": y1,
                    "x2": x2,
                    "y2": y2,
                })

    write_rows(audit_csv, rows)

    severe = [r for r in rows if r["event"] in {
        "box_shift_or_low_iou",
        "possible_missing_label",
        "wrong_class",
        "fn_missed_gt",
    }]
    severe = sorted(
        severe,
        key=lambda r: (
            {"possible_missing_label": 0, "box_shift_or_low_iou": 1, "wrong_class": 2, "fn_missed_gt": 3}.get(r["event"], 9),
            -fnum(r.get("conf"), 0),
        )
    )[:topk]

    cards = []
    gallery_dir = audit_dir / "gallery"
    gallery_dir.mkdir(exist_ok=True)

    for k, r in enumerate(severe):
        img_path = image_map.get(r["image_name"])
        if img_path is None:
            continue

        img = Image.open(img_path).convert("RGB")
        draw = ImageDraw.Draw(img)
        x1, y1, x2, y2 = [float(r[z]) for z in ["x1", "y1", "x2", "y2"]]
        draw.rectangle([x1, y1, x2, y2], outline="red", width=4)
        draw.text((x1, max(0, y1 - 20)), f'{r["event"]} {r["class_name"]} {r["conf"]}', fill="red")

        out_img = gallery_dir / f"{k:04d}_{r['image_name']}"
        img.thumbnail((1200, 900))
        img.save(out_img)

        cards.append(f"""
        <div style="border:1px solid #ddd; padding:12px; margin:12px;">
          <h3>{html.escape(r["event"])} | {html.escape(r["image_name"])}</h3>
          <p>class={html.escape(str(r["class_name"]))}, conf={html.escape(str(r["conf"]))}, iou={html.escape(str(r["iou"]))}</p>
          <img src="gallery/{html.escape(out_img.name)}" style="max-width:100%; height:auto;">
        </div>
        """)

    html_text = f"""
    <html>
    <head><meta charset="utf-8"><title>{html.escape(exp_id)} audit</title></head>
    <body>
    <h1>{html.escape(exp_id)} audit queue</h1>
    <p>CSV: <code>{html.escape(str(audit_csv))}</code></p>
    {''.join(cards)}
    </body>
    </html>
    """
    html_path.write_text(html_text, encoding="utf-8")
    print(f"[DONE AUDIT] {audit_csv}")
    print(f"[DONE AUDIT] {html_path}")


# ---------------------------
# Label-v2 optional training
# ---------------------------

def train_label_v2_if_available(args, out_csv: Path):
    if not args.data_v2:
        print("[SKIP] DATA_V2_YAML not provided")
        return

    data_v2 = Path(args.data_v2)
    if not data_v2.exists():
        print(f"[SKIP] DATA_V2_YAML does not exist: {data_v2}")
        return

    exp_id = "BL_LABEL_V2_YOLO11s_train200"
    if row_done(out_csv, f"{exp_id}_test"):
        print(f"[SKIP done] {exp_id}")
        return

    print(f"[RUN TRAIN LABEL V2] {exp_id}")
    model = YOLO(args.baseline)
    project = Path(args.out) / "runs_train"

    results = model.train(
        data=str(data_v2),
        epochs=args.epochs,
        imgsz=args.train_imgsz,
        batch=args.batch,
        device=args.device,
        optimizer="AdamW",
        lr0=args.lr0,
        cos_lr=True,
        patience=args.patience,
        project=str(project),
        name=exp_id,
        exist_ok=True,
        seed=42,
        plots=True,
        verbose=True,
    )

    best = project / exp_id / "weights" / "best.pt"
    if not best.exists():
        append_row(out_csv, {
            "id": f"{exp_id}_test",
            "stage": "LABEL_V2",
            "type": "train",
            "split": "test",
            "status": "error_no_best_weight",
            "data_v2": str(data_v2),
        })
        return

    for split in ["val", "test"]:
        ultra_val_row(
            exp_id=f"{exp_id}_{split}_eval1280",
            weights=str(best),
            data_yaml=str(data_v2),
            split=split,
            imgsz=1280,
            conf=0.001,
            iou=0.50,
            max_det=1000,
            device=args.device,
            out_csv=out_csv,
            stage="LABEL_V2",
            exp_type="train_eval",
        )


# ---------------------------
# Summary
# ---------------------------

def make_summary(out_dir: Path, baseline_anchor_map50: float, baseline_anchor_map5095: float):
    csv_path = out_dir / "breakthrough_results.csv"
    rows = read_rows(csv_path)
    ok = [r for r in rows if r.get("status") == "ok"]

    for r in ok:
        r["_map50"] = fnum(r.get("map50"))
        r["_map50_95"] = fnum(r.get("map50_95"))
        r["_delta_map50_vs_anchor"] = r["_map50"] - baseline_anchor_map50
        r["_delta_map50_95_vs_anchor"] = r["_map50_95"] - baseline_anchor_map5095

    top_test = [r for r in ok if r.get("split") == "test"]
    top_test = sorted(top_test, key=lambda r: r["_map50_95"], reverse=True)

    winners = [
        r for r in top_test
        if r["_map50"] > baseline_anchor_map50 and r["_map50_95"] > baseline_anchor_map5095
    ]

    write_rows(out_dir / "ranked_test.csv", top_test)
    write_rows(out_dir / "winners_over_fair_baseline_1280.csv", winners)

    status_counts = {}
    for r in rows:
        status_counts[r.get("status", "NA")] = status_counts.get(r.get("status", "NA"), 0) + 1
    status_rows = [{"status": k, "count": v} for k, v in sorted(status_counts.items())]

    cols = [
        "id", "stage", "type", "split", "imgsz", "tile", "overlap",
        "include_full", "post_method", "post_metric", "post_thr",
        "conf", "iou", "max_det", "map50", "map50_95",
        "_delta_map50_vs_anchor", "_delta_map50_95_vs_anchor",
        "num_gt", "num_pred", "elapsed_sec",
    ]

    md = []
    md.append("# Baseline Breakthrough E2E Summary\n")
    md.append(f"- Fair baseline anchor test mAP50: `{baseline_anchor_map50}`")
    md.append(f"- Fair baseline anchor test mAP50-95: `{baseline_anchor_map5095}`")
    md.append(f"- Total rows: `{len(rows)}`")
    md.append(f"- OK rows: `{len(ok)}`")
    md.append(f"- Winners over fair baseline @1280: `{len(winners)}`\n")

    md.append("## Status counts\n")
    md.append(md_table(status_rows, ["status", "count"]))

    md.append("\n## Top test rows by mAP50-95\n")
    md.append(md_table(top_test[:30], cols))

    md.append("\n## Real winners over fair baseline @1280\n")
    md.append(md_table(winners[:30], cols))

    (out_dir / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print(f"[DONE] {out_dir / 'summary.md'}")


# ---------------------------
# Main
# ---------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--baseline", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--splits", default="val,test")
    ap.add_argument("--device", default="0")

    ap.add_argument("--run-fullres", action="store_true")
    ap.add_argument("--run-sahi", action="store_true")
    ap.add_argument("--run-nwd", action="store_true")
    ap.add_argument("--run-classwise", action="store_true")
    ap.add_argument("--run-audit", action="store_true")
    ap.add_argument("--run-teacher-audit", action="store_true")

    ap.add_argument("--teacher", default="")
    ap.add_argument("--data-v2", default="")

    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--train-imgsz", type=int, default=1280)
    ap.add_argument("--batch", type=int, default=2)
    ap.add_argument("--lr0", type=float, default=0.0005)
    ap.add_argument("--patience", type=int, default=30)

    ap.add_argument("--anchor-map50", type=float, default=0.157330)
    ap.add_argument("--anchor-map50-95", type=float, default=0.043496)

    args = ap.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_csv = out_dir / "breakthrough_results.csv"

    splits = [x.strip() for x in args.splits.split(",") if x.strip()]
    class_names = get_class_names(args.data)

    # 1) Full-res official baseline sweep.
    if args.run_fullres:
        imgszs = [1280, 1536, 1792, 2048]
        confs = [0.0005, 0.001, 0.002, 0.003]
        ious = [0.40, 0.45, 0.50, 0.55, 0.60]
        max_dets = [300, 600, 1000, 1500]

        for split in splits:
            for imgsz in imgszs:
                for conf in confs:
                    for iou in ious:
                        for max_det in max_dets:
                            exp_id = f"BL_FR_{split}_img{imgsz}_conf{conf:g}_iou{iou:g}_md{max_det}".replace(".", "p")
                            ultra_val_row(
                                exp_id=exp_id,
                                weights=args.baseline,
                                data_yaml=args.data,
                                split=split,
                                imgsz=imgsz,
                                conf=conf,
                                iou=iou,
                                max_det=max_det,
                                device=args.device,
                                out_csv=out_csv,
                                stage="FR",
                                exp_type="ultralytics_val",
                            )

    # 2) SAHI-like sliced inference on YOLO11s baseline.
    if args.run_sahi:
        sahi_configs = [
            ("BSAHI01_512_ov025_GreedyNMM_IOU", 512, 0.25, False, "GREEDYNMM", "IOU", 0.50),
            ("BSAHI02_640_ov025_GreedyNMM_IOU", 640, 0.25, False, "GREEDYNMM", "IOU", 0.50),
            ("BSAHI03_768_ov025_GreedyNMM_IOU", 768, 0.25, False, "GREEDYNMM", "IOU", 0.50),
            ("BSAHI04_512_ov035_GreedyNMM_IOS", 512, 0.35, False, "GREEDYNMM", "IOS", 0.50),
            ("BSAHI05_640_ov035_GreedyNMM_IOS", 640, 0.35, False, "GREEDYNMM", "IOS", 0.50),
            ("BSAHI06_640_ov050_GreedyNMM_IOS", 640, 0.50, False, "GREEDYNMM", "IOS", 0.50),
            ("BSAHI07_full1280_plus_tile640_ov035_IOS", 640, 0.35, True, "GREEDYNMM", "IOS", 0.50),
            ("BSAHI08_full1280_plus_tile512_ov035_IOS", 512, 0.35, True, "GREEDYNMM", "IOS", 0.50),
        ]

        for split in splits:
            for name, tile, ov, include_full, post_method, metric, thr in sahi_configs:
                run_custom_eval(
                    exp_id=f"{name}_{split}",
                    weights=args.baseline,
                    data_yaml=args.data,
                    split=split,
                    device=args.device,
                    out_csv=out_csv,
                    out_dir=out_dir,
                    class_names=class_names,
                    mode="sliced",
                    imgsz=1280,
                    conf=0.001,
                    iou=0.50,
                    max_det=1000,
                    tile=tile,
                    overlap=ov,
                    include_full=include_full,
                    post_method=post_method,
                    post_metric=metric,
                    post_thr=thr,
                )

    # 3) NWD-NMS eval-only.
    if args.run_nwd:
        nwd_configs = [
            ("BNWD01_full1280_NWD_thr085_c32", 1280, 0.85, 32.0),
            ("BNWD02_full1280_NWD_thr080_c32", 1280, 0.80, 32.0),
            ("BNWD03_full1536_NWD_thr085_c32", 1536, 0.85, 32.0),
            ("BNWD04_full1536_NWD_thr080_c48", 1536, 0.80, 48.0),
        ]

        for split in splits:
            for name, imgsz, thr, c in nwd_configs:
                run_custom_eval(
                    exp_id=f"{name}_{split}",
                    weights=args.baseline,
                    data_yaml=args.data,
                    split=split,
                    device=args.device,
                    out_csv=out_csv,
                    out_dir=out_dir,
                    class_names=class_names,
                    mode="full",
                    imgsz=imgsz,
                    conf=0.001,
                    iou=0.70,
                    max_det=1500,
                    post_method="GREEDYNMM",
                    post_metric="NWD",
                    post_thr=thr,
                    nwd_c=c,
                )

    # 4) Classwise confidence sweep.
    if args.run_classwise:
        cls_configs = [
            ("BCLS01_bg001_wssv0005", 0.001, 0.0005),
            ("BCLS02_bg002_wssv0005", 0.002, 0.0005),
            ("BCLS03_bg0005_wssv001", 0.0005, 0.001),
            ("BCLS04_bg0015_wssv0005", 0.0015, 0.0005),
        ]

        for split in splits:
            for name, bg_thr, wssv_thr in cls_configs:
                run_custom_eval(
                    exp_id=f"{name}_{split}",
                    weights=args.baseline,
                    data_yaml=args.data,
                    split=split,
                    device=args.device,
                    out_csv=out_csv,
                    out_dir=out_dir,
                    class_names=class_names,
                    mode="full",
                    imgsz=1280,
                    conf=min(bg_thr, wssv_thr),
                    iou=0.50,
                    max_det=1500,
                    post_method="GREEDYNMM",
                    post_metric="IOU",
                    post_thr=0.50,
                    classwise=(bg_thr, wssv_thr),
                )

    # 5) Audit current fair baseline.
    if args.run_audit:
        audit_predictions(
            exp_id="AUDIT_BL1280_iou050_md1000",
            weights=args.baseline,
            data_yaml=args.data,
            split="test",
            device=args.device,
            out_dir=out_dir,
            imgsz=1280,
            conf=0.001,
            iou=0.50,
            max_det=1000,
            class_names=class_names,
            topk=300,
        )

    # 6) Optional stronger teacher audit.
    if args.run_teacher_audit:
        if args.teacher and Path(args.teacher).exists():
            audit_predictions(
                exp_id=f"AUDIT_TEACHER_{Path(args.teacher).stem}_1536",
                weights=args.teacher,
                data_yaml=args.data,
                split="test",
                device=args.device,
                out_dir=out_dir,
                imgsz=1536,
                conf=0.05,
                iou=0.50,
                max_det=2000,
                class_names=class_names,
                topk=300,
            )
        else:
            print(f"[SKIP teacher audit] teacher weight not found: {args.teacher}")

    # 7) Optional label-v2 training.
    train_label_v2_if_available(args, out_csv)

    make_summary(out_dir, args.anchor_map50, args.anchor_map50_95)


if __name__ == "__main__":
    main()
