#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:$PWD/tools_paper_diag:$PWD/tools_baseline_breakthrough:$PWD/tools_yolo26_transfer:${PYTHONPATH:-}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"

# Locked YOLO11s fair baseline weight.
YOLO11S_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt"

# YOLO26n weight from the 14-model 200ep canonical benchmark.
YOLO26N_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_od_yolo_14models_200ep_canonical_rebuild_kaggle_rtx4090_v1/runs_train_200ep/yolo26n_canonical2cls_split701515_img1024_ep200_b8_seed42/weights/best.pt"

OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo26n_transfer_from_yolo11s_best"
mkdir -p "$OUT_ROOT"

echo "===== CHECK PATHS ====="
echo "DATA_YAML=$DATA_YAML"
echo "YOLO11S_WEIGHTS=$YOLO11S_WEIGHTS"
echo "YOLO26N_WEIGHTS=$YOLO26N_WEIGHTS"
echo "OUT_ROOT=$OUT_ROOT"

test -f "$DATA_YAML"

if [ ! -f "$YOLO11S_WEIGHTS" ]; then
  echo "[WARN] locked YOLO11s weight not found. Searching fallback..."
  YOLO11S_WEIGHTS="$(find /home/drnguyenvinh/notebooks -path '*yolo11s*weights/best.pt' | head -n 1)"
fi

if [ ! -f "$YOLO26N_WEIGHTS" ]; then
  echo "[WARN] YOLO26n weight not found. Searching fallback..."
  YOLO26N_WEIGHTS="$(find /home/drnguyenvinh/notebooks -path '*yolo26n*weights/best.pt' | head -n 1)"
fi

test -f "$YOLO11S_WEIGHTS"
test -f "$YOLO26N_WEIGHTS"

echo
echo "===== FINAL WEIGHTS ====="
echo "YOLO11S_WEIGHTS=$YOLO11S_WEIGHTS"
echo "YOLO26N_WEIGHTS=$YOLO26N_WEIGHTS"

echo
echo "===== INSTALL LIGHT DEPS ====="
.venv/bin/python -m pip install -U pandas pyyaml pillow numpy tqdm tabulate >/dev/null

echo
echo "===== 1) DIRECT ASSIGNMENT: YOLO11s BEST SETTING -> YOLO26n ====="
.venv/bin/python tools_yolo26_transfer/05_compare_yolo11_best_to_yolo26n.py \
  --data "$DATA_YAML" \
  --yolo11s "$YOLO11S_WEIGHTS" \
  --yolo26n "$YOLO26N_WEIGHTS" \
  --out "$OUT_ROOT/direct_compare" \
  --device 0 \
  --splits val,test \
  --batch 1 \
  --mini-sweep \
  --anchor-map50 0.157789 \
  --anchor-map50-95 0.043617

echo
echo "===== DIRECT COMPARE SUMMARY ====="
cat "$OUT_ROOT/direct_compare/summary.md"

echo
echo "===== 2) FULL IDEAS ON YOLO26n: FULLRES + SAHI + NWD + CLASSWISE + AUDIT ====="
if [ -f "tools_baseline_breakthrough/04_baseline_breakthrough_e2e.py" ]; then
  .venv/bin/python tools_baseline_breakthrough/04_baseline_breakthrough_e2e.py \
    --data "$DATA_YAML" \
    --baseline "$YOLO26N_WEIGHTS" \
    --out "$OUT_ROOT/yolo26n_all_ideas" \
    --splits val,test \
    --device 0 \
    --run-fullres \
    --run-sahi \
    --run-nwd \
    --run-classwise \
    --run-audit \
    --anchor-map50 0.157789 \
    --anchor-map50-95 0.043617

  echo
  echo "===== YOLO26n ALL IDEAS SUMMARY ====="
  cat "$OUT_ROOT/yolo26n_all_ideas/summary.md"
else
  echo "[SKIP] tools_baseline_breakthrough/04_baseline_breakthrough_e2e.py not found."
  echo "Run the previous baseline_breakthrough pack first, or copy that script into tools_baseline_breakthrough/."
fi

echo
echo "===== OUTPUT FILES ====="
echo "$OUT_ROOT/direct_compare/summary.md"
echo "$OUT_ROOT/direct_compare/ranked_test_direct_compare.csv"
echo "$OUT_ROOT/direct_compare/winners_over_yolo11s_calibrated.csv"
echo "$OUT_ROOT/yolo26n_all_ideas/summary.md"
echo "$OUT_ROOT/yolo26n_all_ideas/winners_over_fair_baseline_1280.csv"
echo "$OUT_ROOT/yolo26n_all_ideas/audit/AUDIT_BL1280_iou050_md1000/index.html"
