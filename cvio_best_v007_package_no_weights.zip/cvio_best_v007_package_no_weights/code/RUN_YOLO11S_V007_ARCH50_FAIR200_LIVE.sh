#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:${PYTHONPATH:-}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"

# FAIR INIT:
# Do NOT use V007 best.pt here.
# All 50 variants start from the same YOLO11s pretrained weight.
INIT_WEIGHTS="${INIT_WEIGHTS:-yolo11s.pt}"

OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_v007_arch50_fair200_from_yolo11spt"
mkdir -p "$OUT_ROOT/logs"

echo "===== V007-ARCH50 FAIR 200E YOLO11s E2E ====="
echo "DATA_YAML=$DATA_YAML"
echo "INIT_WEIGHTS=$INIT_WEIGHTS"
echo "OUT_ROOT=$OUT_ROOT"
echo "EPOCHS=200"
echo "PATIENCE=0"
echo "IMGSZ=${IMGSZ:-1280}"
echo "BATCH=${BATCH:-2}"
echo "WORKERS=${WORKERS:-4}"
echo "DEVICE=${DEVICE:-0}"
echo "LR0=${LR0:-0.0005}"
echo "PYTORCH_CUDA_ALLOC_CONF=$PYTORCH_CUDA_ALLOC_CONF"

test -f "$DATA_YAML" || { echo "[FATAL] missing DATA_YAML"; exit 1; }
test -f "tools_yolo11_v007_next50/10_v007_next50_variants.py" || {
  echo "[FATAL] missing tools_yolo11_v007_next50/10_v007_next50_variants.py"
  echo "Create the V007-Next50 script first, then rerun this fair runner."
  exit 1
}

.venv/bin/python -m pip install -U pandas pyyaml tabulate >/dev/null

stdbuf -oL -eL .venv/bin/python tools_yolo11_v007_next50/10_v007_next50_variants.py \
  --local-ultralytics "$PWD/third_party/ultralytics" \
  --pretrain "$INIT_WEIGHTS" \
  --data "$DATA_YAML" \
  --out "$OUT_ROOT" \
  --epochs 200 \
  --imgsz "${IMGSZ:-1280}" \
  --batch "${BATCH:-2}" \
  --workers "${WORKERS:-4}" \
  --device "${DEVICE:-0}" \
  --lr0 "${LR0:-0.0005}" \
  --patience 0 \
  --yolo11s-map50 0.129 \
  --yolo11s-map50-95 0.038 \
  --v007-map50 0.163909 \
  --v007-map50-95 0.047748 \
  2>&1 | tee "$OUT_ROOT/logs/arch50_fair200_live.log"

echo
echo "===== FINAL SUMMARY ====="
cat "$OUT_ROOT/summary.md"

echo
echo "===== WINNERS OVER V007 BEST ====="
cat "$OUT_ROOT/winners_over_v007_best.csv"

echo
echo "===== OUTPUT FILES ====="
echo "$OUT_ROOT/summary.md"
echo "$OUT_ROOT/ranked_test.csv"
echo "$OUT_ROOT/winners_over_v007_best.csv"
echo "$OUT_ROOT/v007_next50_results.csv"
echo "$OUT_ROOT/v007_next50_variants.csv"
echo "$OUT_ROOT/logs/arch50_fair200_live.log"
