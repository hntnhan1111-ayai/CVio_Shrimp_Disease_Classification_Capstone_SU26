#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo
export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:${PYTHONPATH:-}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"
OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_verify_shortlist"
mkdir -p "$OUT_ROOT"

python - <<'PY'
from pathlib import Path
import csv
import time
import pandas as pd
from ultralytics import YOLO

DATA = "/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"
OUT = Path("/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_verify_shortlist")
OUT.mkdir(parents=True, exist_ok=True)

models = {
    "BL_YOLO11s_LOCKED": "/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt",
    "V007_SimAM_backbone_nomosaic": "/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants/runs_train/V007_C3k2SimAM_backbone_nomosaic_loc/weights/best.pt",
    "V004_SimAM_neck_nomosaic": "/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants/runs_train/V004_C3k2SimAM_neck_nomosaic_loc/weights/best.pt",
    "V026_ECA_deep_mild": "/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants/runs_train/V026_C3k2ECA_deep_mild_sod/weights/best.pt",
    "V068_SE_backbone_mild": "/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants/runs_train/V068_C3k2SE_backbone_mild_sod/weights/best.pt",
    "V046_CBAM_head_nomosaic": "/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants/runs_train/V046_C3k2CBAM_head_nomosaic_loc/weights/best.pt",
}

settings = [
    ("1280_iou055", 1280, 0.0005, 0.55, 600),
    ("1280_iou050", 1280, 0.0005, 0.50, 600),
    ("1536_iou055", 1536, 0.0005, 0.55, 600),
    ("1536_iou050", 1536, 0.0005, 0.50, 600),
]

rows = []
for name, weights in models.items():
    if not Path(weights).exists():
        rows.append({"model": name, "status": "missing_weight", "weights": weights})
        continue

    for split in ["val", "test"]:
        for tag, imgsz, conf, iou, max_det in settings:
            print(f"\n===== EVAL {name} {split} {tag} =====")
            t0 = time.time()
            try:
                model = YOLO(weights)
                m = model.val(
                    data=DATA,
                    split=split,
                    imgsz=imgsz,
                    conf=conf,
                    iou=iou,
                    max_det=max_det,
                    device=0,
                    batch=1,
                    workers=4,
                    half=True,
                    plots=False,
                    save_json=False,
                    verbose=False,
                )
                maps = getattr(m.box, "maps", [])
                rows.append({
                    "model": name,
                    "status": "ok",
                    "split": split,
                    "setting": tag,
                    "imgsz": imgsz,
                    "conf": conf,
                    "iou": iou,
                    "max_det": max_det,
                    "map50": float(m.box.map50),
                    "map50_95": float(m.box.map),
                    "map75": float(m.box.map75),
                    "precision": float(m.box.mp),
                    "recall": float(m.box.mr),
                    "ap_BG": float(maps[0]) if len(maps) > 0 else "",
                    "ap_WSSV": float(maps[1]) if len(maps) > 1 else "",
                    "elapsed_sec": time.time() - t0,
                    "weights": weights,
                })
            except Exception as e:
                rows.append({
                    "model": name,
                    "status": "error",
                    "split": split,
                    "setting": tag,
                    "error_type": type(e).__name__,
                    "error_message": str(e),
                    "elapsed_sec": time.time() - t0,
                    "weights": weights,
                })

df = pd.DataFrame(rows)
df.to_csv(OUT / "shortlist_verify_eval.csv", index=False)

ok = df[(df["status"] == "ok") & (df["split"] == "test")].copy()
for c in ["map50", "map50_95", "map75", "precision", "recall"]:
    ok[c] = pd.to_numeric(ok[c], errors="coerce")

baseline = ok[ok["model"] == "BL_YOLO11s_LOCKED"][["setting", "map50", "map50_95"]].rename(
    columns={"map50": "baseline_map50", "map50_95": "baseline_map50_95"}
)

merged = ok.merge(baseline, on="setting", how="left")
merged["delta_map50_vs_same_setting_BL"] = merged["map50"] - merged["baseline_map50"]
merged["delta_map50_95_vs_same_setting_BL"] = merged["map50_95"] - merged["baseline_map50_95"]

merged = merged.sort_values(["map50_95", "map50"], ascending=False)
merged.to_csv(OUT / "shortlist_verify_ranked_test.csv", index=False)

winners = merged[
    (merged["model"] != "BL_YOLO11s_LOCKED") &
    (merged["delta_map50_vs_same_setting_BL"] > 0) &
    (merged["delta_map50_95_vs_same_setting_BL"] > 0)
].copy()
winners.to_csv(OUT / "shortlist_verify_winners_vs_same_setting_baseline.csv", index=False)

cols = [
    "model", "setting", "map50", "map50_95", "map75", "precision", "recall",
    "baseline_map50", "baseline_map50_95",
    "delta_map50_vs_same_setting_BL",
    "delta_map50_95_vs_same_setting_BL",
]

md = []
md.append("# Mega100 Shortlist Verification\n")
md.append("## Ranked test rows\n")
md.append(merged[cols].to_markdown(index=False, floatfmt=".6f"))
md.append("\n## Winners vs same-setting YOLO11s baseline\n")
if len(winners):
    md.append(winners[cols].to_markdown(index=False, floatfmt=".6f"))
else:
    md.append("_No same-setting winners._")

(OUT / "shortlist_verify_summary.md").write_text("\n".join(md), encoding="utf-8")

print("\n===== SUMMARY =====")
print((OUT / "shortlist_verify_summary.md").read_text(encoding="utf-8"))
PY
