#!/usr/bin/env bash
set +e

REPO="/home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo"
PY="$REPO/.venv/bin/python"
PACK="$REPO/a2_boost_all_pack"
FULL_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo"
DATASET="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15"
REPORT="$REPO/a2_boost_debug_report_$(date +%Y%m%d_%H%M%S).txt"

exec > >(tee "$REPORT") 2>&1

echo "============================================================"
echo "A2 BOOST ROOT-CAUSE DEBUG REPORT"
echo "============================================================"
date
hostname
whoami
pwd

echo
echo "============================================================"
echo "0) BASIC PATHS"
echo "============================================================"
echo "REPO=$REPO"
echo "PY=$PY"
echo "PACK=$PACK"
echo "FULL_ROOT=$FULL_ROOT"
echo "DATASET=$DATASET"

echo
echo "============================================================"
echo "1) CHECK REPO / PACK STRUCTURE"
echo "============================================================"
ls -lah "$REPO"
echo
ls -lah "$PACK" || true
echo
find "$PACK" -maxdepth 3 -type f | sort || true

echo
echo "============================================================"
echo "2) CHECK PYTHON / ULTRALYTICS IMPORT WITH CLEAN ENV"
echo "============================================================"
env -i \
  HOME="$HOME" \
  PATH="$REPO/.venv/bin:$HOME/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" \
  VIRTUAL_ENV="$REPO/.venv" \
  PYTHONPATH="$REPO/third_party/ultralytics:$REPO:$PACK:$PACK/scripts" \
  CUDA_VISIBLE_DEVICES=0 \
  "$PY" - <<'PY'
import sys, os
print("sys.executable =", sys.executable)
print("sys.version =", sys.version)
try:
    import torch
    print("torch =", torch.__version__)
    print("cuda_available =", torch.cuda.is_available())
    print("cuda_count =", torch.cuda.device_count())
    print("cuda_name_0 =", torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)
except Exception as e:
    print("TORCH_ERROR =", repr(e))
try:
    import ultralytics
    print("ultralytics =", getattr(ultralytics, "__version__", None))
    print("ultralytics_file =", getattr(ultralytics, "__file__", None))
except Exception as e:
    print("ULTRALYTICS_ERROR =", repr(e))
PY

echo
echo "============================================================"
echo "3) CHECK DATASET / DATA.YAML"
echo "============================================================"
ls -lah "$DATASET" || true
ls -lah "$DATASET/data.yaml" || true
echo
find "$DATASET" -maxdepth 3 -type d | sort | head -80
echo
echo "Image/label counts:"
for split in train val test; do
  echo "--- $split ---"
  echo -n "images: "
  find "$DATASET/images/$split" -type f 2>/dev/null | wc -l
  echo -n "labels: "
  find "$DATASET/labels/$split" -type f -name "*.txt" 2>/dev/null | wc -l
  echo -n "boxes: "
  cat "$DATASET/labels/$split"/*.txt 2>/dev/null | awk 'NF>=5{n++} END{print n+0}'
done

echo
echo "============================================================"
echo "4) CHECK LOCKED BASELINE WEIGHTS"
echo "============================================================"
BASE1="$FULL_ROOT/baseline_reuse_lock/yolo11s_baseline_best.pt"
BASE2="$FULL_ROOT/runs_train/A0_B0_C0_D0_E0_yolo11s_baseline/weights/best.pt"

ls -lh "$BASE1" || true
ls -lh "$BASE2" || true

echo
echo "============================================================"
echo "5) FIND ALL POSSIBLE A2 / P2 / NO-P5 WEIGHTS"
echo "============================================================"
echo "Search under shrimp_yolo11s_full_method_zoo:"
find "$FULL_ROOT" -type f \( -iname "best.pt" -o -iname "last.pt" -o -iname "*.pt" \) 2>/dev/null \
  | grep -Ei 'A2|p2|no.?p5|no_p5|p2_no|P2' \
  | sort

echo
echo "Search under cvio_yolo11s_method_zoo:"
find "$REPO" -type f \( -iname "best.pt" -o -iname "last.pt" -o -iname "*.pt" \) 2>/dev/null \
  | grep -Ei 'A2|p2|no.?p5|no_p5|p2_no|P2' \
  | sort

echo
echo "Broader best.pt list, limited to likely YOLO11s/full-method dirs:"
find /home/drnguyenvinh/notebooks -type f -path "*weights/best.pt" 2>/dev/null \
  | grep -Ei 'yolo11s|method_zoo|full_method|A2|p2' \
  | sort \
  | head -200

echo
echo "============================================================"
echo "6) PARSE FINAL FULL-200 SUMMARY FOR A2 WEIGHTS"
echo "============================================================"
env -i \
  HOME="$HOME" \
  PATH="$REPO/.venv/bin:$HOME/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" \
  VIRTUAL_ENV="$REPO/.venv" \
  PYTHONPATH="$REPO/third_party/ultralytics:$REPO:$PACK:$PACK/scripts" \
  "$PY" - <<'PY'
from pathlib import Path
import csv, json, os

base = Path("/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/e2e_final_summary")
files = [
    base / "final_full200_summary.csv",
    base / "final_full200_rank_by_val.csv",
    base / "final_full200_rank_by_test.csv",
]
for p in files:
    print("\n===", p, "exists=", p.exists(), "===")
    if not p.exists():
        continue
    with p.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    print("rows =", len(rows))
    for r in rows:
        text = " ".join(str(r.get(k, "")) for k in r.keys())
        if any(s.lower() in text.lower() for s in ["A2", "p2_no_p5", "p2-no-p5", "no_p5"]):
            keys = ["id", "group", "train_status", "epochs_recorded", "val_map50_95", "test_map50_95", "weights"]
            print({k: r.get(k) for k in keys if k in r})
            w = r.get("weights")
            if w:
                print("  weights_exists:", Path(w).exists(), "=>", w)
PY

echo
echo "============================================================"
echo "7) CHECK DEFAULT A2 WEIGHT CANDIDATES HARD-CODED IN PACK"
echo "============================================================"
grep -R "A2_BOOST_A2_WEIGHTS\|A2_yolo11s_p2_no_p5\|p2_no_p5" -n "$PACK/scripts/cvio_exp_lib.py" "$PACK/scripts/run_all.py" || true

echo
echo "Candidate path existence:"
for p in \
  "/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/runs_train/A2_yolo11s_p2_no_p5/weights/best.pt" \
  "/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/runs_train/A2_yolo11s_p2_no_p5_full200/weights/best.pt" \
  "$REPO/runs_train/A2_yolo11s_p2_no_p5/weights/best.pt" \
  "$REPO/runs/A2_yolo11s_p2_no_p5/weights/best.pt"
do
  if [ -f "$p" ]; then
    echo "EXISTS: $p"
    ls -lh "$p"
  else
    echo "MISSING: $p"
  fi
done

echo
echo "============================================================"
echo "8) FIND A2 YAML / MODEL CONFIGS"
echo "============================================================"
echo "Likely YAMLs:"
find "$REPO" "$FULL_ROOT" -type f \( -iname "*.yaml" -o -iname "*.yml" \) 2>/dev/null \
  | grep -Ei 'A2|p2|no.?p5|no_p5|dysample|agfpn|nwd|saf|aaf|dyhead|mfam|dasi|ssff|cpam' \
  | sort \
  | head -300

echo
echo "All configs dir tree:"
find "$REPO" -maxdepth 4 -type f \( -iname "*.yaml" -o -iname "*.yml" \) | sort | head -300

echo
echo "============================================================"
echo "9) CHECK PREVIOUS STAGE A SCRIPT"
echo "============================================================"
STAGEA="$REPO/a2_boost_pack/scripts/run_a2_stageA_sahi_postprocess_sweep.py"
ls -lh "$STAGEA" || true
if [ -f "$STAGEA" ]; then
  echo "Stage A existing script found."
  head -80 "$STAGEA"
else
  echo "Stage A existing script missing."
fi

echo
echo "============================================================"
echo "10) CHECK LATEST A2 BOOST LOGS"
echo "============================================================"
find "$PACK/logs" -type f -name "*.log" -printf "%TY-%Tm-%Td %TH:%TM %p\n" 2>/dev/null | sort | tail -10
echo
LATEST_LOG="$(find "$PACK/logs" -type f -name "*.log" 2>/dev/null | sort | tail -1)"
if [ -n "$LATEST_LOG" ]; then
  echo "Latest log: $LATEST_LOG"
  tail -120 "$LATEST_LOG"
fi

echo
echo "============================================================"
echo "11) SUMMARY: AUTO-SUGGEST EXPORT COMMAND IF A2 WEIGHT FOUND IN CSV"
echo "============================================================"
env -i \
  HOME="$HOME" \
  PATH="$REPO/.venv/bin:$HOME/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" \
  VIRTUAL_ENV="$REPO/.venv" \
  PYTHONPATH="$REPO/third_party/ultralytics:$REPO:$PACK:$PACK/scripts" \
  "$PY" - <<'PY'
from pathlib import Path
import csv

base = Path("/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/e2e_final_summary")
candidates = []
for name in ["final_full200_summary.csv", "final_full200_rank_by_val.csv", "final_full200_rank_by_test.csv"]:
    p = base / name
    if not p.exists():
        continue
    with p.open(newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            text = " ".join(str(v) for v in r.values())
            w = r.get("weights", "")
            if w and Path(w).exists() and any(s.lower() in text.lower() for s in ["A2", "p2_no_p5", "p2-no-p5", "no_p5"]):
                candidates.append((r.get("id", ""), w))

seen = []
for item in candidates:
    if item not in seen:
        seen.append(item)

if seen:
    print("FOUND A2 WEIGHT CANDIDATES:")
    for i, (mid, w) in enumerate(seen, 1):
        print(f"{i}. id={mid}")
        print(f"   weights={w}")
    print()
    print("Suggested run command using first candidate:")
    print(f'export A2_BOOST_A2_WEIGHTS="{seen[0][1]}"')
else:
    print("NO A2 WEIGHT FOUND FROM FINAL CSV. Need inspect runs_train manually.")
PY

echo
echo "============================================================"
echo "REPORT SAVED TO:"
echo "$REPORT"
echo "============================================================"
