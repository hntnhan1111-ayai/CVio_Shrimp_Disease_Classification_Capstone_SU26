from __future__ import annotations

import argparse
import csv
import time
from pathlib import Path
from typing import Dict, Any, List

from ultralytics import YOLO


def read_rows(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_rows(path: Path, rows: List[Dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def append_row(path: Path, row: Dict[str, Any]):
    rows = read_rows(path)
    rows.append(row)
    write_rows(path, rows)


def done(path: Path, exp_id: str):
    return any(r.get("id") == exp_id and r.get("status") == "ok" for r in read_rows(path))


def eval_model(exp_id, weights, data, split, imgsz, conf, iou, max_det, device, out_csv):
    if done(out_csv, exp_id):
        print("[SKIP]", exp_id)
        return

    print("[EVAL]", exp_id)
    t0 = time.time()
    try:
        model = YOLO(weights)
        m = model.val(
            data=data,
            split=split,
            imgsz=imgsz,
            conf=conf,
            iou=iou,
            max_det=max_det,
            device=device,
            batch=1,
            workers=4,
            half=True,
            plots=False,
            save_json=False,
            verbose=False,
        )
        maps = getattr(m.box, "maps", [])
        row = {
            "id": exp_id,
            "status": "ok",
            "weights": weights,
            "data": data,
            "split": split,
            "imgsz": imgsz,
            "conf": conf,
            "iou": iou,
            "max_det": max_det,
            "map50": float(m.box.map50),
            "map50_95": float(m.box.map),
            "map75": float(m.box.map75),
            "precision": float(m.box.mp),
            "recall": float(m.box.mr),
            "ap_BG": float(maps[0]) if len(maps) > 0 else "",
            "ap_WSSV": float(maps[1]) if len(maps) > 1 else "",
            "elapsed_sec": time.time() - t0,
        }
    except Exception as e:
        row = {
            "id": exp_id,
            "status": "error",
            "weights": weights,
            "data": data,
            "split": split,
            "imgsz": imgsz,
            "conf": conf,
            "iou": iou,
            "max_det": max_det,
            "error_type": type(e).__name__,
            "error_message": str(e),
            "elapsed_sec": time.time() - t0,
        }
    append_row(out_csv, row)


def train_variant(
    exp_id: str,
    init_weights: str,
    data_yaml: str,
    out_dir: Path,
    imgsz: int,
    epochs: int,
    batch: int,
    device: str,
    lr0: float,
    close_mosaic: int,
    strong_aug: bool,
):
    run_dir = out_dir / "runs_train" / exp_id
    best = run_dir / "weights" / "best.pt"
    if best.exists():
        print("[SKIP TRAIN]", exp_id)
        return str(best)

    print("[TRAIN]", exp_id)
    model = YOLO(init_weights)

    train_kwargs = dict(
        data=data_yaml,
        epochs=epochs,
        imgsz=imgsz,
        batch=batch,
        device=device,
        workers=8,
        optimizer="AdamW",
        lr0=lr0,
        cos_lr=True,
        patience=35,
        seed=42,
        project=str(out_dir / "runs_train"),
        name=exp_id,
        exist_ok=True,
        close_mosaic=close_mosaic,
        plots=True,
        verbose=True,
    )

    if strong_aug:
        train_kwargs.update(dict(
            hsv_h=0.015,
            hsv_s=0.50,
            hsv_v=0.35,
            degrees=10.0,
            translate=0.10,
            scale=0.70,
            shear=2.0,
            perspective=0.0005,
            flipud=0.10,
            fliplr=0.50,
            mosaic=1.0,
            mixup=0.10,
            copy_paste=0.05,
            erasing=0.20,
        ))

    model.train(**train_kwargs)

    if not best.exists():
        raise RuntimeError(f"best.pt not found: {best}")

    return str(best)


def summarize(out_dir: Path, anchor50: float, anchor5095: float):
    csv_path = out_dir / "yolo11s_survey_method_results.csv"
    rows = read_rows(csv_path)
    ok = [r for r in rows if r.get("status") == "ok" and r.get("split") == "test"]

    for r in ok:
        r["_map50"] = float(r["map50"])
        r["_map50_95"] = float(r["map50_95"])
        r["_delta_map50"] = r["_map50"] - anchor50
        r["_delta_map50_95"] = r["_map50_95"] - anchor5095

    ok = sorted(ok, key=lambda r: (r["_map50_95"], r["_map50"]), reverse=True)
    winners = [r for r in ok if r["_map50"] > anchor50 and r["_map50_95"] > anchor5095]

    write_rows(out_dir / "ranked_test.csv", ok)
    write_rows(out_dir / "winners_over_yolo11s_calibrated.csv", winners)

    def table(items, cols, n=30):
        if not items:
            return "_No rows._"
        lines = []
        lines.append("| " + " | ".join(cols) + " |")
        lines.append("| " + " | ".join(["---"] * len(cols)) + " |")
        for r in items[:n]:
            vals = []
            for c in cols:
                v = r.get(c, "")
                try:
                    vals.append(f"{float(v):.6f}")
                except Exception:
                    vals.append(str(v))
            lines.append("| " + " | ".join(vals) + " |")
        return "\n".join(lines)

    cols = [
        "id", "data", "imgsz", "conf", "iou", "max_det",
        "map50", "map50_95", "map75", "precision", "recall",
        "_delta_map50", "_delta_map50_95", "elapsed_sec"
    ]

    md = []
    md.append("# YOLO11s Survey-Method Training/Eval Summary\n")
    md.append(f"- Calibrated anchor mAP50: `{anchor50}`")
    md.append(f"- Calibrated anchor mAP50-95: `{anchor5095}`")
    md.append(f"- Total eval rows: `{len(rows)}`")
    md.append(f"- Winners over anchor on both metrics: `{len(winners)}`\n")

    md.append("## Top test rows\n")
    md.append(table(ok, cols, 40))

    md.append("\n## Winners over YOLO11s calibrated\n")
    md.append(table(winners, cols, 40))

    (out_dir / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print("[DONE]", out_dir / "summary.md")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="0")

    ap.add_argument("--data-v2", default="")
    ap.add_argument("--tile-data", default="")
    ap.add_argument("--sr-data", default="")

    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--final-epochs", type=int, default=200)
    ap.add_argument("--batch-full", type=int, default=2)
    ap.add_argument("--batch-tile", type=int, default=16)
    ap.add_argument("--lr0", type=float, default=0.0005)

    ap.add_argument("--run-label-v2", action="store_true")
    ap.add_argument("--run-tile-train", action="store_true")
    ap.add_argument("--run-strong-aug", action="store_true")
    ap.add_argument("--run-sr", action="store_true")
    ap.add_argument("--run-original-strong", action="store_true")

    ap.add_argument("--anchor-map50", type=float, default=0.157789)
    ap.add_argument("--anchor-map50-95", type=float, default=0.043617)

    args = ap.parse_args()

    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    out_csv = out_dir / "yolo11s_survey_method_results.csv"

    eval_settings = [
        ("calib_iou050", 1280, 0.0005, 0.50, 600),
        ("best5095_iou055", 1280, 0.0005, 0.55, 600),
        ("old_anchor", 1024, 0.0010, 0.70, 300),
    ]

    trained = []

    if args.run_original_strong:
        w = train_variant(
            "Y11_ORIGINAL_STRONGAUG_1280",
            args.baseline,
            args.data,
            out_dir,
            imgsz=1280,
            epochs=args.epochs,
            batch=args.batch_full,
            device=args.device,
            lr0=args.lr0,
            close_mosaic=15,
            strong_aug=True,
        )
        trained.append(("Y11_ORIGINAL_STRONGAUG_1280", w, args.data))

    if args.run_label_v2 and args.data_v2 and Path(args.data_v2).exists():
        w = train_variant(
            "Y11_LABELV2_FT_1280",
            args.baseline,
            args.data_v2,
            out_dir,
            imgsz=1280,
            epochs=args.final_epochs,
            batch=args.batch_full,
            device=args.device,
            lr0=args.lr0,
            close_mosaic=15,
            strong_aug=True,
        )
        trained.append(("Y11_LABELV2_FT_1280", w, args.data_v2))
    elif args.run_label_v2:
        print("[SKIP] --data-v2 missing or not found")

    if args.run_tile_train and args.tile_data and Path(args.tile_data).exists():
        w = train_variant(
            "Y11_TILEAWARE_640",
            args.baseline,
            args.tile_data,
            out_dir,
            imgsz=640,
            epochs=args.epochs,
            batch=args.batch_tile,
            device=args.device,
            lr0=args.lr0,
            close_mosaic=10,
            strong_aug=True,
        )
        trained.append(("Y11_TILEAWARE_640_eval_full", w, args.data))
        trained.append(("Y11_TILEAWARE_640_eval_tile", w, args.tile_data))
    elif args.run_tile_train:
        print("[SKIP] --tile-data missing or not found")

    if args.run_sr and args.sr_data and Path(args.sr_data).exists():
        w = train_variant(
            "Y11_SR_LANCZOS_X2_1280",
            args.baseline,
            args.sr_data,
            out_dir,
            imgsz=1280,
            epochs=args.epochs,
            batch=args.batch_full,
            device=args.device,
            lr0=args.lr0,
            close_mosaic=15,
            strong_aug=True,
        )
        trained.append(("Y11_SR_LANCZOS_X2_1280", w, args.sr_data))
    elif args.run_sr:
        print("[SKIP] --sr-data missing or not found")

    # Always eval original baseline again for same CSV context.
    trained.insert(0, ("Y11_BASELINE_LOCKED", args.baseline, args.data))

    for tag, weights, data_yaml in trained:
        for split in ["val", "test"]:
            for name, imgsz, conf, iou, md in eval_settings:
                eval_model(
                    exp_id=f"{tag}_{split}_{name}",
                    weights=weights,
                    data=data_yaml,
                    split=split,
                    imgsz=imgsz,
                    conf=conf,
                    iou=iou,
                    max_det=md,
                    device=args.device,
                    out_csv=out_csv,
                )

    summarize(out_dir, args.anchor_map50, args.anchor_map50_95)


if __name__ == "__main__":
    main()
