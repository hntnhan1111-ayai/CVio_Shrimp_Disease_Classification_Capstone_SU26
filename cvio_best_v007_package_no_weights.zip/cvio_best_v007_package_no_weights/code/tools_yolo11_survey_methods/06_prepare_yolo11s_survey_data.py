from __future__ import annotations

import argparse
import csv
import html
import os
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Any

import yaml
import pandas as pd
from PIL import Image, ImageDraw


IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def read_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def write_yaml(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")


def dataset_root(data_yaml: Path) -> Path:
    d = read_yaml(data_yaml)
    if "path" in d and d["path"]:
        p = Path(d["path"])
        return p if p.is_absolute() else (data_yaml.parent / p).resolve()
    return data_yaml.parent.resolve()


def split_image_dir(data_yaml: Path, split: str) -> Path:
    d = read_yaml(data_yaml)
    root = dataset_root(data_yaml)
    value = d.get(split)
    if value is None:
        raise ValueError(f"Missing split {split} in {data_yaml}")
    if isinstance(value, list):
        value = value[0]
    p = Path(str(value))
    if not p.is_absolute():
        p = root / p
    return p.resolve()


def label_path_for_image(img_path: Path) -> Path:
    parts = list(img_path.parts)
    if "images" in parts:
        idx = len(parts) - 1 - parts[::-1].index("images")
        parts[idx] = "labels"
        return Path(*parts).with_suffix(".txt")
    return img_path.parent.parent / "labels" / img_path.parent.name / f"{img_path.stem}.txt"


def list_images(img_dir: Path) -> List[Path]:
    return sorted([p for p in img_dir.rglob("*") if p.suffix.lower() in IMG_EXTS])


def read_yolo_labels(label_path: Path) -> List[List[float]]:
    if not label_path.exists():
        return []
    rows = []
    for line in label_path.read_text(encoding="utf-8").splitlines():
        parts = line.strip().split()
        if len(parts) != 5:
            continue
        rows.append([float(x) for x in parts])
    return rows


def write_yolo_labels(label_path: Path, rows: List[List[float]]):
    label_path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for cls, xc, yc, w, h in rows:
        lines.append(f"{int(cls)} {xc:.8f} {yc:.8f} {w:.8f} {h:.8f}")
    label_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def yolo_to_xyxy(row, W, H):
    cls, xc, yc, w, h = row
    x1 = (xc - w / 2) * W
    y1 = (yc - h / 2) * H
    x2 = (xc + w / 2) * W
    y2 = (yc + h / 2) * H
    return int(cls), [x1, y1, x2, y2]


def xyxy_to_yolo(cls_id, box, W, H):
    x1, y1, x2, y2 = box
    x1 = max(0.0, min(float(W), x1))
    y1 = max(0.0, min(float(H), y1))
    x2 = max(0.0, min(float(W), x2))
    y2 = max(0.0, min(float(H), y2))
    if x2 <= x1 or y2 <= y1:
        return None
    xc = ((x1 + x2) / 2) / W
    yc = ((y1 + y2) / 2) / H
    w = (x2 - x1) / W
    h = (y2 - y1) / H
    return [int(cls_id), xc, yc, w, h]


def box_iou(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    aa = max(0, ax2 - ax1) * max(0, ay2 - ay1)
    bb = max(0, bx2 - bx1) * max(0, by2 - by1)
    return inter / max(aa + bb - inter, 1e-9)


def link_or_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return
    try:
        os.symlink(src, dst)
    except Exception:
        shutil.copy2(src, dst)


def names_from_data(data_yaml: Path):
    d = read_yaml(data_yaml)
    names = d.get("names", {0: "BG", 1: "WSSV"})
    if isinstance(names, list):
        return {i: n for i, n in enumerate(names)}
    return {int(k): v for k, v in names.items()}


# ---------------------------
# 1) Label-v2 review pack
# ---------------------------

def make_label_v2_review(data_yaml: Path, audit_csv: Path, out_root: Path, topk: int):
    out = out_root / "label_v2_review_pack"
    gallery = out / "gallery"
    gallery.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(audit_csv)
    priority = {
        "possible_missing_label": 0,
        "box_shift_or_low_iou": 1,
        "wrong_class": 2,
        "fn_missed_gt": 3,
    }
    df = df[df["event"].isin(priority.keys())].copy()
    df["priority"] = df["event"].map(priority)
    if "conf" in df.columns:
        df["conf_numeric"] = pd.to_numeric(df["conf"], errors="coerce").fillna(0)
    else:
        df["conf_numeric"] = 0
    df = df.sort_values(["priority", "conf_numeric"], ascending=[True, False]).head(topk).copy()

    image_index = {}
    for split in ["train", "val", "test"]:
        try:
            for p in list_images(split_image_dir(data_yaml, split)):
                image_index[p.name] = p
        except Exception:
            pass

    action_rows = []
    html_cards = []

    for i, r in df.reset_index(drop=True).iterrows():
        image_name = str(r["image_name"])
        img_path = image_index.get(image_name)
        if img_path is None:
            continue

        img = Image.open(img_path).convert("RGB")
        draw = ImageDraw.Draw(img)

        x1, y1, x2, y2 = [float(r[c]) for c in ["x1", "y1", "x2", "y2"]]
        draw.rectangle([x1, y1, x2, y2], outline="red", width=4)
        label = f'{i:04d} {r["event"]} {r.get("class_name", r.get("class_id", ""))} conf={r.get("conf","")}'
        draw.text((max(0, x1), max(0, y1 - 24)), label, fill="red")

        thumb = img.copy()
        thumb.thumbnail((1200, 900))
        thumb_path = gallery / f"{i:04d}_{image_name}"
        thumb.save(thumb_path)

        suggested_action = ""
        if r["event"] == "possible_missing_label":
            suggested_action = "add_box"
        elif r["event"] == "box_shift_or_low_iou":
            suggested_action = "update_nearest"
        elif r["event"] == "wrong_class":
            suggested_action = "change_nearest_class"
        elif r["event"] == "fn_missed_gt":
            suggested_action = "keep"

        action_rows.append({
            "review_id": i,
            "status": "todo",
            "action": suggested_action,
            "image_name": image_name,
            "event": r["event"],
            "class_id": int(r["class_id"]),
            "class_name": r.get("class_name", ""),
            "x1": x1,
            "y1": y1,
            "x2": x2,
            "y2": y2,
            "target_label_index": "",
            "notes": "",
        })

        html_cards.append(f"""
        <div style="border:1px solid #ddd; border-radius:12px; padding:16px; margin:16px 0;">
          <h3>#{i:04d} | {html.escape(str(r["event"]))} | {html.escape(image_name)}</h3>
          <p>Suggested action: <b>{html.escape(suggested_action)}</b> | class={html.escape(str(r.get("class_name", r.get("class_id", ""))))} | conf={html.escape(str(r.get("conf","")))}</p>
          <img src="gallery/{html.escape(thumb_path.name)}" style="max-width:100%; height:auto; border-radius:8px;">
        </div>
        """)

    actions_csv = out / "manual_label_actions.csv"
    pd.DataFrame(action_rows).to_csv(actions_csv, index=False)

    html_text = f"""
    <!doctype html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>ShrimpOD Label-v2 Review Pack</title>
      <style>
        body {{ font-family: Arial, sans-serif; max-width: 1200px; margin: 32px auto; line-height: 1.5; }}
        code {{ background:#f4f4f4; padding:2px 6px; border-radius:4px; }}
      </style>
    </head>
    <body>
      <h1>ShrimpOD Label-v2 Review Pack</h1>
      <p>Edit this CSV after review: <code>{html.escape(str(actions_csv))}</code></p>
      <p>Allowed actions: <code>keep</code>, <code>ignore</code>, <code>add_box</code>, <code>update_nearest</code>, <code>change_nearest_class</code>, <code>delete_nearest</code>.</p>
      {''.join(html_cards)}
    </body>
    </html>
    """
    (out / "index.html").write_text(html_text, encoding="utf-8")

    print("[DONE] review HTML:", out / "index.html")
    print("[DONE] actions CSV:", actions_csv)


# ---------------------------
# 2) Apply manual label-v2 actions
# ---------------------------

def copy_dataset_skeleton(data_yaml: Path, out_dataset: Path):
    names = names_from_data(data_yaml)
    for split in ["train", "val", "test"]:
        try:
            img_dir = split_image_dir(data_yaml, split)
        except Exception:
            continue
        for img in list_images(img_dir):
            dst_img = out_dataset / "images" / split / img.name
            link_or_copy(img.resolve(), dst_img)

            src_lab = label_path_for_image(img)
            dst_lab = out_dataset / "labels" / split / f"{img.stem}.txt"
            dst_lab.parent.mkdir(parents=True, exist_ok=True)
            if src_lab.exists():
                shutil.copy2(src_lab, dst_lab)
            else:
                dst_lab.write_text("", encoding="utf-8")

    data = {
        "path": str(out_dataset.resolve()),
        "train": "images/train",
        "val": "images/val",
        "test": "images/test",
        "names": names,
    }
    write_yaml(out_dataset / "data.yaml", data)


def find_image_in_v2(out_dataset: Path, image_name: str) -> Path | None:
    hits = list((out_dataset / "images").rglob(image_name))
    return hits[0] if hits else None


def apply_actions(data_yaml: Path, actions_csv: Path, out_dataset: Path):
    copy_dataset_skeleton(data_yaml, out_dataset)

    df = pd.read_csv(actions_csv)
    df = df[df["status"].astype(str).str.lower().isin(["done", "apply", "approved", "yes"])]
    if df.empty:
        print("[WARN] No approved rows. Set status=done for rows you want to apply.")
        print("[DONE] label-v2 skeleton:", out_dataset / "data.yaml")
        return

    changelog = []

    for _, r in df.iterrows():
        action = str(r["action"]).strip()
        if action in ["keep", "ignore", ""]:
            continue

        img = find_image_in_v2(out_dataset, str(r["image_name"]))
        if img is None:
            continue

        W, H = Image.open(img).size
        lab = out_dataset / "labels" / img.parent.name / f"{img.stem}.txt"
        rows = read_yolo_labels(lab)

        cls_id = int(r["class_id"])
        candidate = [float(r["x1"]), float(r["y1"]), float(r["x2"]), float(r["y2"])]

        abs_rows = []
        for idx, row in enumerate(rows):
            c, box = yolo_to_xyxy(row, W, H)
            abs_rows.append((idx, c, box))

        if action == "add_box":
            y = xyxy_to_yolo(cls_id, candidate, W, H)
            if y is not None:
                rows.append(y)
                changelog.append({**r.to_dict(), "applied": "add_box"})

        elif action in ["update_nearest", "change_nearest_class", "delete_nearest"]:
            if not abs_rows:
                continue

            same_or_all = abs_rows
            if action != "change_nearest_class":
                same = [x for x in abs_rows if x[1] == cls_id]
                if same:
                    same_or_all = same

            best = max(same_or_all, key=lambda x: box_iou(x[2], candidate))
            idx = best[0]

            if action == "update_nearest":
                y = xyxy_to_yolo(cls_id, candidate, W, H)
                if y is not None:
                    rows[idx] = y
                    changelog.append({**r.to_dict(), "applied": "update_nearest", "target_index": idx})

            elif action == "change_nearest_class":
                old = rows[idx]
                rows[idx] = [cls_id, old[1], old[2], old[3], old[4]]
                changelog.append({**r.to_dict(), "applied": "change_nearest_class", "target_index": idx})

            elif action == "delete_nearest":
                rows.pop(idx)
                changelog.append({**r.to_dict(), "applied": "delete_nearest", "target_index": idx})

        write_yolo_labels(lab, rows)

    pd.DataFrame(changelog).to_csv(out_dataset / "label_v2_changelog.csv", index=False)
    print("[DONE] label-v2 data:", out_dataset / "data.yaml")
    print("[DONE] changelog:", out_dataset / "label_v2_changelog.csv")


# ---------------------------
# 3) True tile-aware dataset
# ---------------------------

def tile_grid(W: int, H: int, tile: int, overlap: float):
    step = max(1, int(tile * (1 - overlap)))
    xs = list(range(0, max(W - tile + 1, 1), step))
    ys = list(range(0, max(H - tile + 1, 1), step))
    if not xs or xs[-1] != max(W - tile, 0):
        xs.append(max(W - tile, 0))
    if not ys or ys[-1] != max(H - tile, 0):
        ys.append(max(H - tile, 0))

    seen = set()
    coords = []
    for y in ys:
        for x in xs:
            x2, y2 = min(x + tile, W), min(y + tile, H)
            key = (x, y, x2, y2)
            if key not in seen:
                seen.add(key)
                coords.append(key)
    return coords


def intersect_box(box, crop):
    x1, y1, x2, y2 = box
    cx1, cy1, cx2, cy2 = crop
    ix1, iy1 = max(x1, cx1), max(y1, cy1)
    ix2, iy2 = min(x2, cx2), min(y2, cy2)
    if ix2 <= ix1 or iy2 <= iy1:
        return None
    return [ix1 - cx1, iy1 - cy1, ix2 - cx1, iy2 - cy1]


def make_tile_dataset(data_yaml: Path, out_dataset: Path, tile: int, overlap: float, min_keep: float, min_box_px: float):
    names = names_from_data(data_yaml)

    stats = []
    for split in ["train", "val", "test"]:
        try:
            img_dir = split_image_dir(data_yaml, split)
        except Exception:
            continue

        out_img_dir = out_dataset / "images" / split
        out_lab_dir = out_dataset / "labels" / split
        out_img_dir.mkdir(parents=True, exist_ok=True)
        out_lab_dir.mkdir(parents=True, exist_ok=True)

        for img_path in list_images(img_dir):
            img = Image.open(img_path).convert("RGB")
            W, H = img.size

            labels = []
            for row in read_yolo_labels(label_path_for_image(img_path)):
                c, b = yolo_to_xyxy(row, W, H)
                labels.append((c, b))

            for k, crop in enumerate(tile_grid(W, H, tile, overlap)):
                cx1, cy1, cx2, cy2 = crop
                crop_img = img.crop(crop)
                tw, th = crop_img.size

                out_labels = []
                for c, b in labels:
                    ib = intersect_box(b, crop)
                    if ib is None:
                        continue

                    orig_area = max(1e-9, (b[2] - b[0]) * (b[3] - b[1]))
                    inter_area = max(0, ib[2] - ib[0]) * max(0, ib[3] - ib[1])
                    if inter_area / orig_area < min_keep:
                        continue
                    if (ib[2] - ib[0]) < min_box_px or (ib[3] - ib[1]) < min_box_px:
                        continue

                    y = xyxy_to_yolo(c, ib, tw, th)
                    if y is not None:
                        out_labels.append(y)

                # Keep only tiles with at least one object for train. For val/test, keep all object tiles.
                if not out_labels:
                    continue

                stem = f"{img_path.stem}_tile{k:03d}_x{cx1}_y{cy1}"
                out_img = out_img_dir / f"{stem}.jpg"
                out_lab = out_lab_dir / f"{stem}.txt"

                crop_img.save(out_img, quality=95)
                write_yolo_labels(out_lab, out_labels)
                stats.append({"split": split, "image": out_img.name, "n_labels": len(out_labels)})

    data = {
        "path": str(out_dataset.resolve()),
        "train": "images/train",
        "val": "images/val",
        "test": "images/test",
        "names": names,
    }
    write_yaml(out_dataset / "data.yaml", data)
    pd.DataFrame(stats).to_csv(out_dataset / "tile_stats.csv", index=False)
    print("[DONE] tile data:", out_dataset / "data.yaml")
    print("[DONE] tile stats:", out_dataset / "tile_stats.csv")


# ---------------------------
# 4) Super-resolution/Lanczos dataset
# ---------------------------

def make_sr_dataset(data_yaml: Path, out_dataset: Path, scale: int):
    names = names_from_data(data_yaml)
    for split in ["train", "val", "test"]:
        try:
            img_dir = split_image_dir(data_yaml, split)
        except Exception:
            continue

        for img_path in list_images(img_dir):
            img = Image.open(img_path).convert("RGB")
            W, H = img.size
            up = img.resize((W * scale, H * scale), Image.Resampling.LANCZOS)

            out_img = out_dataset / "images" / split / img_path.name
            out_lab = out_dataset / "labels" / split / f"{img_path.stem}.txt"
            out_img.parent.mkdir(parents=True, exist_ok=True)
            out_lab.parent.mkdir(parents=True, exist_ok=True)

            up.save(out_img, quality=95)

            src_lab = label_path_for_image(img_path)
            if src_lab.exists():
                shutil.copy2(src_lab, out_lab)
            else:
                out_lab.write_text("", encoding="utf-8")

    data = {
        "path": str(out_dataset.resolve()),
        "train": "images/train",
        "val": "images/val",
        "test": "images/test",
        "names": names,
    }
    write_yaml(out_dataset / "data.yaml", data)
    print("[DONE] SR data:", out_dataset / "data.yaml")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out-root", required=True)
    ap.add_argument("--audit-csv", default="")
    ap.add_argument("--make-review", action="store_true")
    ap.add_argument("--topk", type=int, default=500)

    ap.add_argument("--apply-actions", action="store_true")
    ap.add_argument("--actions-csv", default="")
    ap.add_argument("--label-v2-out", default="")

    ap.add_argument("--make-tiles", action="store_true")
    ap.add_argument("--tile-data", default="")
    ap.add_argument("--tile", type=int, default=640)
    ap.add_argument("--overlap", type=float, default=0.35)
    ap.add_argument("--min-keep", type=float, default=0.30)
    ap.add_argument("--min-box-px", type=float, default=2.0)

    ap.add_argument("--make-sr", action="store_true")
    ap.add_argument("--sr-out", default="")
    ap.add_argument("--sr-scale", type=int, default=2)

    args = ap.parse_args()

    data_yaml = Path(args.data).resolve()
    out_root = Path(args.out_root).resolve()
    out_root.mkdir(parents=True, exist_ok=True)

    if args.make_review:
        if not args.audit_csv:
            raise SystemExit("--audit-csv required for --make-review")
        make_label_v2_review(data_yaml, Path(args.audit_csv).resolve(), out_root, args.topk)

    if args.apply_actions:
        if not args.actions_csv:
            raise SystemExit("--actions-csv required for --apply-actions")
        label_v2_out = Path(args.label_v2_out).resolve() if args.label_v2_out else out_root / "shrimp_yolo_labels_v2"
        apply_actions(data_yaml, Path(args.actions_csv).resolve(), label_v2_out)

    if args.make_tiles:
        src_data = Path(args.tile_data).resolve() if args.tile_data else data_yaml
        out_dataset = out_root / f"tile{args.tile}_ov{str(args.overlap).replace('.', 'p')}"
        make_tile_dataset(src_data, out_dataset, args.tile, args.overlap, args.min_keep, args.min_box_px)

    if args.make_sr:
        out_dataset = Path(args.sr_out).resolve() if args.sr_out else out_root / f"sr_x{args.sr_scale}"
        make_sr_dataset(data_yaml, out_dataset, args.sr_scale)


if __name__ == "__main__":
    main()
