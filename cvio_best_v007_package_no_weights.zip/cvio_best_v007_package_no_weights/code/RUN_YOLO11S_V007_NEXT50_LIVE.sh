#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:${PYTHONPATH:-}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"

V007_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants/runs_train/V007_C3k2SimAM_backbone_nomosaic_loc/weights/best.pt"
YOLO11S_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt"

if [ -f "$V007_WEIGHTS" ]; then
  PRETRAIN="$V007_WEIGHTS"
else
  echo "[WARN] V007 best.pt not found. Fallback to YOLO11s baseline."
  PRETRAIN="$YOLO11S_WEIGHTS"
fi

OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_v007_next50_variants"
mkdir -p "$OUT_ROOT/logs"

echo "===== V007-NEXT50 YOLO11s E2E ====="
echo "DATA_YAML=$DATA_YAML"
echo "PRETRAIN=$PRETRAIN"
echo "OUT_ROOT=$OUT_ROOT"
echo "MAX_VARIANTS=50 fixed"
echo "EPOCHS=${EPOCHS:-200}"
echo "IMGSZ=${IMGSZ:-1280}"
echo "BATCH=${BATCH:-2}"
echo "WORKERS=${WORKERS:-4}"
echo "LR0=${LR0:-0.00035}"
echo "PYTORCH_CUDA_ALLOC_CONF=$PYTORCH_CUDA_ALLOC_CONF"

test -f "$DATA_YAML" || { echo "[FATAL] missing DATA_YAML"; exit 1; }
test -f "$PRETRAIN" || { echo "[FATAL] missing PRETRAIN"; exit 1; }

.venv/bin/python -m pip install -U pandas pyyaml tabulate >/dev/null

stdbuf -oL -eL .venv/bin/python tools_yolo11_v007_next50/10_v007_next50_variants.py \
  --local-ultralytics "$PWD/third_party/ultralytics" \
  --pretrain "$PRETRAIN" \
  --data "$DATA_YAML" \
  --out "$OUT_ROOT" \
  --epochs "${EPOCHS:-200}" \
  --imgsz "${IMGSZ:-1280}" \
  --batch "${BATCH:-2}" \
  --workers "${WORKERS:-4}" \
  --device "${DEVICE:-0}" \
  --lr0 "${LR0:-0.00035}" \
  --patience "${PATIENCE:-45}" \
  --yolo11s-map50 0.129 \
  --yolo11s-map50-95 0.038 \
  --v007-map50 0.163909 \
  --v007-map50-95 0.047748 \
  2>&1 | tee "$OUT_ROOT/logs/v007_next50_live.log"

echo
echo "===== FINAL SUMMARY ====="
cat "$OUT_ROOT/summary.md"

echo
echo "===== WINNERS OVER V007 BEST ====="
cat "$OUT_ROOT/winners_over_v007_best.csv"

echo
echo "===== OUTPUT FILES ====="
echo "$OUT_ROOT/summary.md"
echo "$OUT_ROOT/ranked_test.csv"
echo "$OUT_ROOT/winners_over_v007_best.csv"
echo "$OUT_ROOT/v007_next50_results.csv"
echo "$OUT_ROOT/v007_next50_variants.csv"
echo "$OUT_ROOT/logs/v007_next50_live.log"
