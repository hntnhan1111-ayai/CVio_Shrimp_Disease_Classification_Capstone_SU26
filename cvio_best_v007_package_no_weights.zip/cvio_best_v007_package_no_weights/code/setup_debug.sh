set -Eeuo pipefail
set -x

PROJECT_DIR="${PROJECT_DIR:-$HOME/notebooks/cvio_yolo11s_method_zoo}"
VENV_DIR="${VENV_DIR:-$PROJECT_DIR/.venv}"
PY_VER="${PY_VER:-3.12}"
RUN_SMOKE_TRAIN="${RUN_SMOKE_TRAIN:-0}"
RUN_FULL_BASELINE="${RUN_FULL_BASELINE:-0}"
RESET_VENV="${RESET_VENV:-1}"

trap 'echo "[FAILED] line=$LINENO cmd=$BASH_COMMAND exit=$?"' ERR

cd "$PROJECT_DIR"

unset PYTHONHOME || true
unset PYTHONPATH || true
export UV_LINK_MODE=copy
export PIP_DISABLE_PIP_VERSION_CHECK=1
export PYTHONNOUSERSITE=1
export PATH="$HOME/.local/bin:$PATH"

echo "===== SYSTEM ====="
pwd
which python || true
python --version || true
which uv || true
uv --version || true
which nvidia-smi || true
nvidia-smi || true

echo "===== INSTALL UV IF MISSING ====="
if ! command -v uv >/dev/null 2>&1; then
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi
uv --version

echo "===== CREATE UV PYTHON/VENV ====="
uv python install "$PY_VER" || true
if [ "$RESET_VENV" = "1" ]; then
  rm -rf "$VENV_DIR"
fi
uv venv "$VENV_DIR" --python "$PY_VER"
source "$VENV_DIR/bin/activate"

python - <<'PY'
import sys, platform
print(sys.executable)
print(sys.version)
print(platform.platform())
PY

echo "===== BASIC PACKAGING ====="
uv pip install --upgrade pip setuptools wheel packaging psutil pyyaml

echo "===== INSTALL TORCH ====="
uv pip uninstall -y torch torchvision torchaudio >/dev/null 2>&1 || true

# Ưu tiên CUDA 12.6. Nếu fail thì CUDA 12.1. Nếu vẫn fail thì báo rõ.
if nvidia-smi >/dev/null 2>&1; then
  (
    uv pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu126
  ) || (
    echo "[WARN] cu126 failed, trying cu121"
    uv pip uninstall -y torch torchvision torchaudio >/dev/null 2>&1 || true
    uv pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
  )
else
  uv pip install torch torchvision torchaudio
fi

python - <<'PY'
import torch
print("torch", torch.__version__)
print("torch cuda", torch.version.cuda)
print("cuda available", torch.cuda.is_available())
print("device count", torch.cuda.device_count())
if torch.cuda.is_available():
    print("gpu", torch.cuda.get_device_name(0))
else:
    raise SystemExit("CUDA is not available. Stop before installing/running YOLO training.")
PY

echo "===== INSTALL CORE DEPS ====="
uv pip install pandas numpy scipy scikit-learn matplotlib tqdm rich opencv-python-headless pillow ipython ipykernel jupyter pycocotools thop einops timm albumentations kagglehub requests charset-normalizer urllib3

echo "===== INSTALL ULTRALYTICS LOCAL OR PYPI ====="
if [ -d "third_party/ultralytics" ]; then
  uv pip install -e third_party/ultralytics
else
  uv pip install -U ultralytics
fi

echo "===== INSTALL SAHI + WBF ====="
if [ -d "third_party/sahi" ]; then
  uv pip install -e third_party/sahi || uv pip install sahi
else
  uv pip install sahi
fi
uv pip install ensemble-boxes || true

echo "===== IMPORT CHECK ====="
export PYTHONPATH="$PROJECT_DIR:$PYTHONPATH"
python - <<'PY'
from pathlib import Path
import sys
print("python", sys.executable)

import torch
print("torch", torch.__version__, "cuda", torch.cuda.is_available())
assert torch.cuda.is_available(), "torch CUDA unavailable"

import ultralytics
from ultralytics import YOLO
print("ultralytics", getattr(ultralytics, "__version__", "unknown"))
YOLO("yolo11s.pt").info()

import sahi
print("sahi ok")

try:
    import ensemble_boxes
    print("ensemble_boxes ok")
except Exception as e:
    print("ensemble_boxes warning", repr(e))

from cvio_yolo11s_zoo.registry import load_registry, list_experiments
from cvio_yolo11s_zoo.dataset import verify_yolo_dataset

reg = load_registry("cvio_yolo11s_zoo/registry/experiment_registry.yaml")
print("experiments", len(list_experiments(reg)))
ds = verify_yolo_dataset(reg["globals"]["data_yaml"])
print("dataset", ds["rows"])
print("bad", len(ds["bad"]))
if ds["bad"]:
    raise SystemExit(ds["bad"][:10])
PY

echo "===== DRY RUN ====="
python scripts/run_zoo_from_registry.py --dry-run

echo "===== DONE SETUP DEBUG OK ====="
