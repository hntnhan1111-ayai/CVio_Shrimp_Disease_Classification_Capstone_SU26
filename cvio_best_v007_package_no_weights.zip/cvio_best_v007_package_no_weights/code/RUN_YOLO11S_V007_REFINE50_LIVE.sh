#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:${PYTHONPATH:-}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"
V007_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants/runs_train/V007_C3k2SimAM_backbone_nomosaic_loc/weights/best.pt"

OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_v007_refine50_variants"
mkdir -p "$OUT_ROOT/logs"

echo "===== V007-REFINE50 YOLO11s E2E ====="
echo "DATA_YAML=$DATA_YAML"
echo "V007_WEIGHTS=$V007_WEIGHTS"
echo "OUT_ROOT=$OUT_ROOT"
echo "PYTORCH_CUDA_ALLOC_CONF=$PYTORCH_CUDA_ALLOC_CONF"

test -f "$DATA_YAML" || { echo "[FATAL] missing DATA_YAML"; exit 1; }
test -f "$V007_WEIGHTS" || { echo "[FATAL] missing V007_WEIGHTS"; exit 1; }

.venv/bin/python -m pip install -U pandas pyyaml tabulate >/dev/null

stdbuf -oL -eL .venv/bin/python tools_yolo11_v007_refine50/11_v007_refine50.py \
  --v007-weights "$V007_WEIGHTS" \
  --data "$DATA_YAML" \
  --out "$OUT_ROOT" \
  --device "${DEVICE:-0}" \
  --workers "${WORKERS:-4}" \
  --optimizer "${OPTIMIZER:-AdamW}" \
  --yolo11s-map50 0.129 \
  --yolo11s-map50-95 0.038 \
  --v007-map50 0.163909 \
  --v007-map50-95 0.047748 \
  2>&1 | tee "$OUT_ROOT/logs/v007_refine50_live.log"

echo
echo "===== FINAL SUMMARY ====="
cat "$OUT_ROOT/summary.md"

echo
echo "===== WINNERS OVER V007 BEST ====="
cat "$OUT_ROOT/winners_over_v007_best.csv"

echo
echo "===== OUTPUT FILES ====="
echo "$OUT_ROOT/summary.md"
echo "$OUT_ROOT/ranked_test.csv"
echo "$OUT_ROOT/winners_over_v007_best.csv"
echo "$OUT_ROOT/v007_refine50_results.csv"
echo "$OUT_ROOT/v007_refine50_variants.csv"
echo "$OUT_ROOT/logs/v007_refine50_live.log"
