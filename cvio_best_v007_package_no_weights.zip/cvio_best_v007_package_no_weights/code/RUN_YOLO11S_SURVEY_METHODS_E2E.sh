#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:$PWD/tools_paper_diag:$PWD/tools_yolo11_survey_methods:${PYTHONPATH:-}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"
YOLO11S_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt"

OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_v1"

# Existing YOLO11s audit from previous parallel run.
AUDIT_CSV="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/parallel_yolo11s_yolo26n_all_ideas/yolo11s_all_ideas/audit/AUDIT_BL1280_iou050_md1000/audit_queue.csv"

mkdir -p "$OUT_ROOT"

echo "===== PATH CHECK ====="
echo "DATA_YAML=$DATA_YAML"
echo "YOLO11S_WEIGHTS=$YOLO11S_WEIGHTS"
echo "OUT_ROOT=$OUT_ROOT"
echo "AUDIT_CSV=$AUDIT_CSV"

test -f "$DATA_YAML"
test -f "$YOLO11S_WEIGHTS"

echo
echo "===== INSTALL LIGHT DEPS ====="
.venv/bin/python -m pip install -U pandas pyyaml pillow numpy tqdm tabulate >/dev/null

echo
echo "===== 1) MAKE LABEL-V2 REVIEW PACK ====="
if [ -f "$AUDIT_CSV" ]; then
  .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
    --data "$DATA_YAML" \
    --out-root "$OUT_ROOT" \
    --audit-csv "$AUDIT_CSV" \
    --make-review \
    --topk 700
else
  echo "[WARN] audit CSV not found, skip label-v2 review pack."
fi

echo
echo "===== 2) MAKE TRUE TILE-AWARE DATASET FROM ORIGINAL LABELS ====="
.venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
  --data "$DATA_YAML" \
  --out-root "$OUT_ROOT" \
  --make-tiles \
  --tile "$TILE_SIZE" \
  --overlap "$TILE_OVERLAP" \
  --min-keep 0.30 \
  --min-box-px 2.0

echo
echo "===== 3) MAKE SUPER-RESOLUTION LANCZOS DATASET ====="
.venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
  --data "$DATA_YAML" \
  --out-root "$OUT_ROOT" \
  --make-sr \
  --sr-scale 2

TILE_DATA="$OUT_ROOT/tile${TILE_SIZE}_ov${TILE_OVERLAP/./p}/data.yaml"
SR_DATA="$OUT_ROOT/sr_x2/data.yaml"

echo
echo "===== 4) OPTIONAL APPLY LABEL-V2 ACTIONS ====="
ACTIONS_CSV="$OUT_ROOT/label_v2_review_pack/manual_label_actions.csv"
LABEL_V2_DATA="$OUT_ROOT/shrimp_yolo_labels_v2/data.yaml"

if [ -f "$ACTIONS_CSV" ]; then
  APPROVED_COUNT="$(python - <<PY
import pandas as pd
p="$ACTIONS_CSV"
df=pd.read_csv(p)
print(df["status"].astype(str).str.lower().isin(["done","apply","approved","yes"]).sum())
PY
)"
  echo "Approved label actions: $APPROVED_COUNT"

  if [ "$APPROVED_COUNT" -gt 0 ]; then
    .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
      --data "$DATA_YAML" \
      --out-root "$OUT_ROOT" \
      --apply-actions \
      --actions-csv "$ACTIONS_CSV" \
      --label-v2-out "$OUT_ROOT/shrimp_yolo_labels_v2"
  else
    echo "[SKIP] No approved label actions yet. Open review HTML and edit status=done first."
  fi
fi

echo
echo "===== 5) TRAIN/EVAL YOLO11s SURVEY METHODS ====="
TRAIN_ARGS=(
  --baseline "$YOLO11S_WEIGHTS"
  --data "$DATA_YAML"
  --out "$OUT_ROOT/train_eval"
  --device 0
  --tile-data "$TILE_DATA"
  --sr-data "$SR_DATA"
  --epochs "${EPOCHS:-80}"
  --final-epochs "${FINAL_EPOCHS:-200}"
  --batch-full "${BATCH_FULL:-2}"
  --batch-tile "${BATCH_TILE:-16}"
  --lr0 "${LR0:-0.0005}"
  --run-original-strong
  --run-tile-train
  --run-sr
  --anchor-map50 0.157789
  --anchor-map50-95 0.043617
)

if [ -f "$LABEL_V2_DATA" ]; then
  TRAIN_ARGS+=(--data-v2 "$LABEL_V2_DATA" --run-label-v2)
else
  echo "[INFO] LABEL_V2_DATA not found yet, label-v2 training will be skipped."
fi

.venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py "${TRAIN_ARGS[@]}"

echo
echo "===== FINAL SUMMARY ====="
cat "$OUT_ROOT/train_eval/summary.md"

echo
echo "===== OUTPUTS ====="
echo "Review HTML:"
echo "$OUT_ROOT/label_v2_review_pack/index.html"
echo
echo "Manual actions CSV:"
echo "$OUT_ROOT/label_v2_review_pack/manual_label_actions.csv"
echo
echo "Tile data:"
echo "$TILE_DATA"
echo
echo "SR data:"
echo "$SR_DATA"
echo
echo "Training summary:"
echo "$OUT_ROOT/train_eval/summary.md"
echo
echo "Winners:"
echo "$OUT_ROOT/train_eval/winners_over_yolo11s_calibrated.csv"
