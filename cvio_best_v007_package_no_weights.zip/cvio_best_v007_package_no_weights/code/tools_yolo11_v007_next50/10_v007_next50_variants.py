from __future__ import annotations

import argparse
import csv
import gc
import re
import time
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
import torch
import yaml


CUSTOM_NAMES = [
    "C3k2V7SimAMGate",
    "C3k2V7SimAMECA",
    "C3k2V7SimAMCoord",
    "C3k2V7MSDWSimAM",
    "C3k2V7DilatedSimAM",
    "C3k2V7RepDWSimAM",
    "C3k2V7ShrimpFocus",
    "C3k2V7TinyNodule",
    "C3k2V7DualGate",
    "C3k2V7UltraLight",
]


CUSTOM_MODULE_CODE = r'''
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.nn.modules.block import C3k2


class SimAM(nn.Module):
    """Parameter-free 3D attention."""

    def __init__(self, e_lambda=1e-4):
        super().__init__()
        self.e_lambda = e_lambda

    def forward(self, x):
        b, c, h, w = x.shape
        n = max(h * w - 1, 1)
        mu = x.mean(dim=(2, 3), keepdim=True)
        d = (x - mu).pow(2)
        v = d.sum(dim=(2, 3), keepdim=True) / n
        e_inv = d / (4 * (v + self.e_lambda)) + 0.5
        return x * torch.sigmoid(e_inv)


class ECA(nn.Module):
    """Efficient Channel Attention: local cross-channel interaction."""

    def __init__(self, channels, k_size=3):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(
            1,
            1,
            kernel_size=k_size,
            padding=(k_size - 1) // 2,
            bias=False,
        )

    def forward(self, x):
        y = self.pool(x)
        y = self.conv(y.squeeze(-1).transpose(-1, -2))
        y = torch.sigmoid(y.transpose(-1, -2).unsqueeze(-1))
        return x * y


class CoordLite(nn.Module):
    """BN-free coordinate attention to avoid 1x1 BatchNorm instability."""

    def __init__(self, channels, reduction=32):
        super().__init__()
        mip = max(8, channels // reduction)
        self.conv1 = nn.Conv2d(channels, mip, 1, bias=True)
        self.act = nn.SiLU(inplace=True)
        self.conv_h = nn.Conv2d(mip, channels, 1, bias=True)
        self.conv_w = nn.Conv2d(mip, channels, 1, bias=True)

    def forward(self, x):
        identity = x
        n, c, h, w = x.shape
        x_h = x.mean(dim=3, keepdim=True)
        x_w = x.mean(dim=2, keepdim=True).permute(0, 1, 3, 2)
        y = torch.cat([x_h, x_w], dim=2)
        y = self.act(self.conv1(y))
        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)
        a_h = torch.sigmoid(self.conv_h(x_h))
        a_w = torch.sigmoid(self.conv_w(x_w))
        return identity * a_h * a_w


class SpatialGateLite(nn.Module):
    """CBAM-like spatial gate, lightweight."""

    def __init__(self, kernel=7):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel, padding=kernel // 2, bias=False)

    def forward(self, x):
        avg = x.mean(dim=1, keepdim=True)
        mx, _ = x.max(dim=1, keepdim=True)
        s = torch.sigmoid(self.conv(torch.cat([avg, mx], dim=1)))
        return x * s


class MultiScaleDW(nn.Module):
    """Cheap multi-kernel local context for tiny lesions."""

    def __init__(self, channels):
        super().__init__()
        self.b3 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.b5 = nn.Conv2d(channels, channels, 5, padding=2, groups=channels, bias=False)
        self.bd = nn.Conv2d(channels, channels, 3, padding=2, dilation=2, groups=channels, bias=False)
        self.fuse = nn.Conv2d(channels * 3, channels, 1, bias=True)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        y = torch.cat([self.b3(x), self.b5(x), self.bd(x)], dim=1)
        return x + self.act(self.fuse(y))


class DilatedContext(nn.Module):
    """Small-object context branch with low overhead."""

    def __init__(self, channels):
        super().__init__()
        self.dw1 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.dw2 = nn.Conv2d(channels, channels, 3, padding=2, dilation=2, groups=channels, bias=False)
        self.pw = nn.Conv2d(channels * 2, channels, 1, bias=True)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        y = torch.cat([self.dw1(x), self.dw2(x)], dim=1)
        return x + self.act(self.pw(y))


class RepDWLite(nn.Module):
    """RepVGG-inspired depthwise multi-branch block, not deploy-reparameterized."""

    def __init__(self, channels):
        super().__init__()
        self.dw3 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.dw1 = nn.Conv2d(channels, channels, 1, padding=0, groups=channels, bias=False)
        self.pw = nn.Conv2d(channels, channels, 1, bias=True)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        return x + self.act(self.pw(self.dw3(x) + self.dw1(x) + x))


class ShrimpLocalContrast(nn.Module):
    """
    Custom CVio module:
    emphasizes tiny lesion-like local contrast before SimAM.
    This is intended for WSSV/BG small symptom spots.
    """

    def __init__(self, channels):
        super().__init__()
        self.smooth = nn.AvgPool2d(kernel_size=3, stride=1, padding=1)
        self.dw = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.pw = nn.Conv2d(channels * 2, channels, 1, bias=True)
        self.gate = nn.Conv2d(channels, channels, 1, bias=True)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        contrast = x - self.smooth(x)
        detail = self.dw(contrast)
        fused = self.act(self.pw(torch.cat([x, detail], dim=1)))
        g = torch.sigmoid(self.gate(fused))
        return x * (1.0 + g)


class TinyNoduleFocus(nn.Module):
    """
    Custom CVio module:
    point-like lesion focus using local max/mean contrast.
    """

    def __init__(self, channels):
        super().__init__()
        self.local_mean = nn.AvgPool2d(5, stride=1, padding=2)
        self.local_max = nn.MaxPool2d(5, stride=1, padding=2)
        self.mix = nn.Conv2d(channels * 3, channels, 1, bias=True)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        mean = self.local_mean(x)
        mx = self.local_max(x)
        y = self.act(self.mix(torch.cat([x, x - mean, mx - mean], dim=1)))
        return x + y


class LearnableGate(nn.Module):
    """Stable residual gate initialized small."""

    def __init__(self, init=0.10):
        super().__init__()
        self.alpha = nn.Parameter(torch.tensor(float(init)))

    def forward(self, base, refined):
        return base + torch.clamp(self.alpha, 0.0, 1.0) * (refined - base)


class _BaseC3k2V7(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__()
        self.block = C3k2(c1, c2, n, shortcut, e)

    def forward(self, x):
        return self.block(x)


class C3k2V7SimAMGate(_BaseC3k2V7):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.simam = SimAM()
        self.gate = LearnableGate(0.10)

    def forward(self, x):
        y = self.block(x)
        return self.gate(y, self.simam(y))


class C3k2V7SimAMECA(_BaseC3k2V7):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.refine = nn.Sequential(ECA(c2), SimAM())

    def forward(self, x):
        return self.refine(self.block(x))


class C3k2V7SimAMCoord(_BaseC3k2V7):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.coord = CoordLite(c2)
        self.simam = SimAM()
        self.gate = LearnableGate(0.08)

    def forward(self, x):
        y = self.block(x)
        r = self.simam(self.coord(y))
        return self.gate(y, r)


class C3k2V7MSDWSimAM(_BaseC3k2V7):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.ctx = MultiScaleDW(c2)
        self.simam = SimAM()
        self.eca = ECA(c2)

    def forward(self, x):
        y = self.block(x)
        return self.eca(self.simam(self.ctx(y)))


class C3k2V7DilatedSimAM(_BaseC3k2V7):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.ctx = DilatedContext(c2)
        self.simam = SimAM()
        self.gate = LearnableGate(0.10)

    def forward(self, x):
        y = self.block(x)
        return self.gate(y, self.simam(self.ctx(y)))


class C3k2V7RepDWSimAM(_BaseC3k2V7):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.rep = RepDWLite(c2)
        self.simam = SimAM()
        self.gate = LearnableGate(0.08)

    def forward(self, x):
        y = self.block(x)
        return self.gate(y, self.simam(self.rep(y)))


class C3k2V7ShrimpFocus(_BaseC3k2V7):
    """CVio-exclusive: local contrast + SimAM + residual gate."""

    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.focus = ShrimpLocalContrast(c2)
        self.simam = SimAM()
        self.gate = LearnableGate(0.08)

    def forward(self, x):
        y = self.block(x)
        r = self.simam(self.focus(y))
        return self.gate(y, r)


class C3k2V7TinyNodule(_BaseC3k2V7):
    """CVio-exclusive: local max/mean tiny-nodule focus + SimAM."""

    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.focus = TinyNoduleFocus(c2)
        self.simam = SimAM()
        self.eca = ECA(c2)

    def forward(self, x):
        y = self.block(x)
        return self.eca(self.simam(self.focus(y)))


class C3k2V7DualGate(_BaseC3k2V7):
    """CBAM-like spatial gate + ECA + SimAM."""

    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.spatial = SpatialGateLite(7)
        self.eca = ECA(c2)
        self.simam = SimAM()
        self.gate = LearnableGate(0.08)

    def forward(self, x):
        y = self.block(x)
        r = self.simam(self.eca(self.spatial(y)))
        return self.gate(y, r)


class C3k2V7UltraLight(_BaseC3k2V7):
    """Minimal V007 extension: SimAM + very small residual gate only."""

    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.simam = SimAM()
        self.gate = LearnableGate(0.05)

    def forward(self, x):
        y = self.block(x)
        return self.gate(y, self.simam(y))
'''


def patch_ultralytics(local_root: Path):
    pkg = local_root / "ultralytics"
    module_dir = pkg / "nn" / "modules"
    init_path = module_dir / "__init__.py"
    tasks_path = pkg / "nn" / "tasks.py"
    cvio_path = module_dir / "cvio_v007next.py"

    if not tasks_path.exists():
        raise FileNotFoundError(tasks_path)
    if not init_path.exists():
        raise FileNotFoundError(init_path)

    cvio_path.write_text(CUSTOM_MODULE_CODE, encoding="utf-8")

    init_text = init_path.read_text(encoding="utf-8")
    import_line = "from .cvio_v007next import " + ", ".join(CUSTOM_NAMES) + "  # noqa: F401\n"
    if "from .cvio_v007next import" not in init_text:
        init_text += "\n" + import_line
        init_path.write_text(init_text, encoding="utf-8")

    text = tasks_path.read_text(encoding="utf-8")

    if CUSTOM_NAMES[0] not in text.split("def parse_model", 1)[0]:
        marker = "C3k2,"
        if marker in text:
            text = text.replace(marker, marker + "\n    " + ",\n    ".join(CUSTOM_NAMES) + ",", 1)
        else:
            import_line2 = "from ultralytics.nn.modules.cvio_v007next import " + ", ".join(CUSTOM_NAMES) + "\n"
            text = import_line2 + text

    if "def parse_model" not in text:
        raise RuntimeError("Could not find parse_model() in tasks.py")

    pre, post = text.split("def parse_model", 1)

    if CUSTOM_NAMES[0] not in post:
        if "C3k2," not in post:
            raise RuntimeError("Could not find C3k2 inside parse_model(); inspect tasks.py manually.")
        insert_names = ", ".join(CUSTOM_NAMES)
        post = post.replace("C3k2,", "C3k2, " + insert_names + ",")

    text = pre + "def parse_model" + post
    tasks_path.write_text(text, encoding="utf-8")

    print("[PATCHED]", cvio_path)
    print("[PATCHED]", init_path)
    print("[PATCHED]", tasks_path)


def write_yaml(path: Path, obj: Dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(obj, sort_keys=False), encoding="utf-8")


def yolo11s_yaml(custom_module: str, layers_to_replace: List[int]) -> Dict[str, Any]:
    def m(layer_idx: int, default: str = "C3k2"):
        if default == "C3k2" and layer_idx in layers_to_replace:
            return custom_module
        return default

    return {
        "nc": 2,
        "backbone": [
            [-1, 1, "Conv", [32, 3, 2]],
            [-1, 1, "Conv", [64, 3, 2]],
            [-1, 1, m(2), [128, False, 0.25]],
            [-1, 1, "Conv", [128, 3, 2]],
            [-1, 1, m(4), [256, False, 0.25]],
            [-1, 1, "Conv", [256, 3, 2]],
            [-1, 1, m(6), [256, True]],
            [-1, 1, "Conv", [512, 3, 2]],
            [-1, 1, m(8), [512, True]],
            [-1, 1, "SPPF", [512, 5]],
            [-1, 1, "C2PSA", [512]],
        ],
        "head": [
            [-1, 1, "nn.Upsample", [None, 2, "nearest"]],
            [[-1, 6], 1, "Concat", [1]],
            [-1, 1, m(13), [256, False]],
            [-1, 1, "nn.Upsample", [None, 2, "nearest"]],
            [[-1, 4], 1, "Concat", [1]],
            [-1, 1, m(16), [128, False]],
            [-1, 1, "Conv", [128, 3, 2]],
            [[-1, 13], 1, "Concat", [1]],
            [-1, 1, m(19), [256, False]],
            [-1, 1, "Conv", [256, 3, 2]],
            [[-1, 10], 1, "Concat", [1]],
            [-1, 1, m(22), [512, True]],
            [[16, 19, 22], 1, "Detect", ["nc"]],
        ],
    }


def generate_variants(out_dir: Path, data: str) -> List[Dict[str, Any]]:
    placements = {
        "v007_backbone_468": [4, 6, 8],
        "backbone_68": [6, 8],
        "backbone_8_only": [8],
        "backbone_468_neck13": [4, 6, 8, 13],
        "backbone_468_head16": [4, 6, 8, 16],
    }

    variants = []
    idx = 1
    for mod in CUSTOM_NAMES:
        for place_name, layer_ids in placements.items():
            vid = f"N{idx:03d}_{mod}_{place_name}_nomosaic"
            yaml_path = out_dir / "configs" / f"{vid}.yaml"
            write_yaml(yaml_path, yolo11s_yaml(mod, layer_ids))
            variants.append(
                {
                    "id": vid,
                    "module": mod,
                    "placement": place_name,
                    "profile": "v007_nomosaic_loc",
                    "data": data,
                    "yaml": str(yaml_path),
                }
            )
            idx += 1

    return variants


def read_rows(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_rows(path: Path, rows: List[Dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = []
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def append_row(path: Path, row: Dict[str, Any]):
    rows = read_rows(path)
    rows.append(row)
    write_rows(path, rows)


def has_ok(path: Path, vid: str, phase: str) -> bool:
    return any(
        r.get("id") == vid and r.get("phase") == phase and r.get("status") == "ok"
        for r in read_rows(path)
    )


def train_kwargs(args):
    return dict(
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        device=args.device,
        workers=args.workers,
        optimizer="AdamW",
        lr0=args.lr0,
        cos_lr=True,
        patience=args.patience,
        seed=42,
        deterministic=True,
        amp=True,
        plots=False,
        verbose=True,
        mosaic=0.0,
        mixup=0.0,
        copy_paste=0.0,
        erasing=0.0,
        scale=0.20,
        degrees=3.0,
        translate=0.06,
        shear=0.5,
        perspective=0.0001,
        flipud=0.05,
        fliplr=0.50,
        box=10.0,
        cls=0.35,
        dfl=2.0,
        close_mosaic=0,
    )


def train_eval_variant(YOLO, v: Dict[str, Any], args, results_csv: Path):
    vid = v["id"]
    out = Path(args.out)
    run_dir = out / "runs_train" / vid
    best_pt = run_dir / "weights" / "best.pt"

    if not best_pt.exists() and not has_ok(results_csv, vid, "train"):
        print(f"\n===== TRAIN {vid} =====")
        t0 = time.time()
        try:
            model = YOLO(v["yaml"])
            model.load(args.pretrain)
            model.train(
                data=v["data"],
                project=str(out / "runs_train"),
                name=vid,
                exist_ok=True,
                **train_kwargs(args),
            )
            status = "ok" if best_pt.exists() else "missing_best"
            append_row(
                results_csv,
                {
                    **v,
                    "phase": "train",
                    "status": status,
                    "best_pt": str(best_pt),
                    "elapsed_sec": time.time() - t0,
                },
            )
        except Exception as e:
            append_row(
                results_csv,
                {
                    **v,
                    "phase": "train",
                    "status": "error",
                    "error_type": type(e).__name__,
                    "error_message": str(e),
                    "elapsed_sec": time.time() - t0,
                },
            )
            print(f"[ERROR TRAIN] {vid}: {type(e).__name__}: {e}")
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            return
        finally:
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
    else:
        print(f"[SKIP TRAIN] {vid}")

    if not best_pt.exists():
        print(f"[SKIP EVAL] {vid}: no best.pt")
        return

    eval_settings = [
        ("1536_iou055", 1536, 0.0005, 0.55, 600),
        ("1536_iou050", 1536, 0.0005, 0.50, 600),
        ("1280_iou055", 1280, 0.0005, 0.55, 600),
        ("1280_iou050", 1280, 0.0005, 0.50, 600),
    ]

    for split in ["val", "test"]:
        for tag, imgsz, conf, iou, max_det in eval_settings:
            phase = f"eval_{split}_{tag}"
            if has_ok(results_csv, vid, phase):
                print(f"[SKIP EVAL] {vid} {phase}")
                continue

            print(f"\n===== EVAL {vid} {split} {tag} =====")
            t0 = time.time()
            try:
                model = YOLO(str(best_pt))
                m = model.val(
                    data=v["data"],
                    split=split,
                    imgsz=imgsz,
                    conf=conf,
                    iou=iou,
                    max_det=max_det,
                    device=args.device,
                    batch=1,
                    workers=4,
                    half=True,
                    plots=False,
                    save_json=False,
                    verbose=False,
                )
                maps = getattr(m.box, "maps", [])
                append_row(
                    results_csv,
                    {
                        **v,
                        "phase": phase,
                        "status": "ok",
                        "best_pt": str(best_pt),
                        "split": split,
                        "eval_tag": tag,
                        "eval_imgsz": imgsz,
                        "eval_conf": conf,
                        "eval_iou": iou,
                        "eval_max_det": max_det,
                        "map50": float(m.box.map50),
                        "map50_95": float(m.box.map),
                        "map75": float(m.box.map75),
                        "precision": float(m.box.mp),
                        "recall": float(m.box.mr),
                        "ap_BG": float(maps[0]) if len(maps) > 0 else "",
                        "ap_WSSV": float(maps[1]) if len(maps) > 1 else "",
                        "elapsed_sec": time.time() - t0,
                    },
                )
            except Exception as e:
                append_row(
                    results_csv,
                    {
                        **v,
                        "phase": phase,
                        "status": "error",
                        "split": split,
                        "eval_tag": tag,
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "elapsed_sec": time.time() - t0,
                    },
                )
                print(f"[ERROR EVAL] {vid} {phase}: {type(e).__name__}: {e}")
            finally:
                gc.collect()
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()


def summarize(out_dir: Path, yolo11s50: float, yolo11s5095: float, v00750: float, v0075095: float):
    p = out_dir / "v007_next50_results.csv"
    if not p.exists():
        return

    df = pd.read_csv(p)
    ok = df[(df["status"] == "ok") & (df["phase"].astype(str).str.startswith("eval_test"))].copy()
    if ok.empty:
        (out_dir / "summary.md").write_text("# No OK test eval rows yet\n", encoding="utf-8")
        return

    for c in ["map50", "map50_95", "map75", "precision", "recall"]:
        ok[c] = pd.to_numeric(ok[c], errors="coerce")

    ok["delta_map50_vs_yolo11s_original"] = ok["map50"] - yolo11s50
    ok["delta_map50_95_vs_yolo11s_original"] = ok["map50_95"] - yolo11s5095
    ok["delta_map50_vs_v007_best"] = ok["map50"] - v00750
    ok["delta_map50_95_vs_v007_best"] = ok["map50_95"] - v0075095

    ok = ok.sort_values(["map50_95", "map50"], ascending=False)
    winners_v007 = ok[(ok["map50"] > v00750) & (ok["map50_95"] > v0075095)].copy()

    ok.to_csv(out_dir / "ranked_test.csv", index=False)
    winners_v007.to_csv(out_dir / "winners_over_v007_best.csv", index=False)

    cols = [
        "id", "module", "placement", "eval_tag",
        "map50", "map50_95", "map75", "precision", "recall",
        "delta_map50_vs_yolo11s_original",
        "delta_map50_95_vs_yolo11s_original",
        "delta_map50_vs_v007_best",
        "delta_map50_95_vs_v007_best",
        "best_pt",
    ]
    cols = [c for c in cols if c in ok.columns]

    md = []
    md.append("# V007-Next50 YOLO11s Summary\n")
    md.append(f"- Original YOLO11s baseline mAP50: `{yolo11s50}`")
    md.append(f"- Original YOLO11s baseline mAP50-95: `{yolo11s5095}`")
    md.append(f"- Current V007 best mAP50: `{v00750}`")
    md.append(f"- Current V007 best mAP50-95: `{v0075095}`")
    md.append(f"- OK test eval rows: `{len(ok)}`")
    md.append(f"- Winners over V007 best on both metrics: `{len(winners_v007)}`\n")

    md.append("## Top 40 test rows\n")
    md.append(ok[cols].head(40).to_markdown(index=False, floatfmt=".6f"))

    md.append("\n## Winners over current V007 best\n")
    if len(winners_v007):
        md.append(winners_v007[cols].to_markdown(index=False, floatfmt=".6f"))
    else:
        md.append("_No winner over V007 best yet._")

    md.append("\n## Best row per module\n")
    best_each = ok.groupby("module", as_index=False).head(1)
    md.append(best_each[cols].to_markdown(index=False, floatfmt=".6f"))

    (out_dir / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print("[DONE]", out_dir / "summary.md")
    print("[DONE]", out_dir / "ranked_test.csv")
    print("[DONE]", out_dir / "winners_over_v007_best.csv")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--local-ultralytics", default="third_party/ultralytics")
    ap.add_argument("--pretrain", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--imgsz", type=int, default=1280)
    ap.add_argument("--batch", type=int, default=2)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--device", default="0")
    ap.add_argument("--lr0", type=float, default=0.00035)
    ap.add_argument("--patience", type=int, default=45)
    ap.add_argument("--yolo11s-map50", type=float, default=0.129)
    ap.add_argument("--yolo11s-map50-95", type=float, default=0.038)
    ap.add_argument("--v007-map50", type=float, default=0.163909)
    ap.add_argument("--v007-map50-95", type=float, default=0.047748)
    args = ap.parse_args()

    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    patch_ultralytics(Path(args.local_ultralytics).resolve())

    import py_compile
    py_compile.compile(
        str(Path(args.local_ultralytics).resolve() / "ultralytics" / "nn" / "modules" / "cvio_v007next.py"),
        doraise=True,
    )
    py_compile.compile(
        str(Path(args.local_ultralytics).resolve() / "ultralytics" / "nn" / "tasks.py"),
        doraise=True,
    )

    from ultralytics import YOLO

    variants = generate_variants(out_dir, args.data)
    pd.DataFrame(variants).to_csv(out_dir / "v007_next50_variants.csv", index=False)
    print("[INFO] total variants:", len(variants))
    print("[DONE]", out_dir / "v007_next50_variants.csv")

    results_csv = out_dir / "v007_next50_results.csv"

    for i, v in enumerate(variants, start=1):
        print("\n" + "#" * 90)
        print(f"### V007-NEXT VARIANT {i}/{len(variants)}: {v['id']}")
        print("#" * 90)
        train_eval_variant(YOLO, v, args, results_csv)
        summarize(out_dir, args.yolo11s_map50, args.yolo11s_map50_95, args.v007_map50, args.v007_map50_95)

    summarize(out_dir, args.yolo11s_map50, args.yolo11s_map50_95, args.v007_map50, args.v007_map50_95)


if __name__ == "__main__":
    main()
