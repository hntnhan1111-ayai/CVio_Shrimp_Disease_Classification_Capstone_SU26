#!/usr/bin/env bash
set -u

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:$PWD/tools_paper_diag:$PWD/tools_yolo11_survey_methods:${PYTHONPATH:-}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"
YOLO11S_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt"

OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200"
AUDIT_CSV="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/parallel_yolo11s_yolo26n_all_ideas/yolo11s_all_ideas/audit/AUDIT_BL1280_iou050_md1000/audit_queue.csv"

TILE_SIZE="${TILE_SIZE:-640}"
TILE_OVERLAP="${TILE_OVERLAP:-0.35}"
EPOCHS="${EPOCHS:-200}"
FINAL_EPOCHS="${FINAL_EPOCHS:-200}"
BATCH_FULL="${BATCH_FULL:-2}"
BATCH_TILE="${BATCH_TILE:-16}"
LR0="${LR0:-0.0005}"

mkdir -p "$OUT_ROOT/logs"

MAIN_LOG="$OUT_ROOT/logs/final200_main.log"
STATUS_LOG="$OUT_ROOT/logs/final200_status.tsv"

echo -e "stage\tstatus\ttime" > "$STATUS_LOG"

log_stage() {
  local stage="$1"
  local status="$2"
  echo -e "${stage}\t${status}\t$(date '+%F %T')" | tee -a "$STATUS_LOG"
}

run_stage() {
  local stage="$1"
  shift

  echo
  echo "===== RUN STAGE: $stage =====" | tee -a "$MAIN_LOG"
  log_stage "$stage" "START"

  "$@" > "$OUT_ROOT/logs/${stage}.log" 2>&1
  local code=$?

  if [ "$code" -eq 0 ]; then
    log_stage "$stage" "OK"
    echo "[OK] $stage" | tee -a "$MAIN_LOG"
  else
    log_stage "$stage" "ERROR_CODE_${code}"
    echo "[ERROR] $stage code=$code. See $OUT_ROOT/logs/${stage}.log" | tee -a "$MAIN_LOG"
  fi

  return 0
}

echo "===== PATH CHECK =====" | tee "$MAIN_LOG"
echo "DATA_YAML=$DATA_YAML" | tee -a "$MAIN_LOG"
echo "YOLO11S_WEIGHTS=$YOLO11S_WEIGHTS" | tee -a "$MAIN_LOG"
echo "OUT_ROOT=$OUT_ROOT" | tee -a "$MAIN_LOG"
echo "AUDIT_CSV=$AUDIT_CSV" | tee -a "$MAIN_LOG"
echo "TILE_SIZE=$TILE_SIZE" | tee -a "$MAIN_LOG"
echo "TILE_OVERLAP=$TILE_OVERLAP" | tee -a "$MAIN_LOG"
echo "EPOCHS=$EPOCHS" | tee -a "$MAIN_LOG"
echo "FINAL_EPOCHS=$FINAL_EPOCHS" | tee -a "$MAIN_LOG"
echo "BATCH_FULL=$BATCH_FULL" | tee -a "$MAIN_LOG"
echo "BATCH_TILE=$BATCH_TILE" | tee -a "$MAIN_LOG"
echo "LR0=$LR0" | tee -a "$MAIN_LOG"

test -f "$DATA_YAML" || { echo "[FATAL] missing DATA_YAML"; exit 1; }
test -f "$YOLO11S_WEIGHTS" || { echo "[FATAL] missing YOLO11S_WEIGHTS"; exit 1; }

echo
echo "===== INSTALL LIGHT DEPS =====" | tee -a "$MAIN_LOG"
.venv/bin/python -m pip install -U pandas pyyaml pillow numpy tqdm tabulate >/dev/null

# ---------------------------------------------------------------------
# 1) Data preparation
# ---------------------------------------------------------------------

if [ -f "$AUDIT_CSV" ]; then
  run_stage "01_make_label_v2_review_pack" \
    .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
      --data "$DATA_YAML" \
      --out-root "$OUT_ROOT" \
      --audit-csv "$AUDIT_CSV" \
      --make-review \
      --topk 700
else
  echo "[WARN] audit CSV not found; skip label-v2 review pack." | tee -a "$MAIN_LOG"
fi

run_stage "02_make_tile_dataset" \
  .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
    --data "$DATA_YAML" \
    --out-root "$OUT_ROOT" \
    --make-tiles \
    --tile "$TILE_SIZE" \
    --overlap "$TILE_OVERLAP" \
    --min-keep 0.30 \
    --min-box-px 2.0

run_stage "03_make_sr_lanczos_x2_dataset" \
  .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
    --data "$DATA_YAML" \
    --out-root "$OUT_ROOT" \
    --make-sr \
    --sr-scale 2

TILE_DATA="$OUT_ROOT/tile${TILE_SIZE}_ov${TILE_OVERLAP/./p}/data.yaml"
SR_DATA="$OUT_ROOT/sr_x2/data.yaml"
ACTIONS_CSV="$OUT_ROOT/label_v2_review_pack/manual_label_actions.csv"
LABEL_V2_DATA="$OUT_ROOT/shrimp_yolo_labels_v2/data.yaml"

# ---------------------------------------------------------------------
# 2) Apply label-v2 actions only if user has approved rows.
# ---------------------------------------------------------------------

if [ -f "$ACTIONS_CSV" ]; then
  APPROVED_COUNT="$(.venv/bin/python - <<PY
import pandas as pd
p="$ACTIONS_CSV"
df=pd.read_csv(p)
print(df["status"].astype(str).str.lower().isin(["done","apply","approved","yes"]).sum())
PY
)"
  echo "Approved label actions: $APPROVED_COUNT" | tee -a "$MAIN_LOG"

  if [ "$APPROVED_COUNT" -gt 0 ]; then
    run_stage "04_apply_label_v2_actions" \
      .venv/bin/python tools_yolo11_survey_methods/06_prepare_yolo11s_survey_data.py \
        --data "$DATA_YAML" \
        --out-root "$OUT_ROOT" \
        --apply-actions \
        --actions-csv "$ACTIONS_CSV" \
        --label-v2-out "$OUT_ROOT/shrimp_yolo_labels_v2"
  else
    echo "[SKIP] label-v2 apply: no approved rows yet." | tee -a "$MAIN_LOG"
  fi
else
  echo "[SKIP] actions CSV not found yet." | tee -a "$MAIN_LOG"
fi

# ---------------------------------------------------------------------
# 3) Full 200-epoch training stages
# ---------------------------------------------------------------------

COMMON_ARGS=(
  --baseline "$YOLO11S_WEIGHTS"
  --data "$DATA_YAML"
  --out "$OUT_ROOT/train_eval"
  --device 0
  --epochs "$EPOCHS"
  --final-epochs "$FINAL_EPOCHS"
  --batch-full "$BATCH_FULL"
  --batch-tile "$BATCH_TILE"
  --lr0 "$LR0"
  --anchor-map50 0.157789
  --anchor-map50-95 0.043617
)

# Stage A: original dataset + strong augmentation, 200 epochs.
run_stage "05_train_original_strongaug_200ep" \
  .venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py \
    "${COMMON_ARGS[@]}" \
    --run-original-strong

# Stage B: true tile-aware training, 200 epochs.
if [ -f "$TILE_DATA" ]; then
  run_stage "06_train_tileaware_200ep" \
    .venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py \
      "${COMMON_ARGS[@]}" \
      --tile-data "$TILE_DATA" \
      --run-tile-train
else
  echo "[SKIP] tile data missing: $TILE_DATA" | tee -a "$MAIN_LOG"
fi

# Stage C: Lanczos SR x2 training, 200 epochs.
if [ -f "$SR_DATA" ]; then
  run_stage "07_train_sr_lanczos_x2_200ep" \
    .venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py \
      "${COMMON_ARGS[@]}" \
      --sr-data "$SR_DATA" \
      --run-sr
else
  echo "[SKIP] SR data missing: $SR_DATA" | tee -a "$MAIN_LOG"
fi

# Stage D: label-v2 training, 200 epochs, only if manual review has been applied.
if [ -f "$LABEL_V2_DATA" ]; then
  run_stage "08_train_labelv2_200ep" \
    .venv/bin/python tools_yolo11_survey_methods/07_train_eval_yolo11s_survey_methods.py \
      "${COMMON_ARGS[@]}" \
      --data-v2 "$LABEL_V2_DATA" \
      --run-label-v2
else
  echo "[SKIP] label-v2 data missing. Review HTML and approve actions first." | tee -a "$MAIN_LOG"
fi

# ---------------------------------------------------------------------
# 4) Final reporting
# ---------------------------------------------------------------------

echo
echo "===== FINAL STATUS =====" | tee -a "$MAIN_LOG"
cat "$STATUS_LOG" | tee -a "$MAIN_LOG"

echo
echo "===== FINAL SUMMARY =====" | tee -a "$MAIN_LOG"
if [ -f "$OUT_ROOT/train_eval/summary.md" ]; then
  cat "$OUT_ROOT/train_eval/summary.md" | tee -a "$MAIN_LOG"
else
  echo "[WARN] summary.md not found" | tee -a "$MAIN_LOG"
fi

echo
echo "===== OUTPUTS =====" | tee -a "$MAIN_LOG"
echo "Review HTML: $OUT_ROOT/label_v2_review_pack/index.html" | tee -a "$MAIN_LOG"
echo "Manual actions CSV: $OUT_ROOT/label_v2_review_pack/manual_label_actions.csv" | tee -a "$MAIN_LOG"
echo "Tile data: $TILE_DATA" | tee -a "$MAIN_LOG"
echo "SR data: $SR_DATA" | tee -a "$MAIN_LOG"
echo "Training summary: $OUT_ROOT/train_eval/summary.md" | tee -a "$MAIN_LOG"
echo "Winners: $OUT_ROOT/train_eval/winners_over_yolo11s_calibrated.csv" | tee -a "$MAIN_LOG"
echo "Logs: $OUT_ROOT/logs/" | tee -a "$MAIN_LOG"
