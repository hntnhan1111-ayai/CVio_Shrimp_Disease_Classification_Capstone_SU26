#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:$PWD/tools_paper_diag:$PWD/tools_baseline_breakthrough:${PYTHONPATH:-}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"

YOLO11S_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt"

YOLO26N_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_od_yolo_14models_200ep_canonical_rebuild_kaggle_rtx4090_v1/runs_train_200ep/yolo26n_canonical2cls_split701515_img1024_ep200_b8_seed42/weights/best.pt"

OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/parallel_yolo11s_yolo26n_all_ideas"
mkdir -p "$OUT_ROOT"

echo "===== PATH CHECK ====="
echo "DATA_YAML=$DATA_YAML"
echo "YOLO11S_WEIGHTS=$YOLO11S_WEIGHTS"
echo "YOLO26N_WEIGHTS=$YOLO26N_WEIGHTS"
echo "OUT_ROOT=$OUT_ROOT"

test -f "$DATA_YAML"

if [ ! -f "$YOLO11S_WEIGHTS" ]; then
  echo "[WARN] YOLO11s locked weight not found. Searching fallback..."
  YOLO11S_WEIGHTS="$(find /home/drnguyenvinh/notebooks -path '*yolo11s*weights/best.pt' | head -n 1)"
fi

if [ ! -f "$YOLO26N_WEIGHTS" ]; then
  echo "[WARN] YOLO26n weight not found. Searching fallback..."
  YOLO26N_WEIGHTS="$(find /home/drnguyenvinh/notebooks -path '*yolo26n*weights/best.pt' | head -n 1)"
fi

test -f "$YOLO11S_WEIGHTS"
test -f "$YOLO26N_WEIGHTS"

echo
echo "===== FINAL WEIGHTS ====="
echo "YOLO11S_WEIGHTS=$YOLO11S_WEIGHTS"
echo "YOLO26N_WEIGHTS=$YOLO26N_WEIGHTS"

echo
echo "===== INSTALL LIGHT DEPS ====="
.venv/bin/python -m pip install -U pandas pyyaml pillow numpy tqdm tabulate >/dev/null

echo
echo "===== RUN YOLO11s ALL IDEAS ====="
.venv/bin/python tools_baseline_breakthrough/04_baseline_breakthrough_e2e.py \
  --data "$DATA_YAML" \
  --baseline "$YOLO11S_WEIGHTS" \
  --out "$OUT_ROOT/yolo11s_all_ideas" \
  --splits val,test \
  --device 0 \
  --run-fullres \
  --run-sahi \
  --run-nwd \
  --run-classwise \
  --run-audit \
  --anchor-map50 0.157789 \
  --anchor-map50-95 0.043617

echo
echo "===== RUN YOLO26n ALL IDEAS ====="
.venv/bin/python tools_baseline_breakthrough/04_baseline_breakthrough_e2e.py \
  --data "$DATA_YAML" \
  --baseline "$YOLO26N_WEIGHTS" \
  --out "$OUT_ROOT/yolo26n_all_ideas" \
  --splits val,test \
  --device 0 \
  --run-fullres \
  --run-sahi \
  --run-nwd \
  --run-classwise \
  --run-audit \
  --anchor-map50 0.157789 \
  --anchor-map50-95 0.043617

echo
echo "===== MERGE YOLO11s + YOLO26n RESULTS ====="
.venv/bin/python - <<'PY'
from pathlib import Path
import pandas as pd

OUT_ROOT = Path("/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/parallel_yolo11s_yolo26n_all_ideas")

sources = [
    ("YOLO11s", OUT_ROOT / "yolo11s_all_ideas" / "breakthrough_results.csv"),
    ("YOLO26n", OUT_ROOT / "yolo26n_all_ideas" / "breakthrough_results.csv"),
]

frames = []
for model, p in sources:
    if not p.exists():
        print("[MISSING]", p)
        continue
    df = pd.read_csv(p)
    df["model_family"] = model
    frames.append(df)

if not frames:
    raise SystemExit("No result CSV found.")

df = pd.concat(frames, ignore_index=True)

for c in ["map50", "map50_95", "map75", "precision", "recall", "elapsed_sec", "imgsz", "conf", "iou", "max_det", "tile", "overlap"]:
    if c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")

ANCHOR50 = 0.157789
ANCHOR5095 = 0.043617

df["delta_vs_yolo11s_calibrated_map50"] = df["map50"] - ANCHOR50
df["delta_vs_yolo11s_calibrated_map50_95"] = df["map50_95"] - ANCHOR5095

all_csv = OUT_ROOT / "parallel_all_results.csv"
df.to_csv(all_csv, index=False)

test = df[(df["split"] == "test") & (df["status"] == "ok")].copy()
test = test.sort_values(["map50_95", "map50"], ascending=False)

ranked_csv = OUT_ROOT / "parallel_ranked_test.csv"
test.to_csv(ranked_csv, index=False)

winners = test[
    (test["map50"] > ANCHOR50) &
    (test["map50_95"] > ANCHOR5095)
].copy()

winners_csv = OUT_ROOT / "parallel_winners_over_yolo11s_calibrated.csv"
winners.to_csv(winners_csv, index=False)

cols = [
    "model_family", "id", "stage", "type", "split",
    "imgsz", "conf", "iou", "max_det", "tile", "overlap",
    "include_full", "post_method", "post_metric", "post_thr",
    "map50", "map50_95", "map75",
    "delta_vs_yolo11s_calibrated_map50",
    "delta_vs_yolo11s_calibrated_map50_95",
    "num_gt", "num_pred", "elapsed_sec"
]
cols = [c for c in cols if c in test.columns]

def md_table(x, cols, n=40):
    if x.empty:
        return "_No rows._"
    y = x[cols].head(n).copy()
    return y.to_markdown(index=False, floatfmt=".6f")

md = []
md.append("# Parallel YOLO11s vs YOLO26n All-Ideas Comparison\n")
md.append("## Fair milestone\n")
md.append(f"- YOLO11s calibrated mAP50: `{ANCHOR50}`")
md.append(f"- YOLO11s calibrated mAP50-95: `{ANCHOR5095}`\n")

md.append("## Best test rows across both families\n")
md.append(md_table(test, cols, 50))

md.append("\n## Rows beating YOLO11s calibrated on both mAP50 and mAP50-95\n")
md.append(md_table(winners, cols, 50))

md.append("\n## Best row per model family\n")
best_each = test.sort_values(["map50_95", "map50"], ascending=False).groupby("model_family", as_index=False).head(1)
md.append(md_table(best_each, cols, 10))

md.append("\n## Decision rule\n")
md.append("- If YOLO26n beats YOLO11s calibrated on both metrics, YOLO26n becomes the new lightweight milestone.")
md.append("- If YOLO26n is below YOLO11s but faster/smaller, report it as an edge-efficiency trade-off.")
md.append("- If both families plateau around the same score, stop inference-only tuning and move to label_v2 + true tile-aware training.")

summary = OUT_ROOT / "parallel_summary.md"
summary.write_text("\n".join(md), encoding="utf-8")

print("[DONE]", all_csv)
print("[DONE]", ranked_csv)
print("[DONE]", winners_csv)
print("[DONE]", summary)
PY

echo
echo "===== FINAL PARALLEL SUMMARY ====="
cat "$OUT_ROOT/parallel_summary.md"

echo
echo "===== OUTPUT FILES ====="
echo "$OUT_ROOT/parallel_summary.md"
echo "$OUT_ROOT/parallel_ranked_test.csv"
echo "$OUT_ROOT/parallel_winners_over_yolo11s_calibrated.csv"
echo "$OUT_ROOT/yolo11s_all_ideas/audit/AUDIT_BL1280_iou050_md1000/index.html"
echo "$OUT_ROOT/yolo26n_all_ideas/audit/AUDIT_BL1280_iou050_md1000/index.html"
