from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Any, List, Tuple

from ultralytics import YOLO

from common_diag import (
    resolve_split_images,
    load_gt_for_image,
    area_bin,
    box_iou,
    voc_ap,
    write_csv,
    write_jsonl,
    md_table,
    get_class_names,
)


def parse_model_arg(s: str) -> Tuple[str, str]:
    if "=" not in s:
        raise ValueError("--model must be tag=/path/to/weights.pt")
    tag, path = s.split("=", 1)
    return tag.strip(), path.strip()


def predict_all(model_tag: str, weights: str, images: List[Path], args) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    model = YOLO(weights)

    all_gt = []
    all_pred = []

    for idx, img in enumerate(images):
        if idx % 25 == 0:
            print(f"[{model_tag}] predicting {idx}/{len(images)}")

        gts = load_gt_for_image(img)
        for j, g in enumerate(gts):
            g = dict(g)
            g["gt_id"] = f"{img.name}::gt{j}"
            g["model"] = model_tag
            g["bin"] = area_bin(g["area"], args.tiny_area, args.small_area)
            all_gt.append(g)

        result = model.predict(
            source=str(img),
            imgsz=args.imgsz,
            conf=args.conf,
            iou=args.iou,
            max_det=args.max_det,
            device=args.device,
            verbose=False,
        )[0]

        if result.boxes is None:
            continue

        for k, b in enumerate(result.boxes):
            xyxy = [float(x) for x in b.xyxy[0].detach().cpu().tolist()]
            conf = float(b.conf.item())
            cls = int(b.cls.item())
            x1, y1, x2, y2 = xyxy
            area = max(0.0, x2 - x1) * max(0.0, y2 - y1)
            all_pred.append({
                "pred_id": f"{img.name}::pred{k}",
                "model": model_tag,
                "image": str(img),
                "image_name": img.name,
                "cls": cls,
                "conf": conf,
                "xyxy": xyxy,
                "area": area,
                "bin": area_bin(area, args.tiny_area, args.small_area),
            })

    return all_gt, all_pred


def compute_ap_for_class_bin(gts, preds, cls_id: int, bin_name: str, iou_thr: float) -> float:
    gt_subset = [g for g in gts if g["cls"] == cls_id and g["bin"] == bin_name]
    pred_subset = [p for p in preds if p["cls"] == cls_id and p["bin"] == bin_name]

    n_gt = len(gt_subset)
    if n_gt == 0:
        return float("nan")

    gt_by_image = {}
    for g in gt_subset:
        gt_by_image.setdefault(g["image_name"], []).append(g)

    matched = set()
    pred_subset = sorted(pred_subset, key=lambda x: x["conf"], reverse=True)

    tp = []
    fp = []

    for p in pred_subset:
        candidates = gt_by_image.get(p["image_name"], [])
        best_iou = 0.0
        best_gt = None

        for g in candidates:
            if g["gt_id"] in matched:
                continue
            iou = box_iou(p["xyxy"], g["xyxy"])
            if iou > best_iou:
                best_iou = iou
                best_gt = g

        if best_gt is not None and best_iou >= iou_thr:
            matched.add(best_gt["gt_id"])
            tp.append(1)
            fp.append(0)
        else:
            tp.append(0)
            fp.append(1)

    if not tp:
        return 0.0

    cum_tp = []
    cum_fp = []
    a = b = 0
    for t, f in zip(tp, fp):
        a += t
        b += f
        cum_tp.append(a)
        cum_fp.append(b)

    rec = [x / n_gt for x in cum_tp]
    prec = [cum_tp[i] / max(cum_tp[i] + cum_fp[i], 1) for i in range(len(cum_tp))]
    return voc_ap(rec, prec)


def compute_recall_fn_for_class_bin(gts, preds, cls_id: int, bin_name: str, iou_thr: float = 0.5):
    gt_subset = [g for g in gts if g["cls"] == cls_id and g["bin"] == bin_name]
    pred_subset = [p for p in preds if p["cls"] == cls_id]

    n_gt = len(gt_subset)
    if n_gt == 0:
        return {
            "n_gt": 0,
            "tp_gt": 0,
            "fn_gt": 0,
            "recall50": float("nan"),
        }

    preds_by_image = {}
    for p in sorted(pred_subset, key=lambda x: x["conf"], reverse=True):
        preds_by_image.setdefault(p["image_name"], []).append(p)

    matched_gt = set()
    used_pred = set()

    for g in gt_subset:
        best_iou = 0.0
        best_pred_id = None
        for p in preds_by_image.get(g["image_name"], []):
            if p["pred_id"] in used_pred:
                continue
            iou = box_iou(p["xyxy"], g["xyxy"])
            if iou > best_iou:
                best_iou = iou
                best_pred_id = p["pred_id"]
        if best_pred_id is not None and best_iou >= iou_thr:
            matched_gt.add(g["gt_id"])
            used_pred.add(best_pred_id)

    tp_gt = len(matched_gt)
    fn_gt = n_gt - tp_gt
    return {
        "n_gt": n_gt,
        "tp_gt": tp_gt,
        "fn_gt": fn_gt,
        "recall50": tp_gt / n_gt if n_gt else float("nan"),
    }


def summarize(model_tag: str, gts, preds, class_names: Dict[int, str]) -> List[Dict[str, Any]]:
    bins = ["tiny", "small", "medium_large"]
    classes = sorted(set([g["cls"] for g in gts]))
    iou_thrs = [0.50 + 0.05 * i for i in range(10)]

    rows = []

    for bin_name in bins:
        for cls_id in classes:
            aps = []
            for thr in iou_thrs:
                ap = compute_ap_for_class_bin(gts, preds, cls_id, bin_name, thr)
                if ap == ap:
                    aps.append(ap)

            ap50 = compute_ap_for_class_bin(gts, preds, cls_id, bin_name, 0.50)
            rec = compute_recall_fn_for_class_bin(gts, preds, cls_id, bin_name, 0.50)

            rows.append({
                "model": model_tag,
                "bin": bin_name,
                "class_id": cls_id,
                "class_name": class_names.get(cls_id, str(cls_id)),
                "n_gt": rec["n_gt"],
                "tp_gt_at50": rec["tp_gt"],
                "fn_gt_at50": rec["fn_gt"],
                "recall50": rec["recall50"],
                "ap50": ap50,
                "map50_95": sum(aps) / len(aps) if aps else float("nan"),
            })

        # macro over classes with n_gt > 0
        bin_rows = [r for r in rows if r["model"] == model_tag and r["bin"] == bin_name and r["n_gt"] > 0]
        if bin_rows:
            rows.append({
                "model": model_tag,
                "bin": bin_name,
                "class_id": "macro",
                "class_name": "macro",
                "n_gt": sum(int(r["n_gt"]) for r in bin_rows),
                "tp_gt_at50": sum(int(r["tp_gt_at50"]) for r in bin_rows),
                "fn_gt_at50": sum(int(r["fn_gt_at50"]) for r in bin_rows),
                "recall50": sum(float(r["recall50"]) for r in bin_rows) / len(bin_rows),
                "ap50": sum(float(r["ap50"]) for r in bin_rows) / len(bin_rows),
                "map50_95": sum(float(r["map50_95"]) for r in bin_rows) / len(bin_rows),
            })

    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--split", default="test")
    ap.add_argument("--model", action="append", required=True, help="tag=/path/to/weights.pt")
    ap.add_argument("--out", default="paper_diagnostics/size_binned_eval")
    ap.add_argument("--imgsz", type=int, default=1280)
    ap.add_argument("--conf", type=float, default=0.001)
    ap.add_argument("--iou", type=float, default=0.50)
    ap.add_argument("--max-det", type=int, default=300)
    ap.add_argument("--device", default="0")
    ap.add_argument("--tiny-area", type=float, default=32 * 32)
    ap.add_argument("--small-area", type=float, default=96 * 96)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    images = resolve_split_images(args.data, args.split)
    class_names = get_class_names(args.data)

    all_summary = []
    for m in args.model:
        tag, weights = parse_model_arg(m)
        gts, preds = predict_all(tag, weights, images, args)

        # JSON-safe copies.
        gts_safe = []
        for g in gts:
            x = dict(g)
            x["xyxy"] = [float(v) for v in x["xyxy"]]
            gts_safe.append(x)

        preds_safe = []
        for p in preds:
            x = dict(p)
            x["xyxy"] = [float(v) for v in x["xyxy"]]
            preds_safe.append(x)

        write_jsonl(gts_safe, out / f"{tag}_gt.jsonl")
        write_jsonl(preds_safe, out / f"{tag}_preds.jsonl")

        rows = summarize(tag, gts, preds, class_names)
        all_summary.extend(rows)

    write_csv(all_summary, out / "size_binned_summary.csv")

    md = []
    md.append("# Size-binned AP/FN Analysis\n")
    md.append(f"- split: `{args.split}`")
    md.append(f"- imgsz: `{args.imgsz}`")
    md.append(f"- conf: `{args.conf}`")
    md.append(f"- iou: `{args.iou}`")
    md.append(f"- max_det: `{args.max_det}`")
    md.append(f"- tiny: area < `{args.tiny_area}` px²")
    md.append(f"- small: `{args.tiny_area}` <= area < `{args.small_area}` px²\n")

    macro = [r for r in all_summary if r["class_id"] == "macro"]
    md.append("## Macro rows\n")
    md.append(md_table(macro, [
        "model", "bin", "n_gt", "tp_gt_at50", "fn_gt_at50",
        "recall50", "ap50", "map50_95"
    ]))

    md.append("\n## Per-class rows\n")
    md.append(md_table(all_summary, [
        "model", "bin", "class_id", "class_name", "n_gt", "tp_gt_at50",
        "fn_gt_at50", "recall50", "ap50", "map50_95"
    ]))

    (out / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print(f"[DONE] {out / 'summary.md'}")


if __name__ == "__main__":
    main()
