from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from typing import Dict, List, Any, Tuple

import yaml
from PIL import Image

IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def load_yaml(path: str | Path) -> Dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def get_dataset_root(data_yaml: str | Path) -> Tuple[Dict[str, Any], Path]:
    data_yaml = Path(data_yaml).resolve()
    cfg = load_yaml(data_yaml)
    root = Path(cfg.get("path", data_yaml.parent)).expanduser()
    if not root.is_absolute():
        root = (data_yaml.parent / root).resolve()
    return cfg, root


def get_class_names(data_yaml: str | Path) -> Dict[int, str]:
    cfg, _ = get_dataset_root(data_yaml)
    names = cfg.get("names", {})
    if isinstance(names, list):
        return {i: str(v) for i, v in enumerate(names)}
    if isinstance(names, dict):
        return {int(k): str(v) for k, v in names.items()}
    return {}


def _resolve_one_split_item(item: str | Path, root: Path) -> List[Path]:
    p = Path(str(item)).expanduser()
    if not p.is_absolute():
        p = root / p

    if p.is_dir():
        return sorted([x.resolve() for x in p.rglob("*") if x.suffix.lower() in IMG_EXTS])

    if p.is_file() and p.suffix.lower() == ".txt":
        out = []
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            q = Path(line).expanduser()
            candidates = []
            if q.is_absolute():
                candidates.append(q)
            else:
                candidates.append(root / q)
                candidates.append(p.parent / q)
            for c in candidates:
                if c.exists() and c.suffix.lower() in IMG_EXTS:
                    out.append(c.resolve())
                    break
        return sorted(set(out))

    if p.is_file() and p.suffix.lower() in IMG_EXTS:
        return [p.resolve()]

    return []


def resolve_split_images(data_yaml: str | Path, split: str) -> List[Path]:
    cfg, root = get_dataset_root(data_yaml)
    item = cfg.get(split)
    if item is None:
        raise ValueError(f"Split '{split}' not found in {data_yaml}")

    images: List[Path] = []
    if isinstance(item, list):
        for x in item:
            images.extend(_resolve_one_split_item(x, root))
    else:
        images.extend(_resolve_one_split_item(item, root))

    images = sorted(set(images))
    if not images:
        raise RuntimeError(f"No images found for split='{split}' from item={item}")
    return images


def label_path_for_image(img_path: str | Path) -> Path:
    p = Path(img_path)
    parts = list(p.parts)
    replaced = False
    for i in range(len(parts) - 1, -1, -1):
        if parts[i] == "images":
            parts[i] = "labels"
            replaced = True
            break

    if replaced:
        return Path(*parts).with_suffix(".txt")

    # fallback: image_dir/../labels/stem.txt
    return (p.parent.parent / "labels" / p.stem).with_suffix(".txt")


def image_size(img_path: str | Path) -> Tuple[int, int]:
    with Image.open(img_path) as im:
        return im.size  # W, H


def yolo_to_xyxy(cx: float, cy: float, bw: float, bh: float, W: int, H: int) -> List[float]:
    x1 = (cx - bw / 2.0) * W
    y1 = (cy - bh / 2.0) * H
    x2 = (cx + bw / 2.0) * W
    y2 = (cy + bh / 2.0) * H
    return [max(0.0, x1), max(0.0, y1), min(float(W), x2), min(float(H), y2)]


def load_gt_for_image(img_path: str | Path) -> List[Dict[str, Any]]:
    img_path = Path(img_path)
    W, H = image_size(img_path)
    lbl = label_path_for_image(img_path)
    rows = []
    if not lbl.exists():
        return rows

    for li, line in enumerate(lbl.read_text(encoding="utf-8").splitlines()):
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        cls = int(float(parts[0]))
        cx, cy, bw, bh = map(float, parts[1:5])
        xyxy = yolo_to_xyxy(cx, cy, bw, bh, W, H)
        x1, y1, x2, y2 = xyxy
        area = max(0.0, x2 - x1) * max(0.0, y2 - y1)
        rows.append({
            "image": str(img_path),
            "image_name": img_path.name,
            "label_file": str(lbl),
            "line_id": li,
            "cls": cls,
            "xyxy": xyxy,
            "area": area,
            "W": W,
            "H": H,
        })
    return rows


def area_bin(area: float, tiny_area: float = 32 * 32, small_area: float = 96 * 96) -> str:
    if area < tiny_area:
        return "tiny"
    if area < small_area:
        return "small"
    return "medium_large"


def box_iou(a: List[float], b: List[float]) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b

    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)

    iw = max(0.0, ix2 - ix1)
    ih = max(0.0, iy2 - iy1)
    inter = iw * ih

    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    if union <= 0:
        return 0.0
    return inter / union


def voc_ap(rec: List[float], prec: List[float]) -> float:
    mrec = [0.0] + rec + [1.0]
    mpre = [0.0] + prec + [0.0]

    for i in range(len(mpre) - 2, -1, -1):
        mpre[i] = max(mpre[i], mpre[i + 1])

    ap = 0.0
    for i in range(1, len(mrec)):
        if mrec[i] != mrec[i - 1]:
            ap += (mrec[i] - mrec[i - 1]) * mpre[i]
    return ap


def write_csv(rows: List[Dict[str, Any]], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if not rows:
        path.write_text("", encoding="utf-8")
        return

    fieldnames = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                fieldnames.append(k)

    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def write_jsonl(rows: List[Dict[str, Any]], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def md_table(rows: List[Dict[str, Any]], columns: List[str]) -> str:
    if not rows:
        return "_No rows._\n"

    def fmt(v):
        if isinstance(v, float):
            return f"{v:.6f}"
        return str(v)

    out = []
    out.append("| " + " | ".join(columns) + " |")
    out.append("| " + " | ".join(["---"] * len(columns)) + " |")
    for r in rows:
        out.append("| " + " | ".join(fmt(r.get(c, "")) for c in columns) + " |")
    return "\n".join(out) + "\n"


def safe_float(x: Any, default: float = float("nan")) -> float:
    try:
        return float(x)
    except Exception:
        return default
