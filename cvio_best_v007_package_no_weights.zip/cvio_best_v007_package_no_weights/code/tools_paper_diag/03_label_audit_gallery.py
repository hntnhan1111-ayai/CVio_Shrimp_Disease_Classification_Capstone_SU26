from __future__ import annotations

import argparse
import html
from pathlib import Path
from typing import Dict, Any, List

from PIL import Image, ImageDraw, ImageFont
from ultralytics import YOLO

from common_diag import (
    resolve_split_images,
    load_gt_for_image,
    box_iou,
    write_csv,
    get_class_names,
)


COLORS = {
    "gt": (0, 180, 0),
    "tp": (0, 180, 0),
    "fn_missed_gt": (255, 0, 0),
    "possible_missing_label": (255, 0, 255),
    "box_shift_or_low_iou": (255, 140, 0),
    "wrong_class": (0, 120, 255),
    "fp_other": (160, 160, 160),
}


def draw_box(draw, box, color, text, width=3):
    x1, y1, x2, y2 = box
    draw.rectangle([x1, y1, x2, y2], outline=color, width=width)
    if text:
        tx, ty = x1, max(0, y1 - 14)
        draw.rectangle([tx, ty, tx + max(80, len(text) * 7), ty + 14], fill=color)
        draw.text((tx + 2, ty + 1), text, fill=(255, 255, 255))


def predict_image(model, img: Path, args) -> List[Dict[str, Any]]:
    result = model.predict(
        source=str(img),
        imgsz=args.imgsz,
        conf=args.conf,
        iou=args.iou,
        max_det=args.max_det,
        device=args.device,
        verbose=False,
    )[0]

    preds = []
    if result.boxes is None:
        return preds

    for k, b in enumerate(result.boxes):
        xyxy = [float(x) for x in b.xyxy[0].detach().cpu().tolist()]
        preds.append({
            "pred_id": f"{img.name}::pred{k}",
            "image_name": img.name,
            "cls": int(b.cls.item()),
            "conf": float(b.conf.item()),
            "xyxy": xyxy,
        })
    return preds


def analyze_image(img: Path, gts: List[Dict[str, Any]], preds: List[Dict[str, Any]], args, class_names):
    events = []

    for i, g in enumerate(gts):
        g["gt_id"] = f"{img.name}::gt{i}"

    preds_sorted = sorted(preds, key=lambda x: x["conf"], reverse=True)
    matched_gt = set()
    matched_pred = set()

    # First pass: true positives by same class IoU >= match_iou.
    for p in preds_sorted:
        best_gt = None
        best_iou = 0.0
        for g in gts:
            if g["gt_id"] in matched_gt:
                continue
            if g["cls"] != p["cls"]:
                continue
            iou = box_iou(p["xyxy"], g["xyxy"])
            if iou > best_iou:
                best_iou = iou
                best_gt = g

        if best_gt is not None and best_iou >= args.match_iou:
            matched_gt.add(best_gt["gt_id"])
            matched_pred.add(p["pred_id"])
            events.append({
                "image": str(img),
                "image_name": img.name,
                "event": "tp",
                "class_id": p["cls"],
                "class_name": class_names.get(p["cls"], str(p["cls"])),
                "conf": p["conf"],
                "iou": best_iou,
                "xyxy": p["xyxy"],
                "gt_xyxy": best_gt["xyxy"],
                "severity": 0,
            })

    # Missed GT = labeled object not detected.
    for g in gts:
        if g["gt_id"] not in matched_gt:
            events.append({
                "image": str(img),
                "image_name": img.name,
                "event": "fn_missed_gt",
                "class_id": g["cls"],
                "class_name": class_names.get(g["cls"], str(g["cls"])),
                "conf": "",
                "iou": "",
                "xyxy": g["xyxy"],
                "gt_xyxy": g["xyxy"],
                "severity": 3,
            })

    # Unmatched predictions: possible missing labels, box shifts, wrong class, or FP.
    for p in preds_sorted:
        if p["pred_id"] in matched_pred:
            continue

        best_same_cls_gt = None
        best_same_cls_iou = 0.0
        best_any_cls_gt = None
        best_any_cls_iou = 0.0

        for g in gts:
            iou = box_iou(p["xyxy"], g["xyxy"])
            if iou > best_any_cls_iou:
                best_any_cls_iou = iou
                best_any_cls_gt = g
            if g["cls"] == p["cls"] and iou > best_same_cls_iou:
                best_same_cls_iou = iou
                best_same_cls_gt = g

        if best_any_cls_gt is not None and best_any_cls_iou >= args.match_iou and best_any_cls_gt["cls"] != p["cls"]:
            event = "wrong_class"
            sev = 2
        elif args.low_iou <= best_same_cls_iou < args.match_iou:
            event = "box_shift_or_low_iou"
            sev = 2
        elif p["conf"] >= args.possible_missing_conf and best_any_cls_iou < args.low_iou:
            event = "possible_missing_label"
            sev = 2
        else:
            event = "fp_other"
            sev = 1 if p["conf"] >= args.fp_conf else 0

        events.append({
            "image": str(img),
            "image_name": img.name,
            "event": event,
            "class_id": p["cls"],
            "class_name": class_names.get(p["cls"], str(p["cls"])),
            "conf": p["conf"],
            "iou": max(best_same_cls_iou, best_any_cls_iou),
            "xyxy": p["xyxy"],
            "gt_xyxy": best_any_cls_gt["xyxy"] if best_any_cls_gt is not None else "",
            "severity": sev,
        })

    return events


def make_gallery_image(img: Path, events: List[Dict[str, Any]], out_path: Path, class_names):
    im = Image.open(img).convert("RGB")
    draw = ImageDraw.Draw(im)
    W, H = im.size
    width = max(2, min(W, H) // 350)

    # Draw GT first.
    for e in events:
        if e["event"] == "tp":
            continue
        if e["event"] == "fp_other" and float(e.get("severity", 0)) <= 0:
            continue

        color = COLORS.get(e["event"], (255, 255, 0))
        cls_name = e.get("class_name", str(e.get("class_id", "")))
        conf = e.get("conf", "")
        if isinstance(conf, float):
            text = f"{e['event']} {cls_name} {conf:.2f}"
        else:
            text = f"{e['event']} {cls_name}"
        draw_box(draw, e["xyxy"], color, text, width=width)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(out_path, quality=92)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--split", default="test")
    ap.add_argument("--weights", required=True)
    ap.add_argument("--tag", default="model")
    ap.add_argument("--out", default="paper_diagnostics/label_audit")
    ap.add_argument("--imgsz", type=int, default=1280)
    ap.add_argument("--conf", type=float, default=0.001)
    ap.add_argument("--iou", type=float, default=0.50)
    ap.add_argument("--max-det", type=int, default=1000)
    ap.add_argument("--device", default="0")
    ap.add_argument("--topk", type=int, default=200)
    ap.add_argument("--match-iou", type=float, default=0.50)
    ap.add_argument("--low-iou", type=float, default=0.10)
    ap.add_argument("--possible-missing-conf", type=float, default=0.05)
    ap.add_argument("--fp-conf", type=float, default=0.10)
    args = ap.parse_args()

    out = Path(args.out)
    gallery = out / "gallery"
    out.mkdir(parents=True, exist_ok=True)
    gallery.mkdir(parents=True, exist_ok=True)

    class_names = get_class_names(args.data)
    images = resolve_split_images(args.data, args.split)
    model = YOLO(args.weights)

    all_events = []
    image_scores = []

    for idx, img in enumerate(images):
        if idx % 25 == 0:
            print(f"[AUDIT] {idx}/{len(images)}")

        gts = load_gt_for_image(img)
        preds = predict_image(model, img, args)
        events = analyze_image(img, gts, preds, args, class_names)

        severity = sum(int(e.get("severity", 0)) for e in events)
        n_fn = sum(1 for e in events if e["event"] == "fn_missed_gt")
        n_possible_missing = sum(1 for e in events if e["event"] == "possible_missing_label")
        n_shift = sum(1 for e in events if e["event"] == "box_shift_or_low_iou")
        n_wrong_class = sum(1 for e in events if e["event"] == "wrong_class")
        n_fp = sum(1 for e in events if e["event"] == "fp_other" and int(e.get("severity", 0)) > 0)

        image_scores.append({
            "image": str(img),
            "image_name": img.name,
            "severity": severity,
            "n_gt": len(gts),
            "n_pred": len(preds),
            "n_fn_missed_gt": n_fn,
            "n_possible_missing_label": n_possible_missing,
            "n_box_shift_or_low_iou": n_shift,
            "n_wrong_class": n_wrong_class,
            "n_high_conf_fp_other": n_fp,
        })

        for e in events:
            e["model_tag"] = args.tag
            # Flatten boxes for CSV.
            xyxy = e.get("xyxy")
            if isinstance(xyxy, list):
                e["x1"], e["y1"], e["x2"], e["y2"] = xyxy
            gt_xyxy = e.get("gt_xyxy")
            if isinstance(gt_xyxy, list):
                e["gt_x1"], e["gt_y1"], e["gt_x2"], e["gt_y2"] = gt_xyxy
            all_events.append(e)

    image_scores = sorted(image_scores, key=lambda r: r["severity"], reverse=True)
    write_csv(image_scores, out / "image_scores.csv")
    write_csv(all_events, out / "audit_queue.csv")

    selected = [r for r in image_scores if r["severity"] > 0][:args.topk]
    events_by_image = {}
    for e in all_events:
        events_by_image.setdefault(e["image_name"], []).append(e)

    html_rows = []
    for rank, r in enumerate(selected, 1):
        img = Path(r["image"])
        out_img = gallery / f"{rank:04d}_{img.stem}.jpg"
        make_gallery_image(img, events_by_image.get(img.name, []), out_img, class_names)

        rel = out_img.relative_to(out)
        html_rows.append(f"""
        <tr>
          <td>{rank}</td>
          <td>{html.escape(img.name)}</td>
          <td>{r['severity']}</td>
          <td>{r['n_gt']}</td>
          <td>{r['n_pred']}</td>
          <td>{r['n_fn_missed_gt']}</td>
          <td>{r['n_possible_missing_label']}</td>
          <td>{r['n_box_shift_or_low_iou']}</td>
          <td>{r['n_wrong_class']}</td>
          <td><img src="{html.escape(str(rel))}" style="max-width:900px"></td>
        </tr>
        """)

    html_text = f"""
    <!doctype html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Label Audit Gallery - {html.escape(args.tag)}</title>
      <style>
        body {{ font-family: Arial, sans-serif; margin: 24px; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ccc; padding: 6px; vertical-align: top; }}
        th {{ background: #f2f2f2; }}
        img {{ border: 1px solid #ddd; }}
      </style>
    </head>
    <body>
      <h1>Label Audit Gallery - {html.escape(args.tag)}</h1>
      <p>
        Red = missed GT, magenta = possible missing label, orange = box shift/low IoU,
        blue = wrong class, gray = high-confidence FP.
      </p>
      <p>CSV files: <code>audit_queue.csv</code>, <code>image_scores.csv</code></p>
      <table>
        <tr>
          <th>Rank</th>
          <th>Image</th>
          <th>Severity</th>
          <th>GT</th>
          <th>Pred</th>
          <th>FN</th>
          <th>Possible missing label</th>
          <th>Box shift</th>
          <th>Wrong class</th>
          <th>Preview</th>
        </tr>
        {''.join(html_rows)}
      </table>
    </body>
    </html>
    """
    (out / "index.html").write_text(html_text, encoding="utf-8")
    print(f"[DONE] {out / 'index.html'}")
    print(f"[DONE] {out / 'audit_queue.csv'}")


if __name__ == "__main__":
    main()
