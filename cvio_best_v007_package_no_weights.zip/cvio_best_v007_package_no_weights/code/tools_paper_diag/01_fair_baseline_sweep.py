from __future__ import annotations

import argparse
import time
from pathlib import Path
from typing import Dict, Any, List

from ultralytics import YOLO

from common_diag import write_csv, md_table


def parse_list_int(s: str) -> List[int]:
    return [int(x) for x in s.split(",") if x.strip()]


def parse_list_float(s: str) -> List[float]:
    return [float(x) for x in s.split(",") if x.strip()]


def extract_metrics(result) -> Dict[str, Any]:
    box = getattr(result, "box", None)
    row = {}
    if box is not None:
        row["map50"] = float(getattr(box, "map50", float("nan")))
        row["map50_95"] = float(getattr(box, "map", float("nan")))
        row["map75"] = float(getattr(box, "map75", float("nan")))

        maps = getattr(box, "maps", None)
        if maps is not None:
            try:
                maps = list(maps)
                for i, v in enumerate(maps):
                    row[f"ap_class_{i}"] = float(v)
            except Exception:
                pass

    speed = getattr(result, "speed", None)
    if isinstance(speed, dict):
        for k, v in speed.items():
            row[f"speed_{k}"] = v

    return row


def run_val(weights: str, data_yaml: str, split: str, imgsz: int, conf: float, iou: float, max_det: int, device: str, project: Path, name: str):
    model = YOLO(weights)
    t0 = time.time()
    result = model.val(
        data=data_yaml,
        split=split,
        imgsz=imgsz,
        conf=conf,
        iou=iou,
        max_det=max_det,
        device=device,
        plots=False,
        save_json=False,
        verbose=False,
        project=str(project),
        name=name,
        exist_ok=True,
    )
    dt = time.time() - t0
    m = extract_metrics(result)
    m["elapsed_sec"] = dt
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--baseline", required=True)
    ap.add_argument("--a2", required=True)
    ap.add_argument("--out", default="paper_diagnostics/fair_baseline_sweep")
    ap.add_argument("--splits", default="val,test")
    ap.add_argument("--imgszs", default="1024,1280")
    ap.add_argument("--ious", default="0.50,0.70")
    ap.add_argument("--max-dets", default="300,1000")
    ap.add_argument("--confs", default="0.001")
    ap.add_argument("--device", default="0")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    models = {
        "baseline_yolo11s": args.baseline,
        "a2_current_best": args.a2,
    }

    splits = [x.strip() for x in args.splits.split(",") if x.strip()]
    imgszs = parse_list_int(args.imgszs)
    ious = parse_list_float(args.ious)
    max_dets = parse_list_int(args.max_dets)
    confs = parse_list_float(args.confs)

    rows = []
    for model_tag, weights in models.items():
        for split in splits:
            for imgsz in imgszs:
                for conf in confs:
                    for iou in ious:
                        for max_det in max_dets:
                            run_name = f"{model_tag}_{split}_img{imgsz}_conf{conf}_iou{iou}_md{max_det}".replace(".", "p")
                            row = {
                                "model": model_tag,
                                "weights": weights,
                                "split": split,
                                "imgsz": imgsz,
                                "conf": conf,
                                "iou": iou,
                                "max_det": max_det,
                                "status": "ok",
                            }
                            print(f"[RUN] {run_name}")
                            try:
                                m = run_val(
                                    weights=weights,
                                    data_yaml=args.data,
                                    split=split,
                                    imgsz=imgsz,
                                    conf=conf,
                                    iou=iou,
                                    max_det=max_det,
                                    device=args.device,
                                    project=out / "ultralytics_val_runs",
                                    name=run_name,
                                )
                                row.update(m)
                            except Exception as e:
                                row["status"] = "error"
                                row["error_type"] = type(e).__name__
                                row["error_message"] = str(e)
                                print(f"[ERROR] {run_name}: {type(e).__name__}: {e}")
                            rows.append(row)
                            write_csv(rows, out / "fair_baseline_sweep.csv")

    ok_test = [r for r in rows if r.get("status") == "ok" and r.get("split") == "test"]
    ok_test = sorted(ok_test, key=lambda r: float(r.get("map50_95", -1)), reverse=True)

    cols = [
        "model", "split", "imgsz", "conf", "iou", "max_det",
        "map50", "map50_95", "map75", "ap_class_0", "ap_class_1", "elapsed_sec"
    ]

    md = []
    md.append("# Fair Baseline Sweep\n")
    md.append("## Top test rows by mAP50-95\n")
    md.append(md_table(ok_test[:20], cols))

    # Paired comparison: baseline vs A2 under identical settings.
    md.append("\n## Paired baseline vs A2 under identical inference settings\n")
    paired = []
    key_fields = ["split", "imgsz", "conf", "iou", "max_det"]
    index = {}
    for r in rows:
        if r.get("status") != "ok":
            continue
        key = tuple(r.get(k) for k in key_fields)
        index.setdefault(key, {})[r["model"]] = r

    for key, d in index.items():
        b = d.get("baseline_yolo11s")
        a = d.get("a2_current_best")
        if not b or not a:
            continue
        paired.append({
            "split": key[0],
            "imgsz": key[1],
            "conf": key[2],
            "iou": key[3],
            "max_det": key[4],
            "baseline_map50": float(b.get("map50", float("nan"))),
            "a2_map50": float(a.get("map50", float("nan"))),
            "delta_map50": float(a.get("map50", float("nan"))) - float(b.get("map50", float("nan"))),
            "baseline_map50_95": float(b.get("map50_95", float("nan"))),
            "a2_map50_95": float(a.get("map50_95", float("nan"))),
            "delta_map50_95": float(a.get("map50_95", float("nan"))) - float(b.get("map50_95", float("nan"))),
        })

    paired = sorted(paired, key=lambda r: (r["split"] != "test", -r["delta_map50_95"]))
    write_csv(paired, out / "paired_baseline_vs_a2.csv")
    md.append(md_table(paired, [
        "split", "imgsz", "conf", "iou", "max_det",
        "baseline_map50", "a2_map50", "delta_map50",
        "baseline_map50_95", "a2_map50_95", "delta_map50_95",
    ]))

    (out / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print(f"[DONE] {out / 'summary.md'}")


if __name__ == "__main__":
    main()
