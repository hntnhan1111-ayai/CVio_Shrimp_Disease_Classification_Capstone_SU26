from __future__ import annotations

import argparse
import csv
import gc
import time
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
import torch


def read_rows(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_rows(path: Path, rows: List[Dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = []
    for r in rows:
        for k in r.keys():
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def append_row(path: Path, row: Dict[str, Any]):
    rows = read_rows(path)
    rows.append(row)
    write_rows(path, rows)


def has_ok(path: Path, vid: str, phase: str) -> bool:
    return any(
        r.get("id") == vid and r.get("phase") == phase and r.get("status") == "ok"
        for r in read_rows(path)
    )


def recipes() -> List[Dict[str, Any]]:
    # All recipes keep mosaic/mixup/copy_paste off because V007 won under nomosaic localization-safe training.
    base = dict(
        mosaic=0.0,
        mixup=0.0,
        copy_paste=0.0,
        erasing=0.0,
        close_mosaic=0,
        fliplr=0.50,
        flipud=0.03,
        perspective=0.00005,
        shear=0.3,
        hsv_h=0.006,
        hsv_s=0.25,
        hsv_v=0.18,
        degrees=2.0,
        translate=0.05,
        scale=0.15,
        box=10.0,
        cls=0.35,
        dfl=2.0,
        nbs=64,
        multi_scale=0.0,
    )

    def r(name: str, **kw):
        x = base.copy()
        x.update(kw)
        x["recipe"] = name
        return x

    return [
        # NWD/GFL-inspired: more localization emphasis, less classification pressure.
        r("R01_loc_strong_dfl", box=10.5, dfl=2.4, cls=0.28, scale=0.12, degrees=1.5, translate=0.04),

        # More box regression pressure.
        r("R02_loc_box_heavy", box=12.0, dfl=2.0, cls=0.25, scale=0.10, degrees=1.0, translate=0.035),

        # Recall-biased, but still localization-safe.
        r("R03_recall_soft_cls", box=9.0, dfl=1.8, cls=0.55, scale=0.18, hsv_s=0.30, hsv_v=0.22),

        # Precision-biased to reduce false positives.
        r("R04_precision_low_fp", box=11.0, dfl=2.2, cls=0.22, scale=0.08, hsv_s=0.15, hsv_v=0.10, fliplr=0.35),

        # Almost no augmentation: test whether V007 only needs clean fine-tune.
        r("R05_no_color_no_geom", box=10.0, dfl=2.0, cls=0.35, scale=0.00, degrees=0.0, translate=0.00, hsv_h=0.0, hsv_s=0.0, hsv_v=0.0, fliplr=0.0, flipud=0.0),

        # Soft color robustness without geometric damage.
        r("R06_soft_color_loc", box=10.0, dfl=2.1, cls=0.32, scale=0.08, degrees=1.0, translate=0.03, hsv_s=0.35, hsv_v=0.25),

        # Tiny lesion-safe movement: very small translate/scale.
        r("R07_tiny_motion_safe", box=11.5, dfl=2.3, cls=0.30, scale=0.06, degrees=0.8, translate=0.025, shear=0.0),

        # Balanced recipe: not too localization-heavy, keeps class learning.
        r("R08_bg_wssv_balanced", box=9.5, dfl=1.9, cls=0.45, scale=0.14, degrees=2.0, translate=0.05),

        # DFL-heavy for stricter mAP50-95 localization.
        r("R09_high_dfl_low_cls", box=9.0, dfl=2.8, cls=0.22, scale=0.08, degrees=1.0, translate=0.035),

        # Minimal perturbation, low LR should preserve V007.
        r("R10_stable_minimal", box=10.0, dfl=2.0, cls=0.30, scale=0.04, degrees=0.5, translate=0.02, hsv_s=0.10, hsv_v=0.08, fliplr=0.25),
    ]


def modes() -> List[Dict[str, Any]]:
    return [
        dict(mode="M01_ft60_lr1e4_1280", epochs=60, imgsz=1280, batch=2, lr0=1e-4, lrf=0.10, freeze=None, patience=35),
        dict(mode="M02_ft80_lr5e5_1280", epochs=80, imgsz=1280, batch=2, lr0=5e-5, lrf=0.15, freeze=None, patience=40),
        dict(mode="M03_ft60_freeze8_1280", epochs=60, imgsz=1280, batch=2, lr0=2e-4, lrf=0.10, freeze=8, patience=35),
        dict(mode="M04_ft80_freeze16_1280", epochs=80, imgsz=1280, batch=2, lr0=2e-4, lrf=0.10, freeze=16, patience=40),
        dict(mode="M05_ft50_lr8e5_1536", epochs=50, imgsz=1536, batch=1, lr0=8e-5, lrf=0.15, freeze=None, patience=30),
    ]


def make_variants() -> List[Dict[str, Any]]:
    out = []
    idx = 1
    for rec in recipes():
        for mode in modes():
            vid = f"F{idx:03d}_{rec['recipe']}_{mode['mode']}"
            out.append({"id": vid, **rec, **mode})
            idx += 1
    return out


def cleanup_cuda():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def train_variant(YOLO, v: Dict[str, Any], args, results_csv: Path):
    vid = v["id"]
    out = Path(args.out)
    run_dir = out / "runs_train" / vid
    best_pt = run_dir / "weights" / "best.pt"

    if best_pt.exists() or has_ok(results_csv, vid, "train"):
        print(f"[SKIP TRAIN] {vid}")
        return best_pt

    print(f"\n===== TRAIN {vid} =====")
    t0 = time.time()

    try:
        # Fine-tune directly from current best V007 checkpoint.
        model = YOLO(args.v007_weights)

        train_args = dict(
            data=args.data,
            epochs=int(v["epochs"]),
            imgsz=int(v["imgsz"]),
            batch=int(v["batch"]),
            device=args.device,
            workers=args.workers,
            optimizer=args.optimizer,
            lr0=float(v["lr0"]),
            lrf=float(v["lrf"]),
            cos_lr=True,
            patience=int(v["patience"]),
            seed=42,
            deterministic=True,
            amp=True,
            plots=False,
            verbose=True,
            project=str(out / "runs_train"),
            name=vid,
            exist_ok=True,
            mosaic=float(v["mosaic"]),
            mixup=float(v["mixup"]),
            copy_paste=float(v["copy_paste"]),
            erasing=float(v["erasing"]),
            close_mosaic=int(v["close_mosaic"]),
            fliplr=float(v["fliplr"]),
            flipud=float(v["flipud"]),
            perspective=float(v["perspective"]),
            shear=float(v["shear"]),
            hsv_h=float(v["hsv_h"]),
            hsv_s=float(v["hsv_s"]),
            hsv_v=float(v["hsv_v"]),
            degrees=float(v["degrees"]),
            translate=float(v["translate"]),
            scale=float(v["scale"]),
            box=float(v["box"]),
            cls=float(v["cls"]),
            dfl=float(v["dfl"]),
            nbs=int(v["nbs"]),
            multi_scale=float(v["multi_scale"]),
        )

        if v.get("freeze") is not None:
            train_args["freeze"] = int(v["freeze"])

        model.train(**train_args)

        status = "ok" if best_pt.exists() else "missing_best"
        append_row(
            results_csv,
            {
                **v,
                "phase": "train",
                "status": status,
                "best_pt": str(best_pt),
                "elapsed_sec": time.time() - t0,
            },
        )
    except Exception as e:
        append_row(
            results_csv,
            {
                **v,
                "phase": "train",
                "status": "error",
                "error_type": type(e).__name__,
                "error_message": str(e),
                "elapsed_sec": time.time() - t0,
            },
        )
        print(f"[ERROR TRAIN] {vid}: {type(e).__name__}: {e}")
    finally:
        cleanup_cuda()

    return best_pt


def eval_variant(YOLO, v: Dict[str, Any], args, results_csv: Path, best_pt: Path):
    vid = v["id"]

    if not best_pt.exists():
        print(f"[SKIP EVAL] {vid}: no best.pt")
        return

    eval_settings = [
        ("1536_iou055", 1536, 0.0005, 0.55, 600),
        ("1536_iou050", 1536, 0.0005, 0.50, 600),
        ("1280_iou055", 1280, 0.0005, 0.55, 600),
        ("1280_iou050", 1280, 0.0005, 0.50, 600),
    ]

    for split in ["val", "test"]:
        for tag, imgsz, conf, iou, max_det in eval_settings:
            phase = f"eval_{split}_{tag}"
            if has_ok(results_csv, vid, phase):
                print(f"[SKIP EVAL] {vid} {phase}")
                continue

            print(f"\n===== EVAL {vid} {split} {tag} =====")
            t0 = time.time()
            try:
                model = YOLO(str(best_pt))
                m = model.val(
                    data=args.data,
                    split=split,
                    imgsz=imgsz,
                    conf=conf,
                    iou=iou,
                    max_det=max_det,
                    device=args.device,
                    batch=1,
                    workers=4,
                    half=True,
                    plots=False,
                    save_json=False,
                    verbose=False,
                )
                maps = getattr(m.box, "maps", [])
                append_row(
                    results_csv,
                    {
                        **v,
                        "phase": phase,
                        "status": "ok",
                        "best_pt": str(best_pt),
                        "split": split,
                        "eval_tag": tag,
                        "eval_imgsz": imgsz,
                        "eval_conf": conf,
                        "eval_iou": iou,
                        "eval_max_det": max_det,
                        "map50": float(m.box.map50),
                        "map50_95": float(m.box.map),
                        "map75": float(m.box.map75),
                        "precision": float(m.box.mp),
                        "recall": float(m.box.mr),
                        "ap_BG": float(maps[0]) if len(maps) > 0 else "",
                        "ap_WSSV": float(maps[1]) if len(maps) > 1 else "",
                        "elapsed_sec": time.time() - t0,
                    },
                )
            except Exception as e:
                append_row(
                    results_csv,
                    {
                        **v,
                        "phase": phase,
                        "status": "error",
                        "split": split,
                        "eval_tag": tag,
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "elapsed_sec": time.time() - t0,
                    },
                )
                print(f"[ERROR EVAL] {vid} {phase}: {type(e).__name__}: {e}")
            finally:
                cleanup_cuda()


def summarize(out_dir: Path, yolo11s50: float, yolo11s5095: float, v00750: float, v0075095: float):
    p = out_dir / "v007_refine50_results.csv"
    if not p.exists():
        return

    df = pd.read_csv(p)
    ok = df[(df["status"] == "ok") & (df["phase"].astype(str).str.startswith("eval_test"))].copy()

    if ok.empty:
        (out_dir / "summary.md").write_text("# No OK test eval rows yet\n", encoding="utf-8")
        return

    for c in ["map50", "map50_95", "map75", "precision", "recall"]:
        ok[c] = pd.to_numeric(ok[c], errors="coerce")

    ok["delta_map50_vs_yolo11s_original"] = ok["map50"] - yolo11s50
    ok["delta_map50_95_vs_yolo11s_original"] = ok["map50_95"] - yolo11s5095
    ok["delta_map50_vs_v007_best"] = ok["map50"] - v00750
    ok["delta_map50_95_vs_v007_best"] = ok["map50_95"] - v0075095

    ok["map50_percent"] = ok["map50"] * 100
    ok["map50_95_percent"] = ok["map50_95"] * 100
    ok["delta_map50_vs_v007_pp"] = ok["delta_map50_vs_v007_best"] * 100
    ok["delta_map50_95_vs_v007_pp"] = ok["delta_map50_95_vs_v007_best"] * 100

    ok = ok.sort_values(["map50_95", "map50"], ascending=False)

    winners = ok[
        (ok["map50"] > v00750) &
        (ok["map50_95"] > v0075095)
    ].copy()

    ok.to_csv(out_dir / "ranked_test.csv", index=False)
    winners.to_csv(out_dir / "winners_over_v007_best.csv", index=False)

    cols = [
        "id", "recipe", "mode", "eval_tag",
        "map50", "map50_95", "map75", "precision", "recall",
        "delta_map50_vs_yolo11s_original",
        "delta_map50_95_vs_yolo11s_original",
        "delta_map50_vs_v007_best",
        "delta_map50_95_vs_v007_best",
        "best_pt",
    ]
    cols = [c for c in cols if c in ok.columns]

    md = []
    md.append("# V007-Refine50 Summary\n")
    md.append(f"- Original YOLO11s baseline mAP50: `{yolo11s50}`")
    md.append(f"- Original YOLO11s baseline mAP50-95: `{yolo11s5095}`")
    md.append(f"- Current V007 best mAP50: `{v00750}`")
    md.append(f"- Current V007 best mAP50-95: `{v0075095}`")
    md.append(f"- OK test eval rows: `{len(ok)}`")
    md.append(f"- Winners over V007 best on both metrics: `{len(winners)}`\n")

    md.append("## Top 50 test rows\n")
    md.append(ok[cols].head(50).to_markdown(index=False, floatfmt=".6f"))

    md.append("\n## Winners over current V007 best\n")
    if len(winners):
        md.append(winners[cols].to_markdown(index=False, floatfmt=".6f"))
    else:
        md.append("_No winner over V007 best yet._")

    md.append("\n## Best row per recipe\n")
    best_recipe = ok.groupby("recipe", as_index=False).head(1)
    md.append(best_recipe[cols].to_markdown(index=False, floatfmt=".6f"))

    md.append("\n## Best row per mode\n")
    best_mode = ok.groupby("mode", as_index=False).head(1)
    md.append(best_mode[cols].to_markdown(index=False, floatfmt=".6f"))

    (out_dir / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print("[DONE]", out_dir / "summary.md")
    print("[DONE]", out_dir / "ranked_test.csv")
    print("[DONE]", out_dir / "winners_over_v007_best.csv")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--v007-weights", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="0")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--optimizer", default="AdamW")
    ap.add_argument("--yolo11s-map50", type=float, default=0.129)
    ap.add_argument("--yolo11s-map50-95", type=float, default=0.038)
    ap.add_argument("--v007-map50", type=float, default=0.163909)
    ap.add_argument("--v007-map50-95", type=float, default=0.047748)
    args = ap.parse_args()

    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    from ultralytics import YOLO

    variants = make_variants()
    pd.DataFrame(variants).to_csv(out_dir / "v007_refine50_variants.csv", index=False)
    print("[INFO] total variants:", len(variants))
    print("[DONE]", out_dir / "v007_refine50_variants.csv")

    results_csv = out_dir / "v007_refine50_results.csv"

    for i, v in enumerate(variants, start=1):
        print("\n" + "#" * 100)
        print(f"### V007-REFINE VARIANT {i}/{len(variants)}: {v['id']}")
        print("#" * 100)

        best_pt = train_variant(YOLO, v, args, results_csv)
        eval_variant(YOLO, v, args, results_csv, best_pt)
        summarize(out_dir, args.yolo11s_map50, args.yolo11s_map50_95, args.v007_map50, args.v007_map50_95)

    summarize(out_dir, args.yolo11s_map50, args.yolo11s_map50_95, args.v007_map50, args.v007_map50_95)


if __name__ == "__main__":
    main()
