
from pathlib import Path
import json
def load_registry(path):
    path = Path(path)
    if path.suffix == ".json":
        return json.loads(path.read_text())
    try:
        import yaml
    except Exception as e:
        raise RuntimeError("Install PyYAML: pip install pyyaml") from e
    return yaml.safe_load(path.read_text())
def list_experiments(reg):
    return reg.get("experiments", [])
def registry_table(reg):
    return [{k:e.get(k) for k in ["id","group","kind","readiness","source_type","source_repo","description"]} for e in list_experiments(reg)]
