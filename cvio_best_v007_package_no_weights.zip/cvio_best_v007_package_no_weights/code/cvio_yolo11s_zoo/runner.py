
from pathlib import Path
import json, traceback, time
def write_json(path,obj):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True); path.write_text(json.dumps(obj,indent=2,ensure_ascii=False))
def run_train_val(exp, globals_cfg, dry_run=False):
    out={"id":exp["id"],"group":exp["group"],"kind":exp["kind"],"readiness":exp["readiness"],"status":"planned","timestamp":time.strftime("%Y-%m-%d %H:%M:%S")}
    if exp["readiness"] not in {"ready"}:
        out["status"]="requires_port_or_special_runner"; out["message"]="Registered for coverage; port module/YAML or use specialized notebook cell."; return out
    if dry_run:
        out["status"]="dry_run_ok"; return out
    try:
        from ultralytics import YOLO
        workdir=Path(globals_cfg["workdir"]); cfg=globals_cfg["train"]
        model=YOLO(exp["model_ref"])
        model.train(data=globals_cfg["data_yaml"], epochs=cfg["epochs"], patience=cfg["patience"], imgsz=cfg["imgsz"], batch=cfg["batch"], seed=cfg["seed"], device=cfg["device"], workers=cfg["workers"], pretrained=cfg["pretrained"], amp=cfg["amp"], project=str(workdir/"runs_train"), name=exp["id"], exist_ok=True)
        weights=workdir/"runs_train"/exp["id"]/ "weights" / "best.pt"
        model=YOLO(str(weights))
        val=model.val(data=globals_cfg["data_yaml"], split="test", imgsz=cfg["imgsz"], batch=min(cfg["batch"],8), device=cfg["device"], workers=cfg["workers"], plots=True, project=str(workdir/"runs_eval"), name=f"{exp['id']}_test", exist_ok=True)
        out.update({"status":"ok","weights":str(weights),"map50":float(val.box.map50),"map50_95":float(val.box.map),"map75":float(val.box.map75)})
    except Exception as e:
        out.update({"status":"failed","error":repr(e),"traceback":traceback.format_exc()})
    return out
