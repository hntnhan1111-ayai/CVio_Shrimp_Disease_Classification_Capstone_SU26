
import torch
def box_iou_xyxy(a,b):
    area1=(a[:,2]-a[:,0]).clamp(0)*(a[:,3]-a[:,1]).clamp(0); area2=(b[:,2]-b[:,0]).clamp(0)*(b[:,3]-b[:,1]).clamp(0)
    inter=(torch.min(a[:,None,2:],b[:,2:])-torch.max(a[:,None,:2],b[:,:2])).clamp(0).prod(2)
    return inter/(area1[:,None]+area2-inter+1e-7)
def soft_nms_xyxy(boxes,scores,iou_thr=.5,sigma=.5,score_thr=.001,method="linear"):
    boxes=boxes.clone(); scores=scores.clone(); kb=[]; ks=[]
    while boxes.numel()>0:
        i=torch.argmax(scores); kb.append(boxes[i:i+1]); ks.append(scores[i:i+1])
        mask=torch.ones(len(boxes),dtype=torch.bool,device=boxes.device); mask[i]=False
        rest=boxes[mask]; s=scores[mask]
        if rest.numel()==0: break
        iou=box_iou_xyxy(kb[-1],rest).squeeze(0)
        decay=torch.exp(-(iou*iou)/sigma) if method=="gaussian" else torch.where(iou>iou_thr,1-iou,torch.ones_like(iou))
        s=s*decay; keep=s>=score_thr; boxes=rest[keep]; scores=s[keep]
    return (torch.cat(kb,0), torch.cat(ks,0)) if kb else (boxes.new_zeros((0,4)), scores.new_zeros((0,)))
def diou_nms_xyxy(boxes,scores,iou_thr=.5):
    keep=[]; idx=scores.argsort(descending=True)
    while idx.numel()>0:
        i=idx[0]; keep.append(i)
        if idx.numel()==1: break
        cur=boxes[i:i+1]; rest=boxes[idx[1:]]; iou=box_iou_xyxy(cur,rest).squeeze(0)
        c1=(cur[:,:2]+cur[:,2:])/2; c2=(rest[:,:2]+rest[:,2:])/2
        dist=((c1-c2)**2).sum(1); lt=torch.min(cur[:,:2],rest[:,:2]); rb=torch.max(cur[:,2:],rest[:,2:])
        diag=((rb-lt)**2).sum(1).clamp(min=1e-7); diou=iou-dist/diag
        idx=idx[1:][diou<=iou_thr]
    return torch.stack(keep) if keep else torch.empty(0,dtype=torch.long,device=boxes.device)
