
from pathlib import Path
def run_sahi_predict(exp, weights, image_dir, out_dir, category_mapping=None):
    try:
        from sahi import AutoDetectionModel
        from sahi.predict import predict
    except Exception as e:
        raise RuntimeError("Install SAHI first: pip install sahi") from e
    category_mapping=category_mapping or {"0":"BG","1":"WSSV"}
    out_dir=Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    model=AutoDetectionModel.from_pretrained(model_type="ultralytics", model_path=weights, confidence_threshold=float(exp.get("conf",.25)), category_mapping=category_mapping, device="cuda:0")
    predict(detection_model=model, source=image_dir, slice_height=int(exp["slice_height"]), slice_width=int(exp["slice_width"]), overlap_height_ratio=float(exp["overlap_height_ratio"]), overlap_width_ratio=float(exp["overlap_width_ratio"]), project=str(out_dir.parent), name=out_dir.name, export_pickle=False, export_crop=False, export_visual=False)
    return str(out_dir)
