
import torch, torch.nn as nn, torch.nn.functional as F
class SimAM(nn.Module):
    def __init__(self, channels=None, e_lambda=1e-4): super().__init__(); self.e_lambda=e_lambda
    def forward(self,x):
        n=x.shape[2]*x.shape[3]-1
        if n<=0: return x
        v=(x-x.mean(dim=(2,3),keepdim=True)).pow(2)
        y=v/(4*(v.sum(dim=(2,3),keepdim=True)/n+self.e_lambda))+0.5
        return x*torch.sigmoid(y)
class CoordAttention(nn.Module):
    def __init__(self, inp, oup=None, reduction=32):
        super().__init__(); oup=oup or inp; mip=max(8, inp//reduction)
        self.pool_h=nn.AdaptiveAvgPool2d((None,1)); self.pool_w=nn.AdaptiveAvgPool2d((1,None))
        self.conv1=nn.Conv2d(inp,mip,1); self.bn1=nn.BatchNorm2d(mip); self.act=nn.Hardswish()
        self.conv_h=nn.Conv2d(mip,oup,1); self.conv_w=nn.Conv2d(mip,oup,1)
    def forward(self,x):
        identity=x; n,c,h,w=x.size(); x_h=self.pool_h(x); x_w=self.pool_w(x).permute(0,1,3,2)
        y=self.act(self.bn1(self.conv1(torch.cat([x_h,x_w],dim=2))))
        x_h,x_w=torch.split(y,[h,w],dim=2); x_w=x_w.permute(0,1,3,2)
        return identity*self.conv_h(x_h).sigmoid()*self.conv_w(x_w).sigmoid()
class CoordAttentionToSimAM(nn.Module):
    def __init__(self, channels, reduction=32): super().__init__(); self.ca=CoordAttention(channels,channels,reduction); self.simam=SimAM(channels)
    def forward(self,x): return self.simam(self.ca(x))
class CBAM(nn.Module):
    def __init__(self, channels, reduction=16):
        super().__init__(); h=max(1,channels//reduction)
        self.mlp=nn.Sequential(nn.Conv2d(channels,h,1,bias=False),nn.ReLU(True),nn.Conv2d(h,channels,1,bias=False))
        self.spatial=nn.Conv2d(2,1,7,padding=3,bias=False)
    def forward(self,x):
        ca=torch.sigmoid(self.mlp(F.adaptive_avg_pool2d(x,1))+self.mlp(F.adaptive_max_pool2d(x,1)))
        x=x*ca; sa=torch.sigmoid(self.spatial(torch.cat([x.mean(1,keepdim=True),x.max(1,keepdim=True)[0]],1)))
        return x*sa
class EMA(nn.Module):
    def __init__(self, channels, groups=8):
        super().__init__(); groups=max(1,min(groups,channels))
        while channels%groups and groups>1: groups-=1
        self.groups=groups; ch=channels//groups; self.gn=nn.GroupNorm(ch,ch); self.conv1=nn.Conv2d(ch,ch,1); self.conv3=nn.Conv2d(ch,ch,3,padding=1)
    def forward(self,x):
        b,c,h,w=x.shape; g=self.groups; y=x.reshape(b*g,c//g,h,w)
        yh=F.adaptive_avg_pool2d(y,(h,1)); yw=F.adaptive_avg_pool2d(y,(1,w)).permute(0,1,3,2)
        z=self.conv1(torch.cat([yh,yw],2)); zh,zw=torch.split(z,[h,w],2); zw=zw.permute(0,1,3,2)
        out=y*torch.sigmoid(self.gn(y*zh.sigmoid()*zw.sigmoid())+self.conv3(y))
        return out.reshape(b,c,h,w)
ATTENTION_REGISTRY={"SimAM":SimAM,"CoordAttention":CoordAttention,"CoordAttentionToSimAM":CoordAttentionToSimAM,"CBAM":CBAM,"EMA":EMA}
