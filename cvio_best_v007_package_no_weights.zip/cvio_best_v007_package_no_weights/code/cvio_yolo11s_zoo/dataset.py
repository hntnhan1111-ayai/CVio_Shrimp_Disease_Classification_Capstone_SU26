
from pathlib import Path
from collections import Counter
IMG_EXTS={".jpg",".jpeg",".png",".bmp",".webp",".JPG",".JPEG",".PNG",".BMP",".WEBP"}
def _imgs(p): 
    p=Path(p); return sorted([x for x in p.iterdir() if x.is_file() and x.suffix in IMG_EXTS]) if p.exists() else []
def _labs(p):
    p=Path(p); return sorted([x for x in p.iterdir() if x.is_file() and x.suffix.lower()==".txt"]) if p.exists() else []
def verify_yolo_dataset(data_yaml):
    data_yaml=Path(data_yaml)
    if not data_yaml.exists(): raise FileNotFoundError(data_yaml)
    root=None
    for line in data_yaml.read_text().splitlines():
        if line.strip().startswith("path:"): root=Path(line.split(":",1)[1].strip())
    if root is None: raise RuntimeError("Cannot parse path from data.yaml")
    rows=[]; global_counts=Counter(); bad=[]
    for split in ["train","val","test"]:
        imgs=_imgs(root/"images"/split); labs=_labs(root/"labels"/split); cls=Counter()
        if len(imgs)!=len(labs): bad.append([split,"count_mismatch",len(imgs),len(labs)])
        for lab in labs:
            txt=lab.read_text().strip()
            if not txt: bad.append([split,str(lab),"empty"]); continue
            for no,line in enumerate(txt.splitlines(),1):
                parts=line.split()
                if len(parts)!=5: bad.append([split,str(lab),f"line {no}: cols={len(parts)}"]); continue
                c=int(float(parts[0])); vals=[float(x) for x in parts[1:]]
                if c not in {0,1}: bad.append([split,str(lab),f"class {c}"])
                if not (0<=vals[0]<=1 and 0<=vals[1]<=1 and 0<vals[2]<=1 and 0<vals[3]<=1): bad.append([split,str(lab),f"xywh out of range {vals}"])
                cls[c]+=1; global_counts[c]+=1
        rows.append({"split":split,"images":len(imgs),"labels":len(labs),"total_boxes":cls[0]+cls[1],"BG_boxes":cls[0],"WSSV_boxes":cls[1]})
    return {"root":str(root),"rows":rows,"global_counts":dict(global_counts),"bad":bad}
