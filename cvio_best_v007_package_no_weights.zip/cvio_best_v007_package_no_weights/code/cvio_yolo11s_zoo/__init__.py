"""CVio YOLO11s full method zoo."""
__version__="0.1.0"
