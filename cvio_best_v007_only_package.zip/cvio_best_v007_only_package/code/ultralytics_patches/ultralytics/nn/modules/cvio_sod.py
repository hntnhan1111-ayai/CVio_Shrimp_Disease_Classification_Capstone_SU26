
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.nn.modules.block import C3k2


class SimAM(nn.Module):
    """Parameter-free 3D attention adapted from SimAM."""

    def __init__(self, e_lambda=1e-4):
        super().__init__()
        self.e_lambda = e_lambda

    def forward(self, x):
        b, c, h, w = x.shape
        n = max(h * w - 1, 1)
        mu = x.mean(dim=(2, 3), keepdim=True)
        d = (x - mu).pow(2)
        v = d.sum(dim=(2, 3), keepdim=True) / n
        e_inv = d / (4 * (v + self.e_lambda)) + 0.5
        return x * torch.sigmoid(e_inv)


class ECA(nn.Module):
    """Efficient Channel Attention."""

    def __init__(self, channels, k_size=3):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv(y.squeeze(-1).transpose(-1, -2))
        y = self.sigmoid(y.transpose(-1, -2).unsqueeze(-1))
        return x * y


class SE(nn.Module):
    """Squeeze-and-Excitation style channel recalibration."""

    def __init__(self, channels, reduction=16):
        super().__init__()
        hidden = max(channels // reduction, 8)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=True),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=True),
            nn.Sigmoid(),
        )

    def forward(self, x):
        return x * self.fc(self.pool(x))


class CoordAtt(nn.Module):
    """Coordinate Attention: channel attention with positional encoding."""

    def __init__(self, channels, reduction=32):
        super().__init__()
        mip = max(8, channels // reduction)
        self.conv1 = nn.Conv2d(channels, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = nn.SiLU(inplace=True)
        self.conv_h = nn.Conv2d(mip, channels, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, channels, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x
        n, c, h, w = x.size()
        x_h = x.mean(dim=3, keepdim=True)
        x_w = x.mean(dim=2, keepdim=True).permute(0, 1, 3, 2)
        y = torch.cat([x_h, x_w], dim=2)
        y = self.act(self.bn1(self.conv1(y)))
        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)
        a_h = torch.sigmoid(self.conv_h(x_h))
        a_w = torch.sigmoid(self.conv_w(x_w))
        return identity * a_w * a_h


class CBAM(nn.Module):
    """CBAM channel + spatial attention."""

    def __init__(self, channels, reduction=16, spatial_kernel=7):
        super().__init__()
        hidden = max(channels // reduction, 8)
        self.mlp = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=False),
        )
        self.spatial = nn.Conv2d(
            2,
            1,
            kernel_size=spatial_kernel,
            padding=spatial_kernel // 2,
            bias=False,
        )

    def forward(self, x):
        avg = self.mlp(F.adaptive_avg_pool2d(x, 1))
        mx = self.mlp(F.adaptive_max_pool2d(x, 1))
        x = x * torch.sigmoid(avg + mx)
        avg_out = x.mean(dim=1, keepdim=True)
        max_out, _ = x.max(dim=1, keepdim=True)
        s = torch.sigmoid(self.spatial(torch.cat([avg_out, max_out], dim=1)))
        return x * s


class LiteContext(nn.Module):
    """Light dilated depthwise context block for tiny lesion surroundings."""

    def __init__(self, channels):
        super().__init__()
        self.dw1 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.dw2 = nn.Conv2d(channels, channels, 3, padding=2, dilation=2, groups=channels, bias=False)
        self.pw = nn.Conv2d(channels * 2, channels, 1, bias=False)
        self.bn = nn.BatchNorm2d(channels)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        y = torch.cat([self.dw1(x), self.dw2(x)], dim=1)
        y = self.act(self.bn(self.pw(y)))
        return x + y


class MultiScaleDW(nn.Module):
    """Cheap multi-kernel depthwise feature mixing."""

    def __init__(self, channels):
        super().__init__()
        self.b3 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.b5 = nn.Conv2d(channels, channels, 5, padding=2, groups=channels, bias=False)
        self.bd = nn.Conv2d(channels, channels, 3, padding=3, dilation=3, groups=channels, bias=False)
        self.fuse = nn.Sequential(
            nn.Conv2d(channels * 3, channels, 1, bias=False),
            nn.BatchNorm2d(channels),
            nn.SiLU(inplace=True),
        )

    def forward(self, x):
        y = torch.cat([self.b3(x), self.b5(x), self.bd(x)], dim=1)
        return x + self.fuse(y)


class _C3k2AttnBase(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__()
        self.block = C3k2(c1, c2, n, shortcut, e)
        self.attn = nn.Identity()

    def forward(self, x):
        return self.attn(self.block(x))


class C3k2SimAM(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = SimAM()


class C3k2ECA(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = ECA(c2)


class C3k2CA(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = CoordAtt(c2)


class C3k2CBAM(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = CBAM(c2)


class C3k2SE(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = SE(c2)


class C3k2LiteContext(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = LiteContext(c2)


class C3k2MultiScaleDW(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = MultiScaleDW(c2)


class C3k2TinyFusion(_C3k2AttnBase):
    """Custom shrimp-SOD fusion: cheap multiscale context + ECA + SimAM."""

    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = nn.Sequential(
            MultiScaleDW(c2),
            ECA(c2),
            SimAM(),
        )
