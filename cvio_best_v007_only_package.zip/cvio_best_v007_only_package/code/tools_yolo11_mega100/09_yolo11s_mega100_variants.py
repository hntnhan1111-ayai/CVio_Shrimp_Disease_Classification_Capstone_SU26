from __future__ import annotations

import argparse
import csv
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
import yaml


CUSTOM_NAMES = [
    "C3k2SimAM",
    "C3k2ECA",
    "C3k2CA",
    "C3k2CBAM",
    "C3k2SE",
    "C3k2LiteContext",
    "C3k2MultiScaleDW",
    "C3k2TinyFusion",
]


CUSTOM_MODULE_CODE = r'''
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.nn.modules.block import C3k2


class SimAM(nn.Module):
    """Parameter-free 3D attention adapted from SimAM."""

    def __init__(self, e_lambda=1e-4):
        super().__init__()
        self.e_lambda = e_lambda

    def forward(self, x):
        b, c, h, w = x.shape
        n = max(h * w - 1, 1)
        mu = x.mean(dim=(2, 3), keepdim=True)
        d = (x - mu).pow(2)
        v = d.sum(dim=(2, 3), keepdim=True) / n
        e_inv = d / (4 * (v + self.e_lambda)) + 0.5
        return x * torch.sigmoid(e_inv)


class ECA(nn.Module):
    """Efficient Channel Attention."""

    def __init__(self, channels, k_size=3):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv(y.squeeze(-1).transpose(-1, -2))
        y = self.sigmoid(y.transpose(-1, -2).unsqueeze(-1))
        return x * y


class SE(nn.Module):
    """Squeeze-and-Excitation style channel recalibration."""

    def __init__(self, channels, reduction=16):
        super().__init__()
        hidden = max(channels // reduction, 8)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=True),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=True),
            nn.Sigmoid(),
        )

    def forward(self, x):
        return x * self.fc(self.pool(x))


class CoordAtt(nn.Module):
    """Coordinate Attention: channel attention with positional encoding."""

    def __init__(self, channels, reduction=32):
        super().__init__()
        mip = max(8, channels // reduction)
        self.conv1 = nn.Conv2d(channels, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = nn.SiLU(inplace=True)
        self.conv_h = nn.Conv2d(mip, channels, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, channels, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x
        n, c, h, w = x.size()
        x_h = x.mean(dim=3, keepdim=True)
        x_w = x.mean(dim=2, keepdim=True).permute(0, 1, 3, 2)
        y = torch.cat([x_h, x_w], dim=2)
        y = self.act(self.bn1(self.conv1(y)))
        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)
        a_h = torch.sigmoid(self.conv_h(x_h))
        a_w = torch.sigmoid(self.conv_w(x_w))
        return identity * a_w * a_h


class CBAM(nn.Module):
    """CBAM channel + spatial attention."""

    def __init__(self, channels, reduction=16, spatial_kernel=7):
        super().__init__()
        hidden = max(channels // reduction, 8)
        self.mlp = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=False),
        )
        self.spatial = nn.Conv2d(
            2,
            1,
            kernel_size=spatial_kernel,
            padding=spatial_kernel // 2,
            bias=False,
        )

    def forward(self, x):
        avg = self.mlp(F.adaptive_avg_pool2d(x, 1))
        mx = self.mlp(F.adaptive_max_pool2d(x, 1))
        x = x * torch.sigmoid(avg + mx)
        avg_out = x.mean(dim=1, keepdim=True)
        max_out, _ = x.max(dim=1, keepdim=True)
        s = torch.sigmoid(self.spatial(torch.cat([avg_out, max_out], dim=1)))
        return x * s


class LiteContext(nn.Module):
    """Light dilated depthwise context block for tiny lesion surroundings."""

    def __init__(self, channels):
        super().__init__()
        self.dw1 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.dw2 = nn.Conv2d(channels, channels, 3, padding=2, dilation=2, groups=channels, bias=False)
        self.pw = nn.Conv2d(channels * 2, channels, 1, bias=False)
        self.bn = nn.BatchNorm2d(channels)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x):
        y = torch.cat([self.dw1(x), self.dw2(x)], dim=1)
        y = self.act(self.bn(self.pw(y)))
        return x + y


class MultiScaleDW(nn.Module):
    """Cheap multi-kernel depthwise feature mixing."""

    def __init__(self, channels):
        super().__init__()
        self.b3 = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.b5 = nn.Conv2d(channels, channels, 5, padding=2, groups=channels, bias=False)
        self.bd = nn.Conv2d(channels, channels, 3, padding=3, dilation=3, groups=channels, bias=False)
        self.fuse = nn.Sequential(
            nn.Conv2d(channels * 3, channels, 1, bias=False),
            nn.BatchNorm2d(channels),
            nn.SiLU(inplace=True),
        )

    def forward(self, x):
        y = torch.cat([self.b3(x), self.b5(x), self.bd(x)], dim=1)
        return x + self.fuse(y)


class _C3k2AttnBase(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__()
        self.block = C3k2(c1, c2, n, shortcut, e)
        self.attn = nn.Identity()

    def forward(self, x):
        return self.attn(self.block(x))


class C3k2SimAM(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = SimAM()


class C3k2ECA(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = ECA(c2)


class C3k2CA(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = CoordAtt(c2)


class C3k2CBAM(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = CBAM(c2)


class C3k2SE(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = SE(c2)


class C3k2LiteContext(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = LiteContext(c2)


class C3k2MultiScaleDW(_C3k2AttnBase):
    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = MultiScaleDW(c2)


class C3k2TinyFusion(_C3k2AttnBase):
    """Custom shrimp-SOD fusion: cheap multiscale context + ECA + SimAM."""

    def __init__(self, c1, c2, n=1, shortcut=False, e=0.25):
        super().__init__(c1, c2, n, shortcut, e)
        self.attn = nn.Sequential(
            MultiScaleDW(c2),
            ECA(c2),
            SimAM(),
        )
'''



def patch_ultralytics(local_root: Path):
    """
    Robust local-Ultralytics patcher.

    Why this exists:
    - Some Ultralytics versions define base_modules/repeat_modules as named frozensets.
    - Your local 8.4.75 tree does not expose them in the exact expected text format.
    - So we patch by following the official custom-module path:
      1) create ultralytics/nn/modules/cvio_sod.py
      2) expose custom classes in ultralytics/nn/modules/__init__.py
      3) import custom classes in ultralytics/nn/tasks.py
      4) add custom classes beside C3k2 inside parse_model, so c1/c2/repeat args are handled like C3k2.
    """
    pkg = local_root / "ultralytics"
    module_dir = pkg / "nn" / "modules"
    init_path = module_dir / "__init__.py"
    tasks_path = pkg / "nn" / "tasks.py"
    cvio_path = module_dir / "cvio_sod.py"

    if not tasks_path.exists():
        raise FileNotFoundError(tasks_path)
    if not init_path.exists():
        raise FileNotFoundError(init_path)

    cvio_path.write_text(CUSTOM_MODULE_CODE, encoding="utf-8")

    custom_import = "from .cvio_sod import " + ", ".join(CUSTOM_NAMES) + "  # noqa: F401\n"
    init_text = init_path.read_text(encoding="utf-8")
    if "from .cvio_sod import" not in init_text:
        init_text += "\n" + custom_import
        init_path.write_text(init_text, encoding="utf-8")

    text = tasks_path.read_text(encoding="utf-8")

    # Add custom names into the main "from ultralytics.nn.modules import (...)" block.
    # This works because __init__.py now exposes the classes.
    if "C3k2SimAM" not in text.split("def parse_model", 1)[0]:
        marker = "C3k2,"
        if marker in text:
            text = text.replace(marker, marker + "\n    " + ",\n    ".join(CUSTOM_NAMES) + ",", 1)
        else:
            # Fallback import line if the import block is formatted differently.
            import_line = "from ultralytics.nn.modules.cvio_sod import " + ", ".join(CUSTOM_NAMES) + "\n"
            insert_at = text.find("from ultralytics")
            if insert_at >= 0:
                text = import_line + text
            else:
                text = import_line + text

    # Patch parse_model only, not import blocks.
    if "def parse_model" not in text:
        raise RuntimeError("Could not find parse_model() in tasks.py")

    pre, post = text.split("def parse_model", 1)

    # Add our C3k2 wrapper classes next to C3k2 wherever parse_model checks base/repeat modules.
    # This supports both older tuple/set style and newer frozenset style.
    insert_names = ", ".join(CUSTOM_NAMES)
    if "C3k2SimAM" not in post:
        if "C3k2," not in post:
            raise RuntimeError("Could not find C3k2 inside parse_model(); inspect tasks.py manually.")
        post = post.replace("C3k2,", "C3k2, " + insert_names + ",")
    else:
        print("[INFO] custom names already present in parse_model")

    text = pre + "def parse_model" + post
    tasks_path.write_text(text, encoding="utf-8")

    print("[PATCHED]", cvio_path)
    print("[PATCHED]", init_path)
    print("[PATCHED]", tasks_path)

def write_yaml(path: Path, obj: Dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(obj, sort_keys=False), encoding="utf-8")


def yolo11s_yaml(custom_module: str | None, layers_to_replace: List[int]) -> Dict[str, Any]:
    def m(layer_idx: int, default: str = "C3k2"):
        if default == "C3k2" and custom_module and layer_idx in layers_to_replace:
            return custom_module
        return default

    return {
        "nc": 2,
        "backbone": [
            [-1, 1, "Conv", [32, 3, 2]],
            [-1, 1, "Conv", [64, 3, 2]],
            [-1, 1, m(2), [128, False, 0.25]],
            [-1, 1, "Conv", [128, 3, 2]],
            [-1, 1, m(4), [256, False, 0.25]],
            [-1, 1, "Conv", [256, 3, 2]],
            [-1, 1, m(6), [256, True]],
            [-1, 1, "Conv", [512, 3, 2]],
            [-1, 1, m(8), [512, True]],
            [-1, 1, "SPPF", [512, 5]],
            [-1, 1, "C2PSA", [512]],
        ],
        "head": [
            [-1, 1, "nn.Upsample", [None, 2, "nearest"]],
            [[-1, 6], 1, "Concat", [1]],
            [-1, 1, m(13), [256, False]],
            [-1, 1, "nn.Upsample", [None, 2, "nearest"]],
            [[-1, 4], 1, "Concat", [1]],
            [-1, 1, m(16), [128, False]],
            [-1, 1, "Conv", [128, 3, 2]],
            [[-1, 13], 1, "Concat", [1]],
            [-1, 1, m(19), [256, False]],
            [-1, 1, "Conv", [256, 3, 2]],
            [[-1, 10], 1, "Concat", [1]],
            [-1, 1, m(22), [512, True]],
            [[16, 19, 22], 1, "Detect", ["nc"]],
        ],
    }


def profile_kwargs(profile: str) -> Dict[str, Any]:
    base = dict(
        hsv_h=0.010,
        hsv_s=0.35,
        hsv_v=0.25,
        degrees=5.0,
        translate=0.08,
        scale=0.30,
        shear=1.0,
        perspective=0.0002,
        flipud=0.05,
        fliplr=0.50,
        mosaic=0.20,
        mixup=0.0,
        copy_paste=0.0,
        erasing=0.05,
        close_mosaic=40,
        box=7.5,
        cls=0.5,
        dfl=1.5,
        multi_scale=False,
    )

    if profile == "nomosaic_loc":
        base.update(
            mosaic=0.0,
            mixup=0.0,
            copy_paste=0.0,
            erasing=0.0,
            scale=0.20,
            degrees=3.0,
            box=10.0,
            dfl=2.0,
            cls=0.35,
            close_mosaic=0,
        )
    elif profile == "mild_sod":
        base.update(
            mosaic=0.15,
            scale=0.25,
            degrees=4.0,
            translate=0.06,
            box=8.5,
            dfl=1.75,
            cls=0.40,
            close_mosaic=50,
        )
    elif profile == "recall_sr":
        base.update(
            mosaic=0.10,
            scale=0.35,
            degrees=6.0,
            translate=0.08,
            box=7.5,
            dfl=1.5,
            cls=0.45,
            close_mosaic=40,
        )
    elif profile == "multiscale_loc":
        base.update(
            mosaic=0.10,
            scale=0.50,
            degrees=5.0,
            box=9.5,
            dfl=2.0,
            cls=0.35,
            multi_scale=True,
            close_mosaic=50,
        )
    return base


def generate_variants(max_variants: int, out_dir: Path, data: str, sr_data: str | None) -> List[Dict[str, Any]]:
    placements = {
        "head": [16, 19, 22],
        "neck": [13, 16, 19, 22],
        "backbone": [4, 6, 8],
        "deep": [8, 22],
        "all": [2, 4, 6, 8, 13, 16, 19, 22],
    }
    profiles = ["nomosaic_loc", "mild_sod", "multiscale_loc"]
    variants = []

    idx = 1

    # Architecture x placement x training profile = 8 * 5 * 3 = 120.
    for mod in CUSTOM_NAMES:
        for place_name, layer_ids in placements.items():
            for prof in profiles:
                vid = f"V{idx:03d}_{mod}_{place_name}_{prof}"
                yaml_path = out_dir / "configs" / f"{vid}.yaml"
                write_yaml(yaml_path, yolo11s_yaml(mod, layer_ids))
                variants.append(
                    {
                        "id": vid,
                        "kind": "arch_custom",
                        "module": mod,
                        "placement": place_name,
                        "profile": prof,
                        "data": data,
                        "yaml": str(yaml_path),
                    }
                )
                idx += 1
                if len(variants) >= max_variants:
                    return variants

    # Add baseline/SR control variants if max_variants > 120.
    extra_profiles = ["nomosaic_loc", "mild_sod", "recall_sr", "multiscale_loc"]
    for prof in extra_profiles:
        vid = f"V{idx:03d}_BASELINE_{prof}"
        variants.append(
            {
                "id": vid,
                "kind": "baseline_train",
                "module": "BASELINE",
                "placement": "none",
                "profile": prof,
                "data": data,
                "yaml": "",
            }
        )
        idx += 1

    if sr_data:
        for prof in extra_profiles:
            vid = f"V{idx:03d}_SRX2_BASELINE_{prof}"
            variants.append(
                {
                    "id": vid,
                    "kind": "sr_train",
                    "module": "BASELINE",
                    "placement": "sr_x2",
                    "profile": prof,
                    "data": sr_data,
                    "yaml": "",
                }
            )
            idx += 1

    return variants[:max_variants]


def read_rows(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_rows(path: Path, rows: List[Dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def append_row(path: Path, row: Dict[str, Any]):
    rows = read_rows(path)
    rows.append(row)
    write_rows(path, rows)


def has_ok(path: Path, vid: str, phase: str) -> bool:
    return any(r.get("id") == vid and r.get("phase") == phase and r.get("status") == "ok" for r in read_rows(path))


def train_and_eval_variant(YOLO, v: Dict[str, Any], args, results_csv: Path):
    vid = v["id"]
    run_dir = Path(args.out) / "runs_train" / vid
    best_pt = run_dir / "weights" / "best.pt"

    if not best_pt.exists() and not has_ok(results_csv, vid, "train"):
        print(f"\n===== TRAIN {vid} =====")
        t0 = time.time()
        try:
            if v["yaml"]:
                model = YOLO(v["yaml"])
                model.load(args.pretrain)
            else:
                model = YOLO(args.pretrain)

            hp = profile_kwargs(v["profile"])

            model.train(
                data=v["data"],
                epochs=args.epochs,
                imgsz=args.imgsz,
                batch=args.batch,
                device=args.device,
                workers=args.workers,
                optimizer="AdamW",
                lr0=args.lr0,
                cos_lr=True,
                patience=args.patience,
                seed=42,
                project=str(Path(args.out) / "runs_train"),
                name=vid,
                exist_ok=True,
                plots=False,
                verbose=True,
                **hp,
            )

            status = "ok" if best_pt.exists() else "missing_best"
            append_row(
                results_csv,
                {
                    **v,
                    "phase": "train",
                    "status": status,
                    "best_pt": str(best_pt),
                    "elapsed_sec": time.time() - t0,
                },
            )
        except Exception as e:
            append_row(
                results_csv,
                {
                    **v,
                    "phase": "train",
                    "status": "error",
                    "error_type": type(e).__name__,
                    "error_message": str(e),
                    "elapsed_sec": time.time() - t0,
                },
            )
            print(f"[ERROR TRAIN] {vid}: {type(e).__name__}: {e}")
            return
    else:
        print(f"[SKIP TRAIN] {vid}")

    if not best_pt.exists():
        print(f"[SKIP EVAL] no best.pt for {vid}")
        return

    eval_settings = [
        ("new_anchor_iou055", 1280, 0.0005, 0.55, 600),
        ("calib_iou050", 1280, 0.0005, 0.50, 600),
        ("hires1536_iou055", 1536, 0.0005, 0.55, 600),
    ]

    for split in ["val", "test"]:
        for tag, imgsz, conf, iou, max_det in eval_settings:
            phase = f"eval_{split}_{tag}"
            if has_ok(results_csv, vid, phase):
                print(f"[SKIP EVAL] {vid} {phase}")
                continue

            print(f"\n===== EVAL {vid} {split} {tag} =====")
            t0 = time.time()
            try:
                model = YOLO(str(best_pt))
                m = model.val(
                    data=v["data"],
                    split=split,
                    imgsz=imgsz,
                    conf=conf,
                    iou=iou,
                    max_det=max_det,
                    device=args.device,
                    batch=1,
                    workers=4,
                    half=True,
                    plots=False,
                    save_json=False,
                    verbose=False,
                )
                maps = getattr(m.box, "maps", [])
                append_row(
                    results_csv,
                    {
                        **v,
                        "phase": phase,
                        "status": "ok",
                        "best_pt": str(best_pt),
                        "split": split,
                        "eval_tag": tag,
                        "eval_imgsz": imgsz,
                        "eval_conf": conf,
                        "eval_iou": iou,
                        "eval_max_det": max_det,
                        "map50": float(m.box.map50),
                        "map50_95": float(m.box.map),
                        "map75": float(m.box.map75),
                        "precision": float(m.box.mp),
                        "recall": float(m.box.mr),
                        "ap_BG": float(maps[0]) if len(maps) > 0 else "",
                        "ap_WSSV": float(maps[1]) if len(maps) > 1 else "",
                        "elapsed_sec": time.time() - t0,
                    },
                )
            except Exception as e:
                append_row(
                    results_csv,
                    {
                        **v,
                        "phase": phase,
                        "status": "error",
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "elapsed_sec": time.time() - t0,
                    },
                )
                print(f"[ERROR EVAL] {vid} {phase}: {type(e).__name__}: {e}")


def summarize(out_dir: Path, anchor50: float, anchor5095: float):
    csv_path = out_dir / "mega100_results.csv"
    df = pd.read_csv(csv_path)

    ok = df[(df["status"] == "ok") & (df["phase"].astype(str).str.startswith("eval_test"))].copy()
    if ok.empty:
        (out_dir / "summary.md").write_text("# No OK test eval rows yet\n", encoding="utf-8")
        return

    for c in ["map50", "map50_95", "map75", "precision", "recall"]:
        ok[c] = pd.to_numeric(ok[c], errors="coerce")

    ok["delta_map50_vs_new_anchor"] = ok["map50"] - anchor50
    ok["delta_map50_95_vs_new_anchor"] = ok["map50_95"] - anchor5095
    ok = ok.sort_values(["map50_95", "map50"], ascending=False)

    winners = ok[(ok["map50"] > anchor50) & (ok["map50_95"] > anchor5095)].copy()

    ok.to_csv(out_dir / "ranked_test.csv", index=False)
    winners.to_csv(out_dir / "winners_over_new_anchor.csv", index=False)

    cols = [
        "id", "kind", "module", "placement", "profile", "eval_tag",
        "map50", "map50_95", "map75", "precision", "recall",
        "delta_map50_vs_new_anchor", "delta_map50_95_vs_new_anchor",
        "best_pt",
    ]
    cols = [c for c in cols if c in ok.columns]

    md = []
    md.append("# YOLO11s Mega100 Variants Summary\n")
    md.append(f"- New anchor mAP50: `{anchor50}`")
    md.append(f"- New anchor mAP50-95: `{anchor5095}`")
    md.append(f"- OK test eval rows: `{len(ok)}`")
    md.append(f"- Winners over new anchor on both metrics: `{len(winners)}`\n")

    md.append("## Top 50 test rows\n")
    md.append(ok[cols].head(50).to_markdown(index=False, floatfmt=".6f"))

    md.append("\n## Winners over new anchor\n")
    if len(winners):
        md.append(winners[cols].head(50).to_markdown(index=False, floatfmt=".6f"))
    else:
        md.append("_No winners yet._")

    md.append("\n## Best row per custom module\n")
    best_each = ok.groupby("module", as_index=False).head(1)
    md.append(best_each[cols].to_markdown(index=False, floatfmt=".6f"))

    (out_dir / "summary.md").write_text("\n".join(md), encoding="utf-8")
    print("[DONE]", out_dir / "summary.md")
    print("[DONE]", out_dir / "ranked_test.csv")
    print("[DONE]", out_dir / "winners_over_new_anchor.csv")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--local-ultralytics", default="third_party/ultralytics")
    ap.add_argument("--pretrain", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--sr-data", default="")
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-variants", type=int, default=120)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--imgsz", type=int, default=1280)
    ap.add_argument("--batch", type=int, default=2)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--device", default="0")
    ap.add_argument("--lr0", type=float, default=0.0005)
    ap.add_argument("--patience", type=int, default=40)
    ap.add_argument("--anchor-map50", type=float, default=0.15808826734245732)
    ap.add_argument("--anchor-map50-95", type=float, default=0.044098721071476624)
    args = ap.parse_args()

    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    patch_ultralytics(Path(args.local_ultralytics).resolve())

    import py_compile
    py_compile.compile(
        str(Path(args.local_ultralytics).resolve() / "ultralytics" / "nn" / "modules" / "cvio_sod.py"),
        doraise=True,
    )
    py_compile.compile(
        str(Path(args.local_ultralytics).resolve() / "ultralytics" / "nn" / "tasks.py"),
        doraise=True,
    )

    from ultralytics import YOLO

    sr_data = args.sr_data if args.sr_data and Path(args.sr_data).exists() else ""
    variants = generate_variants(args.max_variants, out_dir, args.data, sr_data)

    variants_csv = out_dir / "mega100_variants.csv"
    pd.DataFrame(variants).to_csv(variants_csv, index=False)
    print("[DONE]", variants_csv)
    print(f"[INFO] total variants: {len(variants)}")

    results_csv = out_dir / "mega100_results.csv"

    for i, v in enumerate(variants, start=1):
        print("\n" + "#" * 80)
        print(f"### VARIANT {i}/{len(variants)}: {v['id']}")
        print("#" * 80)
        train_and_eval_variant(YOLO, v, args, results_csv)
        summarize(out_dir, args.anchor_map50, args.anchor_map50_95)

    summarize(out_dir, args.anchor_map50, args.anchor_map50_95)


if __name__ == "__main__":
    main()
