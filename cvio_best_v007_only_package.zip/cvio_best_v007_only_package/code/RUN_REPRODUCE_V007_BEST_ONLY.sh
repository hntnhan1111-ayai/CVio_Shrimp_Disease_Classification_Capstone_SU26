#!/usr/bin/env bash
set -euo pipefail

# Reproduce only the current best V007 architecture.
# This script assumes you are running inside:
# /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:${PYTHONPATH:-}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

DATA_YAML="${DATA_YAML:-/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml}"
V007_YAML="${V007_YAML:-/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants/configs/V007_C3k2SimAM_backbone_nomosaic_loc.yaml}"
PRETRAIN="${PRETRAIN:-/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt}"
OUT_ROOT="${OUT_ROOT:-/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/reproduce_v007_best_only}"

mkdir -p "$OUT_ROOT/logs"

.venv/bin/python - <<'PY' 2>&1 | tee "$OUT_ROOT/logs/reproduce_v007_best_only.log"
import os
from ultralytics import YOLO

data = os.environ["DATA_YAML"]
yaml = os.environ["V007_YAML"]
pretrain = os.environ["PRETRAIN"]
out = os.environ["OUT_ROOT"]

model = YOLO(yaml).load(pretrain)
model.train(
    data=data,
    epochs=200,
    imgsz=1280,
    batch=2,
    device=os.environ.get("DEVICE", "0"),
    workers=int(os.environ.get("WORKERS", "8")),
    optimizer="AdamW",
    lr0=0.0005,
    lrf=0.01,
    cos_lr=True,
    patience=40,
    seed=42,
    deterministic=True,
    amp=True,
    project=out,
    name="V007_C3k2SimAM_backbone_nomosaic_loc",
    exist_ok=True,

    hsv_h=0.01,
    hsv_s=0.35,
    hsv_v=0.25,
    degrees=3.0,
    translate=0.08,
    scale=0.2,
    shear=1.0,
    perspective=0.0002,
    flipud=0.05,
    fliplr=0.5,
    mosaic=0.0,
    mixup=0.0,
    copy_paste=0.0,
    erasing=0.0,
    close_mosaic=0,

    box=10.0,
    cls=0.35,
    dfl=2.0,
    nbs=64,
    plots=True,
    verbose=True,
)
PY
