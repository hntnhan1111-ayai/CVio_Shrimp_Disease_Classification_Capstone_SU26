#!/usr/bin/env bash
set -euo pipefail

cd /home/drnguyenvinh/notebooks/cvio_yolo11s_method_zoo

export PYTHONPATH="$PWD/third_party/ultralytics:$PWD:${PYTHONPATH:-}"

DATA_YAML="/home/drnguyenvinh/notebooks/shrimp_yolo_canonical_bg_wssv_2cls_split70_15_15/data.yaml"
YOLO11S_WEIGHTS="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/baseline_reuse_lock/yolo11s_baseline_best.pt"
SR_DATA="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_survey_methods_final200_live/sr_x2/data.yaml"
OUT_ROOT="/home/drnguyenvinh/notebooks/shrimp_yolo11s_full_method_zoo/yolo11s_mega100_variants"

mkdir -p "$OUT_ROOT/logs"

echo "===== MEGA100 YOLO11s E2E ====="
echo "DATA_YAML=$DATA_YAML"
echo "YOLO11S_WEIGHTS=$YOLO11S_WEIGHTS"
echo "SR_DATA=$SR_DATA"
echo "OUT_ROOT=$OUT_ROOT"
echo "MAX_VARIANTS=${MAX_VARIANTS:-120}"
echo "EPOCHS=${EPOCHS:-200}"
echo "IMGSZ=${IMGSZ:-1280}"
echo "BATCH=${BATCH:-2}"
echo "LR0=${LR0:-0.0005}"

test -f "$DATA_YAML" || { echo "[FATAL] missing DATA_YAML"; exit 1; }
test -f "$YOLO11S_WEIGHTS" || { echo "[FATAL] missing YOLO11S_WEIGHTS"; exit 1; }
test -f "tools_yolo11_mega100/09_yolo11s_mega100_variants.py" || { echo "[FATAL] missing mega100 python script"; exit 1; }

.venv/bin/python -m pip install -U pandas pyyaml tabulate >/dev/null

set +e
stdbuf -oL -eL .venv/bin/python tools_yolo11_mega100/09_yolo11s_mega100_variants.py \
  --local-ultralytics "$PWD/third_party/ultralytics" \
  --pretrain "$YOLO11S_WEIGHTS" \
  --data "$DATA_YAML" \
  --sr-data "$SR_DATA" \
  --out "$OUT_ROOT" \
  --max-variants "${MAX_VARIANTS:-120}" \
  --epochs "${EPOCHS:-200}" \
  --imgsz "${IMGSZ:-1280}" \
  --batch "${BATCH:-2}" \
  --workers "${WORKERS:-8}" \
  --device "${DEVICE:-0}" \
  --lr0 "${LR0:-0.0005}" \
  --patience "${PATIENCE:-40}" \
  --anchor-map50 0.15808826734245732 \
  --anchor-map50-95 0.044098721071476624 \
  2>&1 | tee "$OUT_ROOT/logs/mega100_live.log"

CODE=${PIPESTATUS[0]}
set -e

echo
echo "===== PYTHON EXIT CODE: $CODE ====="

if [ "$CODE" -ne 0 ]; then
  echo "[FAILED] Mega100 stopped with error. Check:"
  echo "$OUT_ROOT/logs/mega100_live.log"
  exit "$CODE"
fi

echo
echo "===== FINAL SUMMARY ====="
if [ -f "$OUT_ROOT/summary.md" ]; then
  cat "$OUT_ROOT/summary.md"
else
  echo "[WARN] summary.md not found"
fi

echo
echo "===== WINNERS ====="
if [ -f "$OUT_ROOT/winners_over_new_anchor.csv" ]; then
  cat "$OUT_ROOT/winners_over_new_anchor.csv"
else
  echo "[WARN] winners_over_new_anchor.csv not found"
fi

echo
echo "===== OUTPUT FILES ====="
echo "$OUT_ROOT/summary.md"
echo "$OUT_ROOT/ranked_test.csv"
echo "$OUT_ROOT/winners_over_new_anchor.csv"
echo "$OUT_ROOT/mega100_results.csv"
echo "$OUT_ROOT/mega100_variants.csv"
echo "$OUT_ROOT/logs/mega100_live.log"
