# CVio Best V007 Only Package

## Verdict

The original package is valid and contains no weights or raw dataset image folders, but it is too broad for a best-only handoff. This filtered package keeps only files needed to document and reproduce the current best method.

## Current best method

| Field | Value |
|---|---:|
| Method ID | `V007_C3k2SimAM_backbone_nomosaic_loc` |
| Module | `C3k2SimAM` |
| Placement | `backbone` |
| Profile | `nomosaic_loc` |
| Eval tag | `hires1536_iou055` |
| mAP50 | `0.163909` = `16.391%` |
| mAP50-95 | `0.047748` = `4.775%` |
| Precision | `0.237079` |
| Recall | `0.249353` |
| AP_BG | `0.058749` |
| AP_WSSV | `0.036746` |

## Improvement

Compared with original YOLO11s baseline `mAP50=0.129`, `mAP50-95=0.038`:

- mAP50 improvement: `3.491` percentage points.
- mAP50-95 improvement: `0.975` percentage points.

Compared with calibrated YOLO11s anchor `mAP50=0.158088`, `mAP50-95=0.044099`:

- mAP50 improvement: `0.582` percentage points.
- mAP50-95 improvement: `0.365` percentage points.

## Training note

The run was planned for 200 epochs with `patience=40`, but the stored V007 `results.csv` has `138` recorded epochs. Best validation mAP50-95 occurred at epoch `98`.

## Files kept

- `configs/V007_C3k2SimAM_backbone_nomosaic_loc.yaml`
- `run_metadata/V007_C3k2SimAM_backbone_nomosaic_loc/args.yaml`
- `run_metadata/V007_C3k2SimAM_backbone_nomosaic_loc/results.csv`
- `results/best_v007_eval_rows.csv`
- `results/top10_mega100_context.csv`
- `results/winner_v007_over_new_anchor.csv`
- `results/best_v007_variant_definition.csv`
- `code/tools_yolo11_mega100/09_yolo11s_mega100_variants.py`
- `code/ultralytics_patches/`
- `code/RUN_REPRODUCE_V007_BEST_ONLY.sh`
- `visuals/v007_training_val_metrics.png`

## Exclusions

No weights and no raw dataset images are included.
