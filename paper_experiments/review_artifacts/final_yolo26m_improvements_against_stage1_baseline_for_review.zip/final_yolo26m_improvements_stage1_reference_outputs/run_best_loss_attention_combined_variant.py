
from __future__ import annotations
import json
from pathlib import Path
import sys

ROOT = Path(r"/home/drnguyenvinh/notebooks/Improving Lightweight Shrimp Disease Classification with Co-Infection-Aware Losses and RandAugment").resolve()
sys.path.insert(0, str(ROOT))

from shrimp_scripts.dataset import load_yolo_manifest
from shrimp_scripts.models_yolo import train_yolo_with_fallback, yolo_run_id
from shrimp_scripts.utils import read_json, write_json

output_dir = Path(r"/home/drnguyenvinh/notebooks/final_yolo26m_improvements_stage1_reference_outputs")
model = "yolo26m-cls"
condition = {
    "condition_key": "best_loss_asl_ldam_margin_best_attention_cbam_randaugment",
    "loss_key": "asl_ldam_margin",
    "randaugment": True,
    "attention_key": "cbam",
    "epochs": int(30),
    "experiment_key": "final_yolo26m_improvement_against_stage1_baseline",
    "experiment_group": "final_yolo26m_improvement_against_stage1_baseline",
    "screening_note": "Final combined best-loss + best-attention variant; CE baseline is fixed Stage 1 reference and is not rerun.",
}
yolo_manifest = load_yolo_manifest(output_dir)
result = train_yolo_with_fallback(model, condition, yolo_manifest, output_dir, resume=True, smoke_test=False, progress_enabled=True)
run_id = yolo_run_id(model, condition)
run_dir = output_dir / "runs" / run_id
metrics = read_json(run_dir / "metrics.json", default={})
write_json(output_dir / "final_best_loss_attention_combined_result.json", {"run_id": run_id, "result": result, "metrics": metrics, "run_dir": str(run_dir)})
print(json.dumps({"run_id": run_id, "result": result, "metrics": metrics, "run_dir": str(run_dir)}, indent=2, default=str))
