# YOLOv26m-cls Attention Screening Reproducibility Report

Screening design: YOLOv26m-cls, cross-entropy with RandAugment enabled as the default YOLO classification recipe, fixed paper class order and dataset split.

Planned variants: 9
Completed valid variants: 8
Failed/skipped/missing variants: 1

Ranking rule: sort by test_macro_f1 descending, then cohen_kappa descending, test_accuracy descending, latency_ms_image ascending, fps descending, model_size_mb ascending, params_m ascending.

## Ranking

| rank | attention_key | test_macro_f1 | cohen_kappa | test_accuracy | latency_ms_image | fps | model_size_mb | params_m |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | cbam | 0.9037288195636654 | 0.8660685823580309 | 0.9017341040462428 | 66.00248331279424 | 15.150945082791381 | 19.983222007751465 | 10.379622 |
| 2 | ema | 0.8815802882755328 | 0.8502505694760819 | 0.8901734104046243 | 65.86051538500483 | 15.183604230155794 | 19.922121047973633 | 10.347876 |
| 3 | se | 0.8772155403119135 | 0.8425483503981798 | 0.884393063583815 | 68.85724536256294 | 14.522799957136986 | 19.984376907348633 | 10.380068 |
| 4 | simam | 0.865436692850486 | 0.8265110766706171 | 0.8728323699421965 | 68.67773408834645 | 14.560759950431803 | 19.91878318786621 | 10.346756 |
| 5 | coordatt | 0.8628276753276752 | 0.8185342272084645 | 0.8670520231213873 | 66.89308282267841 | 14.949228796209335 | 19.97104263305664 | 10.372388 |
| 6 | triplet | 0.842046062937479 | 0.7949489423778263 | 0.8497109826589595 | 66.51341019338265 | 15.034562159609264 | 19.921454429626465 | 10.34705 |
| 7 | eca | 0.8414619883040935 | 0.7956383462062698 | 0.8497109826589595 | 66.00800139366547 | 15.14967850694486 | 19.91975498199463 | 10.346759 |
| 8 | c2psa_or_psa | 0.810252065634585 | 0.7556497175141244 | 0.8208092485549133 | 67.527302427788 | 14.808824935208612 | 21.834720611572266 | 11.334916 |

## Failed Or Skipped

| run_id | model | attention_key | condition_key | status | errors |
| --- | --- | --- | --- | --- | --- |
| yolo_attention_screening_ultralytics_yolo26m_cls_attention_none_baseline_ce_randaugment_seed42_repeat1 | yolo26m-cls | none_baseline | attention_none_baseline_ce_randaugment | missing | attention_audit:missing_or_empty:attention_module_audit.json \| class_order_audit:missing_or_empty:class_order_audit.json \| invalid_or_missing_metric:cohen_kappa \| invalid_or_missing_metric:test_accuracy \| invalid_or_missing_metric:test_macro_f1 \| missing_run_directory |
